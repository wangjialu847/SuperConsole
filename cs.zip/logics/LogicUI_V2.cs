﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SuperConsole
{
    public static class LogicUI_V2
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 800, 600);
        private static Vector2 scrollPos = Vector2.zero;
        private static LogicEntityV2 editingLogic = null;

        public static Rect GetWindowRect() => windowRect;
        public static void ResetPosition() => windowRect = new Rect(100, 100, 800, 600);

        public static void Toggle()
        {
            visible = !visible;
            if (visible && editingLogic == null)
            {
                var all = LogicManagerV2.GetAll();
                if (all.Count > 0) editingLogic = all[0];
            }
        }

        public static bool IsVisible() => visible;

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12360);
            windowRect = GUI.Window(12360, windowRect, DrawWindow, "逻辑体编辑器 V2 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            // ❌ 删除所有 GUI.FocusControl 调用
            // 焦点由 SuperConsole.OnGUI() 统一管理

            GUILayout.BeginVertical();

            // ---- 标题栏 ----
            GUILayout.BeginHorizontal();
            GUILayout.Label("逻辑体列表", GUILayout.Width(100));

            var all = LogicManagerV2.GetAll();
            string[] names = all.Select(l => l.GetDisplayName()).ToArray();
            int idx = editingLogic != null ? Array.IndexOf(names, editingLogic.GetDisplayName()) : -1;
            if (idx < 0 && names.Length > 0) idx = 0;

            int newIdx = GUILayout.SelectionGrid(
                idx >= 0 ? idx : 0,
                names.Length > 0 ? names : new string[] { "(无)" },
                4,
                GUILayout.ExpandWidth(true)
            );

            if (newIdx >= 0 && newIdx < names.Length && (editingLogic == null || editingLogic.GetDisplayName() != names[newIdx]))
            {
                editingLogic = LogicManagerV2.GetAll()[newIdx];
            }

            if (GUILayout.Button("新建", GUILayout.Width(50)))
            {
                var logic = LogicManagerV2.Create("新逻辑体_" + (all.Count + 1));
                editingLogic = logic;
            }

            if (GUILayout.Button("刷新", GUILayout.Width(50)))
            {
                LogicManagerV2.Refresh();
                var list = LogicManagerV2.GetAll();
                if (list.Count > 0 && editingLogic != null)
                {
                    editingLogic = list.FirstOrDefault(l => l.id == editingLogic.id);
                    if (editingLogic == null) editingLogic = list[0];
                }
            }

            // ---- 导出/导入 .mod ----
            if (GUILayout.Button("导出 .mod", GUILayout.Width(80)))
            {
                if (editingLogic != null)
                {
                    LogicManagerV2.ExportToMod(editingLogic.id);
                    Debug.Log("[LogicUI_V2] 导出 .mod: " + editingLogic.name);
                }
            }
            if (GUILayout.Button("导入 .mod", GUILayout.Width(80)))
            {
                string logicsPath = Path.Combine(BepInEx.Paths.PluginPath, "SuperConsole", "Logics");
                if (Directory.Exists(logicsPath))
                {
                    string[] modFiles = Directory.GetFiles(logicsPath, "*.mod");
                    if (modFiles.Length == 0)
                    {
                        Debug.Log("[LogicUI_V2] 没有找到 .mod 文件");
                    }
                    else
                    {
                        foreach (string modFile in modFiles)
                        {
                            LogicManagerV2.ImportMod(modFile);
                        }
                    }
                }
                LogicManagerV2.Refresh();
                var list = LogicManagerV2.GetAll();
                if (list.Count > 0) editingLogic = list[0];
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (editingLogic == null)
            {
                GUILayout.Label("没有逻辑体，点击「新建」创建");
                GUILayout.EndVertical();
                GUI.DragWindow();
                return;
            }

            // ---- 基本信息 ----
            GUILayout.BeginHorizontal();
            GUILayout.Label("名称:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_name");
            string n = GUILayout.TextField(editingLogic.name, GUILayout.Width(150));
            if (n != editingLogic.name) editingLogic.name = n;

            GUILayout.Label("ID:", GUILayout.Width(25));
            GUILayout.Label(editingLogic.id, GUILayout.Width(120));

            GUILayout.Label("类型:", GUILayout.Width(35));
            string[] types = Enum.GetNames(typeof(LogicType));
            int ti = Array.IndexOf(types, editingLogic.type.ToString());
            int nt = GUILayout.SelectionGrid(ti >= 0 ? ti : 0, types, 4, GUILayout.Width(300));
            if (nt >= 0) editingLogic.type = (LogicType)nt;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("版本:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_version");
            string v = GUILayout.TextField(editingLogic.version, GUILayout.Width(80));
            if (v != editingLogic.version) editingLogic.version = v;

            GUILayout.Label("作者:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_author");
            string a = GUILayout.TextField(editingLogic.author, GUILayout.Width(120));
            if (a != editingLogic.author) editingLogic.author = a;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("描述:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_desc");
            string d = GUILayout.TextField(editingLogic.description, GUILayout.ExpandWidth(true));
            if (d != editingLogic.description) editingLogic.description = d;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("状态:", GUILayout.Width(35));
            GUILayout.Label(editingLogic.GetStatusText(), GUILayout.Width(80));

            if (GUILayout.Button(editingLogic.enabled ? "禁用" : "启用", GUILayout.Width(50)))
            {
                editingLogic.enabled = !editingLogic.enabled;
                LogicManagerV2.SaveToFile(editingLogic);
            }
            if (GUILayout.Button("保存", GUILayout.Width(50)))
            {
                LogicManagerV2.SaveToFile(editingLogic);
            }
            if (GUILayout.Button("删除", GUILayout.Width(50)))
            {
                LogicManagerV2.Delete(editingLogic.id);
                var list = LogicManagerV2.GetAll();
                editingLogic = list.Count > 0 ? list[0] : null;
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ---- 资源列表 ----
            GUILayout.Label("资源", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("预制体: " + (string.IsNullOrEmpty(editingLogic.resources.Prefab) ? "(无)" : editingLogic.resources.Prefab), GUILayout.ExpandWidth(true)))
            {
                // TODO: 选择预制体
            }
            if (GUILayout.Button("模型: " + (string.IsNullOrEmpty(editingLogic.resources.Model) ? "(无)" : editingLogic.resources.Model), GUILayout.ExpandWidth(true)))
            {
                // TODO: 选择模型
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("纹理: " + (editingLogic.resources.Textures?.Count ?? 0), GUILayout.Width(100));
            GUILayout.Label("音频: " + (editingLogic.resources.Audio?.Count ?? 0), GUILayout.Width(100));
            GUILayout.Label("材质: " + (editingLogic.resources.Materials?.Count ?? 0), GUILayout.Width(100));
            GUILayout.Label("动画: " + (editingLogic.resources.Animations?.Count ?? 0), GUILayout.Width(100));
            GUILayout.Label("脚本: " + (editingLogic.resources.Scripts?.Count ?? 0), GUILayout.Width(100));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ---- 操作按钮 ----
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("提取当前对象", GUILayout.Height(30)))
            {
                if (SuperConsole.selectedObject != null)
                {
                    LogicPrefabExtractor.Extract(SuperConsole.selectedObject, SuperConsole.selectedObject.name);
                    LogicManagerV2.Refresh();
                    var list = LogicManagerV2.GetAll();
                    if (list.Count > 0) editingLogic = list[0];
                }
                else
                {
                    Debug.LogWarning("[LogicUI_V2] 请先在对象浏览器中选中一个对象");
                }
            }
            if (GUILayout.Button("提取场景", GUILayout.Height(30)))
            {
                string sceneName = SceneManager.GetActiveScene().name;
                if (string.IsNullOrEmpty(sceneName)) sceneName = "未命名场景";
                LogicExtractor.ExtractFromScene(sceneName);
                LogicManagerV2.Refresh();
                var list = LogicManagerV2.GetAll();
                if (list.Count > 0) editingLogic = list[list.Count - 1];
                Debug.Log("[LogicUI_V2] 场景提取完成: " + sceneName);
            }
            if (GUILayout.Button("3D 预览", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                    LogicPreview3D.Toggle(editingLogic);
                else
                    Debug.LogWarning("[LogicUI_V2] 请先选择一个逻辑体");
            }
            if (GUILayout.Button("召唤到玩家", GUILayout.Height(30)))
            {
                LogicSpawnerV2.SpawnAtPlayer(editingLogic.id);
            }
            if (GUILayout.Button("召唤到鼠标", GUILayout.Height(30)))
            {
                LogicSpawnerV2.SpawnAtMouse(editingLogic.id);
            }
            if (GUILayout.Button("批量召唤", GUILayout.Height(30)))
            {
                LogicSpawnerV2.SpawnMultiple(editingLogic.id, Vector3.zero, 5, 2f);
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("提示: 在对象浏览器中选中对象 -> 点击「提取当前对象」", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("关闭", GUILayout.Width(60))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace SuperConsole
{
    // ============================================================
    // 逻辑体预制体提取器
    // 从游戏对象提取完整的预制体 + 引用资源
    // ============================================================
    public static class LogicPrefabExtractor
    {
        // ============================================================
        // 提取对象到逻辑体
        // ============================================================
        public static LogicEntityV2 Extract(GameObject source, string name, LogicType type = LogicType.Prefab)
        {
            if (source == null)
            {
                Debug.LogError("[LogicPrefabExtractor] ❌ 源对象为空");
                return null;
            }

            // ---- 1. 创建逻辑体 ----
            LogicEntityV2 logic = LogicManagerV2.Create(name, type);

            // ---- 2. 创建目录结构 ----
            string prefabDir = Path.Combine(logic.FolderPath, "prefabs");
            string modelsDir = Path.Combine(logic.FolderPath, "models");
            string texturesDir = Path.Combine(logic.FolderPath, "textures");
            string audioDir = Path.Combine(logic.FolderPath, "audio");
            string materialsDir = Path.Combine(logic.FolderPath, "materials");
            string animationsDir = Path.Combine(logic.FolderPath, "animations");

            Directory.CreateDirectory(prefabDir);
            Directory.CreateDirectory(modelsDir);
            Directory.CreateDirectory(texturesDir);
            Directory.CreateDirectory(audioDir);
            Directory.CreateDirectory(materialsDir);
            Directory.CreateDirectory(animationsDir);

            // ---- 3. 克隆对象 ----
            GameObject clone = UnityEngine.Object.Instantiate(source);
            clone.name = source.name;

            // ---- 4. 清理组件（移除 MonoBehaviour 脚本，只保留核心组件） ----
            CleanComponents(clone);

            // ---- 5. 提取 Mesh（模型） ----
            ExtractMeshes(clone, modelsDir, ref logic);

            // ---- 6. 提取 Textures（纹理） ----
            ExtractTextures(clone, texturesDir, ref logic);

            // ---- 7. 提取 Audio（音频） ----
            ExtractAudio(clone, audioDir, ref logic);

            // ---- 8. 提取 Materials（材质） ----
            ExtractMaterials(clone, materialsDir, ref logic);

            // ---- 9. 提取 Animations（动画） ----
            ExtractAnimations(clone, animationsDir, ref logic);

            // ---- 10. 保存为预制体（使用 LogicPrefabSaver 真正保存） ----
            LogicPrefabSaver.SavePrefab(clone, logic.FolderPath, "main");
            logic.resources.Prefab = "prefabs/main.prefab";

            // ---- 11. 清理克隆 ----
            UnityEngine.Object.Destroy(clone);

            // ---- 12. 保存逻辑体 ----
            LogicManagerV2.SaveToFile(logic);

            Debug.Log($"[LogicPrefabExtractor] ✅ 提取完成: {logic.GetDisplayName()}");
            return logic;
        }

        // ============================================================
        // 清理组件（只保留核心组件）
        // ============================================================
        private static void CleanComponents(GameObject obj)
        {
            // 获取所有 MonoBehaviour 脚本（非核心组件）
            MonoBehaviour[] scripts = obj.GetComponentsInChildren<MonoBehaviour>(true);
            foreach (var script in scripts)
            {
                // 跳过核心组件
                if (script is Transform) continue;
                if (script is MeshFilter) continue;
                if (script is MeshRenderer) continue;
                if (script is SkinnedMeshRenderer) continue;
                if (script is Collider) continue;
                if (script is Rigidbody) continue;
                if (script is Animation) continue;
                if (script is Animator) continue;
                if (script is AudioSource) continue;

                // 移除其他脚本（可能是游戏逻辑脚本）
                UnityEngine.Object.Destroy(script);
            }
        }

        // ============================================================
        // 提取 Mesh
        // ============================================================
        private static void ExtractMeshes(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            MeshFilter[] filters = obj.GetComponentsInChildren<MeshFilter>(true);
            foreach (var filter in filters)
            {
                if (filter == null || filter.mesh == null) continue;

                // 生成 .obj 文件
                string meshName = filter.mesh.name;
                if (string.IsNullOrEmpty(meshName) || meshName == "Mesh") meshName = "mesh_" + Guid.NewGuid().ToString().Substring(0, 6);

                string path = Path.Combine(outputDir, meshName + ".obj");
                string relativePath = $"models/{meshName}.obj";

                // 保存为 OBJ 格式
                string objContent = MeshToObj(filter.mesh);
                File.WriteAllText(path, objContent);

                // 更新资源引用
                if (string.IsNullOrEmpty(logic.resources.Model))
                {
                    logic.resources.Model = relativePath;
                }

                Debug.Log($"[LogicPrefabExtractor] 🎨 提取模型: {meshName} -> {relativePath}");
            }

            // 处理 SkinnedMeshRenderer
            SkinnedMeshRenderer[] skinned = obj.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in skinned)
            {
                if (smr == null || smr.sharedMesh == null) continue;

                string meshName = smr.sharedMesh.name;
                if (string.IsNullOrEmpty(meshName) || meshName == "Mesh") meshName = "skinned_" + Guid.NewGuid().ToString().Substring(0, 6);

                string path = Path.Combine(outputDir, meshName + ".obj");
                string relativePath = $"models/{meshName}.obj";

                string objContent = MeshToObj(smr.sharedMesh);
                File.WriteAllText(path, objContent);

                if (string.IsNullOrEmpty(logic.resources.Model))
                {
                    logic.resources.Model = relativePath;
                }

                Debug.Log($"[LogicPrefabExtractor] 🎨 提取蒙皮模型: {meshName} -> {relativePath}");
            }
        }

        // ============================================================
        // 提取纹理
        // ============================================================
        private static void ExtractTextures(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            HashSet<string> added = new HashSet<string>();

            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;

                foreach (var mat in renderer.sharedMaterials)
                {
                    if (mat == null) continue;
                    if (mat.mainTexture != null)
                    {
                        Texture2D tex = mat.mainTexture as Texture2D;
                        if (tex != null && !added.Contains(tex.name))
                        {
                            added.Add(tex.name);
                            string texName = tex.name;
                            string path = Path.Combine(outputDir, texName + ".png");
                            string relativePath = $"textures/{texName}.png";

                            // 保存纹理为 PNG（运行时需要编码器）
                            try
                            {
                                byte[] pngData = tex.EncodeToPNG();
                                if (pngData != null && pngData.Length > 0)
                                {
                                    File.WriteAllBytes(path, pngData);
                                    logic.resources.Textures.Add(relativePath);
                                    Debug.Log($"[LogicPrefabExtractor] 🖼️ 提取纹理: {texName} -> {relativePath}");
                                }
                            }
                            catch (Exception ex)
                            {
                                Debug.LogWarning($"[LogicPrefabExtractor] ⚠️ 无法保存纹理 {texName}: {ex.Message}");
                            }
                        }
                    }
                }
            }
        }

        // ============================================================
        // 提取音频
        // ============================================================
        private static void ExtractAudio(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            AudioSource[] sources = obj.GetComponentsInChildren<AudioSource>(true);
            HashSet<string> added = new HashSet<string>();

            foreach (var source in sources)
            {
                if (source == null || source.clip == null) continue;

                AudioClip clip = source.clip;
                if (!added.Contains(clip.name))
                {
                    added.Add(clip.name);
                    string clipName = clip.name;
                    string path = Path.Combine(outputDir, clipName + ".wav");
                    string relativePath = $"audio/{clipName}.wav";

                    // 运行时无法直接保存音频为 WAV，只能记录引用
                    // 但我们可以创建一个空的占位文件或记录资源路径
                    // 这里先记录到逻辑体

                    logic.resources.Audio.Add(relativePath);
                    Debug.Log($"[LogicPrefabExtractor] 🔊 记录音频: {clipName} -> {relativePath}");
                }
            }
        }

        // ============================================================
        // 提取材质
        // ============================================================
        private static void ExtractMaterials(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            HashSet<string> added = new HashSet<string>();

            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;

                foreach (var mat in renderer.sharedMaterials)
                {
                    if (mat == null) continue;
                    if (!added.Contains(mat.name))
                    {
                        added.Add(mat.name);
                        string matName = mat.name;
                        string path = Path.Combine(outputDir, matName + ".mat");
                        string relativePath = $"materials/{matName}.mat";

                        // 保存材质为 YAML 文本（Unity 的 .mat 格式）
                        SaveMaterialAsText(mat, path);

                        logic.resources.Materials.Add(relativePath);
                        Debug.Log($"[LogicPrefabExtractor] 🧪 提取材质: {matName} -> {relativePath}");
                    }
                }
            }
        }

        // ============================================================
        // 提取动画
        // ============================================================
        private static void ExtractAnimations(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            Animation anim = obj.GetComponent<Animation>();
            if (anim != null)
            {
                foreach (AnimationState state in anim)
                {
                    if (state == null || state.clip == null) continue;

                    string clipName = state.clip.name;
                    string path = Path.Combine(outputDir, clipName + ".anim");
                    string relativePath = $"animations/{clipName}.anim";

                    // 保存动画为 YAML 文本
                    SaveAnimationAsText(state.clip, path);

                    logic.resources.Animations.Add(relativePath);
                    Debug.Log($"[LogicPrefabExtractor] 🎬 提取动画: {clipName} -> {relativePath}");
                }
            }

            Animator animator = obj.GetComponent<Animator>();
            if (animator != null && animator.runtimeAnimatorController != null)
            {
                // 记录动画控制器
                Debug.Log($"[LogicPrefabExtractor] 🎬 检测到 Animator Controller: {animator.runtimeAnimatorController.name}");
            }
        }

        // ============================================================
        // 将 Mesh 转为 OBJ 格式
        // ============================================================
        private static string MeshToObj(Mesh mesh)
        {
            if (mesh == null) return "";

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("# Extracted by SuperConsole");
            sb.AppendLine($"# Mesh: {mesh.name}");

            // 顶点
            foreach (Vector3 v in mesh.vertices)
            {
                sb.AppendLine($"v {v.x:F6} {v.y:F6} {v.z:F6}");
            }

            // UV
            if (mesh.uv.Length > 0)
            {
                foreach (Vector2 uv in mesh.uv)
                {
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");
                }
            }
            else if (mesh.uv2.Length > 0)
            {
                foreach (Vector2 uv in mesh.uv2)
                {
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");
                }
            }

            // 法线
            foreach (Vector3 n in mesh.normals)
            {
                sb.AppendLine($"vn {n.x:F6} {n.y:F6} {n.z:F6}");
            }

            // 面
            int[] triangles = mesh.triangles;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int v1 = triangles[i] + 1;
                int v2 = triangles[i + 1] + 1;
                int v3 = triangles[i + 2] + 1;

                if (mesh.uv.Length > 0)
                {
                    sb.AppendLine($"f {v1}/{v1} {v2}/{v2} {v3}/{v3}");
                }
                else
                {
                    sb.AppendLine($"f {v1} {v2} {v3}");
                }
            }

            return sb.ToString();
        }

        // ============================================================
        // 保存材质为 YAML 文本
        // ============================================================
        private static void SaveMaterialAsText(Material mat, string path)
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine($"%YAML 1.1");
                sb.AppendLine($"%TAG !u! tag:unity3d.com,2011:");
                sb.AppendLine($"--- !u!21 &2100000");
                sb.AppendLine($"Material:");
                sb.AppendLine($"  serializedVersion: 6");
                sb.AppendLine($"  m_Name: {mat.name}");
                sb.AppendLine($"  m_Shader: {{fileID: 4800000, guid: {GetShaderGuid(mat.shader)}, type: 3}}");

                // 记录主要属性
                if (mat.HasProperty("_Color"))
                {
                    Color c = mat.GetColor("_Color");
                    sb.AppendLine($"  m_Colors:");
                    sb.AppendLine($"  - _Color: {{r: {c.r:F4}, g: {c.g:F4}, b: {c.b:F4}, a: {c.a:F4}}}");
                }

                if (mat.HasProperty("_MainTex") && mat.mainTexture != null)
                {
                    sb.AppendLine($"  m_Textures:");
                    sb.AppendLine($"  - _MainTex: {{fileID: 2800000, guid: {mat.mainTexture.name}, type: 3}}");
                }

                File.WriteAllText(path, sb.ToString());
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicPrefabExtractor] ⚠️ 无法保存材质 {mat.name}: {ex.Message}");
            }
        }

        // ============================================================
        // 保存动画为 YAML 文本
        // ============================================================
        private static void SaveAnimationAsText(AnimationClip clip, string path)
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine($"%YAML 1.1");
                sb.AppendLine($"%TAG !u! tag:unity3d.com,2011:");
                sb.AppendLine($"--- !u!74 &7400000");
                sb.AppendLine($"AnimationClip:");
                sb.AppendLine($"  m_Name: {clip.name}");
                sb.AppendLine($"  m_FrameRate: {clip.frameRate:F2}");
                sb.AppendLine($"  m_LoopTime: {(clip.isLooping ? 1 : 0)}");

                // 记录时长
                sb.AppendLine($"  m_Motion:");
                sb.AppendLine($"    m_Length: {clip.length:F4}");

                if (clip.events.Length > 0)
                {
                    sb.AppendLine($"  m_Events:");
                    foreach (var evt in clip.events)
                    {
                        sb.AppendLine($"  - time: {evt.time:F4}");
                        sb.AppendLine($"    functionName: {evt.functionName}");
                        sb.AppendLine($"    stringParameter: {evt.stringParameter}");
                        sb.AppendLine($"    floatParameter: {evt.floatParameter:F4}");
                        sb.AppendLine($"    intParameter: {evt.intParameter}");
                    }
                }

                File.WriteAllText(path, sb.ToString());
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicPrefabExtractor] ⚠️ 无法保存动画 {clip.name}: {ex.Message}");
            }
        }

        // ============================================================
        // 获取 Shader GUID
        // ============================================================
        private static string GetShaderGuid(Shader shader)
        {
            if (shader == null) return "00000000000000000000000000000000";

            // 常见 Shader 的 GUID
            Dictionary<string, string> shaderGuids = new Dictionary<string, string>
            {
                { "Standard", "0b858cefaa35b4aac80ac717755a0527" },
                { "Unlit/Color", "0b858cefaa35b4aac80ac717755a0528" },
                { "Unlit/Texture", "0b858cefaa35b4aac80ac717755a0529" },
                { "Unlit/Transparent", "0b858cefaa35b4aac80ac717755a0530" },
                { "Sprites/Default", "0b858cefaa35b4aac80ac717755a0531" },
                { "UI/Default", "0b858cefaa35b4aac80ac717755a0532" }
            };

            if (shaderGuids.ContainsKey(shader.name))
                return shaderGuids[shader.name];

            return "00000000000000000000000000000000";
        }
    }
}
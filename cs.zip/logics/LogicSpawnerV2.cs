﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using BepInEx;

namespace SuperConsole
{
    public static class LogicSpawnerV2
    {
        public static GameObject SpawnAtPlayer(string id)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player == null) { Debug.LogError("[LogicSpawnerV2] ❌ 找不到玩家"); return null; }
            return SpawnAtPosition(logic, player.transform.position);
        }

        public static GameObject SpawnAtCoordinates(string id, Vector3 position)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }
            return SpawnAtPosition(logic, position);
        }

        public static GameObject SpawnAtMouse(string id)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }

            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit)) return SpawnAtPosition(logic, hit.point);

            Debug.LogWarning("[LogicSpawnerV2] ⚠️ 没有点击到任何物体，使用摄像机前位置");
            Vector3 pos = Camera.main.transform.position + Camera.main.transform.forward * 2f;
            return SpawnAtPosition(logic, pos);
        }

        private static GameObject SpawnAtPosition(LogicEntityV2 logic, Vector3 position)
        {
            if (logic == null) return null;

            GameObject prefab = LoadPrefab(logic);
            if (prefab == null)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 无法加载预制体，使用占位 Cube");
                prefab = GameObject.CreatePrimitive(PrimitiveType.Cube);
            }

            GameObject instance = UnityEngine.Object.Instantiate(prefab, position, Quaternion.identity);
            instance.name = logic.GetDisplayName() + "_" + logic.id;
            instance.SetActive(logic.enabled);

            // ---- 应用所有资源 ----
            ApplyModel(instance, logic);
            ApplyTextures(instance, logic);
            ApplyMaterials(instance, logic);
            ApplyAnimations(instance, logic);

            // ---- 加载 DLL 扩展 ----
            if (!string.IsNullOrEmpty(logic.resources.DLL))
            {
                LogicDLLLoader.AttachComponents(instance, logic);
                LogicDLLLoader.Initialize(instance, logic);
            }

            Debug.Log($"[LogicSpawnerV2] 🚀 召唤逻辑体: {logic.GetDisplayName()} -> {position}");
            return instance;
        }

        private static GameObject LoadPrefab(LogicEntityV2 logic)
        {
            if (string.IsNullOrEmpty(logic.resources.Prefab)) return null;

            // 1. 从逻辑体文件夹加载
            GameObject prefab = LogicPrefabSaver.LoadPrefab(logic.FolderPath, "main");
            if (prefab != null) return prefab;

            // 2. 从本地 Assets/Prefabs 加载
            string localPath = Path.Combine(LogicResourceLoader.GetPrefabsPath(), Path.GetFileName(logic.resources.Prefab));
            prefab = LogicResourceLoader.LoadPrefab(localPath);
            if (prefab != null) return prefab;

            // 3. 从 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(logic.resources.Prefab);
            GameObject resourcePrefab = Resources.Load<GameObject>(resourceName);
            if (resourcePrefab != null) return resourcePrefab;

            return null;
        }

        // ============================================================
        // 1. 应用模型 (从 .obj 加载 Mesh)
        // ============================================================
        private static void ApplyModel(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (string.IsNullOrEmpty(logic.resources.Model)) return;

                // 使用 LogicResourceLoader 统一加载（自动识别路径）
                Mesh mesh = LogicResourceLoader.LoadMesh(logic.resources.Model, logic.FolderPath);
                if (mesh == null)
                {
                    Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 加载模型失败: {logic.resources.Model}");
                    return;
                }

                // 检查是否已有 MeshFilter
                MeshFilter filter = instance.GetComponent<MeshFilter>();
                if (filter == null) filter = instance.AddComponent<MeshFilter>();
                filter.mesh = mesh;

                // 确保有 Renderer
                MeshRenderer renderer = instance.GetComponent<MeshRenderer>();
                if (renderer == null) renderer = instance.AddComponent<MeshRenderer>();

                // 如果有纹理，先创建材质
                if (logic.resources.Textures != null && logic.resources.Textures.Count > 0)
                {
                    // 纹理会在 ApplyTextures 里应用
                }
                else
                {
                    // 没有纹理，用默认材质
                    if (renderer.material == null || renderer.material.shader == null)
                        renderer.material = new Material(Shader.Find("Standard"));
                }

                Debug.Log($"[LogicSpawnerV2] 🎨 应用模型: {logic.resources.Model}");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用模型失败: {ex.Message}");
            }
        }

        // ============================================================
        // 2. 应用纹理 (从 .png 加载 Texture2D)
        // ============================================================
        private static void ApplyTextures(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (logic.resources.Textures == null || logic.resources.Textures.Count == 0) return;

                Renderer renderer = instance.GetComponent<Renderer>();
                if (renderer == null) return;

                // 如果没有材质，创建一个
                if (renderer.material == null || renderer.material.shader == null)
                    renderer.material = new Material(Shader.Find("Standard"));

                foreach (string texPath in logic.resources.Textures)
                {
                    // 使用 LogicResourceLoader 统一加载
                    Texture2D tex = LogicResourceLoader.LoadTexture(texPath, logic.FolderPath);
                    if (tex != null)
                    {
                        renderer.material.mainTexture = tex;
                        renderer.material.SetTexture("_MainTex", tex);
                        Debug.Log($"[LogicSpawnerV2] 🖼️ 应用纹理: {texPath} ({tex.width}x{tex.height})");
                        return; // 只应用第一个纹理作为主纹理
                    }
                    else
                    {
                        Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 加载纹理失败: {texPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用纹理失败: {ex.Message}");
            }
        }

        // ============================================================
        // 3. 应用材质 (从 .mat 加载 Material)
        // ============================================================
        private static void ApplyMaterials(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (logic.resources.Materials == null || logic.resources.Materials.Count == 0) return;

                Renderer renderer = instance.GetComponent<Renderer>();
                if (renderer == null) return;

                foreach (string matPath in logic.resources.Materials)
                {
                    // 使用 LogicResourceLoader 统一加载
                    Material mat = LogicResourceLoader.LoadMaterial(matPath, logic.FolderPath);
                    if (mat != null)
                    {
                        renderer.material = mat;
                        Debug.Log($"[LogicSpawnerV2] 🧪 应用材质: {matPath}");
                        return; // 只应用第一个材质
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用材质失败: {ex.Message}");
            }
        }

        // ============================================================
        // 4. 应用动画 (从 .anim 加载 AnimationClip)
        // ============================================================
        private static void ApplyAnimations(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (logic.resources.Animations == null || logic.resources.Animations.Count == 0) return;

                Animation anim = instance.GetComponent<Animation>();
                if (anim == null) anim = instance.AddComponent<Animation>();

                foreach (string animPath in logic.resources.Animations)
                {
                    // 使用 LogicResourceLoader 统一加载
                    AnimationClip clip = LogicResourceLoader.LoadAnimation(animPath, logic.FolderPath);
                    if (clip != null)
                    {
                        anim.AddClip(clip, clip.name);
                        // 默认播放第一个动画
                        if (anim.clip == null)
                        {
                            anim.clip = clip;
                            anim.Play();
                        }
                        Debug.Log($"[LogicSpawnerV2] 🎬 应用动画: {animPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用动画失败: {ex.Message}");
            }
        }

        // ============================================================
        // 批量召唤
        // ============================================================
        public static void SpawnMultiple(string id, Vector3 center, int count, float radius)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return; }

            for (int i = 0; i < count; i++)
            {
                Vector3 offset = UnityEngine.Random.insideUnitSphere * radius;
                offset.y = Mathf.Abs(offset.y);
                SpawnAtPosition(logic, center + offset);
            }
            Debug.Log($"[LogicSpawnerV2] 📊 批量召唤 {count} 个 {logic.GetDisplayName()}");
        }
    }
}
﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Resources;
using System.Runtime.Remoting.Messaging;
using UnityEngine;
using UnityEngine.Networking;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using Debug = UnityEngine.Debug;

namespace SuperConsole
{
    public class AssetEntry
    {
        public string Name;
        public string Path;
        public string Type;
        public string Extension;
        public GameObject GameObject;
        public Texture2D Texture;
        public AudioClip AudioClip;
        public Material Material;
        public AnimationClip AnimationClip;
        public DateTime LoadedTime;
        public bool IsLoaded;
        public AssetBundle Bundle;
        public List<UnityEngine.Object> BundleAssets = new List<UnityEngine.Object>();
    }

    public static class AssetManager
    {
        private static string assetPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
        private static List<AssetEntry> loadedAssets = new List<AssetEntry>();

        private static HashSet<string> modelExtensions = new HashSet<string>
        { ".obj", ".fbx", ".dae", ".3ds", ".blend", ".gltf", ".glb", ".stl", ".ply" };
        private static HashSet<string> textureExtensions = new HashSet<string>
        { ".png", ".jpg", ".jpeg", ".tga", ".bmp", ".dds", ".tif", ".tiff", ".gif", ".svg", ".psd" };
        private static HashSet<string> audioExtensions = new HashSet<string>
        { ".wav", ".mp3", ".ogg", ".aiff", ".aif", ".flac" };
        private static HashSet<string> prefabExtensions = new HashSet<string> { ".prefab" };
        private static HashSet<string> animationExtensions = new HashSet<string> { ".anim" };
        private static HashSet<string> materialExtensions = new HashSet<string> { ".mat" };
        private static HashSet<string> bundleExtensions = new HashSet<string> { ".unity3d", ".assetbundle" };

        static AssetManager() { EnsureDirectories(); ScanAllAssets(); }

        private static void EnsureDirectories()
        {
            if (!Directory.Exists(assetPath)) Directory.CreateDirectory(assetPath);
            string[] subDirs = { "Models", "Textures", "Audio", "Prefabs", "Animations", "Materials" };
            foreach (var dir in subDirs)
            {
                string fullPath = Path.Combine(assetPath, dir);
                if (!Directory.Exists(fullPath)) Directory.CreateDirectory(fullPath);
            }
        }

        public static void ScanAllAssets()
        {
            loadedAssets.Clear();
            Debug.Log("[AssetManager] 🔄 Scanning assets...");
            ScanDirectory(Path.Combine(assetPath, "Models"), "model");
            ScanDirectory(Path.Combine(assetPath, "Textures"), "texture");
            ScanDirectory(Path.Combine(assetPath, "Audio"), "audio");
            ScanDirectory(Path.Combine(assetPath, "Prefabs"), "prefab");
            ScanDirectory(Path.Combine(assetPath, "Animations"), "animation");
            ScanDirectory(Path.Combine(assetPath, "Materials"), "material");
            ScanDirectory(assetPath, "unknown");
            Debug.Log("[AssetManager] ✅ Scan complete, found " + loadedAssets.Count + " assets");
        }

        private static void ScanDirectory(string dir, string defaultType)
        {
            if (!Directory.Exists(dir)) return;
            foreach (string file in Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories))
            {
                try
                {
                    string ext = Path.GetExtension(file).ToLower();
                    string type = GetAssetType(ext);
                    if (type == "unknown") continue;
                    var entry = new AssetEntry
                    {
                        Name = Path.GetFileNameWithoutExtension(file),
                        Path = file,
                        Type = type,
                        Extension = ext,
                        IsLoaded = false
                    };
                    loadedAssets.Add(entry);
                }
                catch (Exception ex) { Debug.LogWarning("[AssetManager] ⚠️ Skipping file: " + file + " - " + ex.Message); }
            }
        }

        private static string GetAssetType(string ext)
        {
            if (modelExtensions.Contains(ext)) return "model";
            if (textureExtensions.Contains(ext)) return "texture";
            if (audioExtensions.Contains(ext)) return "audio";
            if (prefabExtensions.Contains(ext)) return "prefab";
            if (animationExtensions.Contains(ext)) return "animation";
            if (materialExtensions.Contains(ext)) return "material";
            if (bundleExtensions.Contains(ext)) return "bundle";
            return "unknown";
        }

        public static AssetEntry LoadAsset(string name)
        {
            var entry = loadedAssets.FirstOrDefault(a => a.Name == name);
            if (entry == null) { Debug.LogWarning("[AssetManager] ⚠️ Asset not found: " + name); return null; }
            if (entry.IsLoaded) return entry;

            try
            {
                switch (entry.Type)
                {
                    case "model": LoadModel(entry); break;
                    case "texture": LoadTexture(entry); break;
                    case "audio": LoadAudio(entry); break;
                    case "prefab": LoadPrefab(entry); break;
                    case "animation": LoadAnimation(entry); break;
                    case "material": LoadMaterial(entry); break;
                    case "bundle": LoadBundle(entry); break;
                }
                entry.IsLoaded = true;
                entry.LoadedTime = DateTime.Now;
                Debug.Log("[AssetManager] ✅ Loaded asset: " + entry.Name + " (" + entry.Type + ")");
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Load failed: " + entry.Name + " - " + ex.Message); }
            return entry;
        }

        private static void LoadModel(AssetEntry entry)
        {
            GameObject obj = new GameObject(entry.Name);
            MeshFilter filter = obj.AddComponent<MeshFilter>();
            MeshRenderer renderer = obj.AddComponent<MeshRenderer>();
            Mesh mesh = null;

            try { if (entry.Extension != ".obj") mesh = Resources.Load<Mesh>(entry.Name); } catch { }
            if (entry.Extension == ".obj") mesh = ObjImporter.Import(entry.Path);

            if (mesh != null) filter.mesh = mesh;
            else { filter.mesh = CreateDefaultMesh(); Debug.LogWarning("[AssetManager] ⚠️ Could not load model " + entry.Name + ", using default mesh."); }
            entry.GameObject = obj;
        }

        private static void LoadTexture(AssetEntry entry)
        {
            try
            {
                byte[] fileData = File.ReadAllBytes(entry.Path);
                Texture2D texture = new Texture2D(2, 2);
                if (ImageConversion.LoadImage(texture, fileData))
                {
                    entry.Texture = texture;
                    Debug.Log("[AssetManager] 📸 Texture loaded: " + entry.Name + " (" + texture.width + "x" + texture.height + ")");
                }
                else Debug.LogWarning("[AssetManager] ⚠️ Failed to load texture: " + entry.Name);
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Texture load error: " + entry.Name + " - " + ex.Message); }
        }

        private static void LoadAudio(AssetEntry entry)
        {
            try
            {
                string url = "file://" + entry.Path.Replace("\\", "/");
                using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url, AudioType.UNKNOWN))
                {
                    www.SendWebRequest();
                    while (!www.isDone) { }
                    if (www.result == UnityWebRequest.Result.Success)
                    {
                        entry.AudioClip = DownloadHandlerAudioClip.GetContent(www);
                        Debug.Log("[AssetManager] 🔊 Audio loaded: " + entry.Name + " (" + entry.AudioClip.length + "s)");
                    }
                    else Debug.LogWarning("[AssetManager] ⚠️ Audio load failed: " + entry.Name + " - " + www.error);
                }
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Audio load error: " + entry.Name + " - " + ex.Message); }
        }

        private static void LoadPrefab(AssetEntry entry)
        {
            try
            {
                GameObject prefab = Resources.Load<GameObject>(entry.Name);
                if (prefab != null) { entry.GameObject = prefab; Debug.Log("[AssetManager] 📦 Prefab loaded: " + entry.Name); return; }
                entry.GameObject = new GameObject(entry.Name);
                Debug.LogWarning("[AssetManager] ⚠️ Could not load prefab " + entry.Name + " from Resources.");
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Prefab load failed: " + entry.Name + " - " + ex.Message); }
        }

        private static void LoadAnimation(AssetEntry entry)
        {
            try
            {
                AnimationClip clip = Resources.Load<AnimationClip>(entry.Name);
                if (clip != null) { entry.AnimationClip = clip; Debug.Log("[AssetManager] 🎬 Animation loaded: " + entry.Name); }
                else { entry.AnimationClip = new AnimationClip(); entry.AnimationClip.name = entry.Name; Debug.LogWarning("[AssetManager] ⚠️ Could not load animation " + entry.Name + " from Resources."); }
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Animation load failed: " + entry.Name + " - " + ex.Message); }
        }

        private static void LoadMaterial(AssetEntry entry)
        {
            try
            {
                Material mat = Resources.Load<Material>(entry.Name);
                if (mat != null) { entry.Material = mat; Debug.Log("[AssetManager] 🧪 Material loaded: " + entry.Name); }
                else { entry.Material = new Material(Shader.Find("Standard")); entry.Material.name = entry.Name; Debug.LogWarning("[AssetManager] ⚠️ Could not load material " + entry.Name + " from Resources."); }
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Material load failed: " + entry.Name + " - " + ex.Message); }
        }

        private static void LoadBundle(AssetEntry entry)
        {
            try
            {
                AssetBundle bundle = AssetBundle.LoadFromFile(entry.Path);
                if (bundle != null)
                {
                    entry.Bundle = bundle;
                    entry.BundleAssets.Clear();
                    string[] assetNames = bundle.GetAllAssetNames();
                    Debug.Log("[AssetManager] 📦 Bundle loaded: " + entry.Name + ", contains " + assetNames.Length + " assets");
                    foreach (string name in assetNames)
                    {
                        try
                        {
                            UnityEngine.Object obj = bundle.LoadAsset(name);
                            if (obj != null)
                            {
                                entry.BundleAssets.Add(obj);
                                if (obj is GameObject go && entry.GameObject == null) entry.GameObject = go;
                            }
                        }
                        catch { }
                    }
                    entry.IsLoaded = true;
                    Debug.Log("[AssetManager] ✅ Bundle loaded: " + entry.Name + ", loaded " + entry.BundleAssets.Count + " assets");
                }
                else Debug.LogWarning("[AssetManager] ⚠️ Failed to load bundle: " + entry.Name);
            }
            catch (Exception ex) { Debug.LogError("[AssetManager] ❌ Bundle load failed: " + entry.Name + " - " + ex.Message); }
        }

        public static List<UnityEngine.Object> GetBundleAssets(string name)
        {
            var entry = loadedAssets.FirstOrDefault(a => a.Name == name && a.Type == "bundle");
            return (entry == null || !entry.IsLoaded) ? new List<UnityEngine.Object>() : entry.BundleAssets;
        }

        public static UnityEngine.Object LoadBundleAsset(string bundleName, string assetName)
        {
            var entry = loadedAssets.FirstOrDefault(a => a.Name == bundleName && a.Type == "bundle");
            if (entry == null || entry.Bundle == null) return null;
            try { return entry.Bundle.LoadAsset(assetName); } catch { return null; }
        }

        private static Mesh CreateDefaultMesh()
        {
            Mesh mesh = new Mesh();
            mesh.vertices = new Vector3[]
            {
                new Vector3(-0.5f, -0.5f, 0),
                new Vector3(0.5f, -0.5f, 0),
                new Vector3(0.5f, 0.5f, 0),
                new Vector3(-0.5f, 0.5f, 0)
            };
            mesh.triangles = new int[] { 0, 1, 2, 0, 2, 3 };
            mesh.uv = new Vector2[] { new Vector2(0, 0), new Vector2(1, 0), new Vector2(1, 1), new Vector2(0, 1) };
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        public static AssetEntry GetAsset(string name) => loadedAssets.FirstOrDefault(a => a.Name == name);
        public static List<AssetEntry> GetAssetsByType(string type) => loadedAssets.Where(a => a.Type == type).ToList();
        public static List<AssetEntry> GetAllAssets() => new List<AssetEntry>(loadedAssets);

        public static GameObject InstantiateAsset(string name, Vector3 position, Quaternion rotation)
        {
            var entry = LoadAsset(name);
            if (entry == null || entry.GameObject == null) { Debug.LogWarning("[AssetManager] ⚠️ Cannot instantiate: " + name); return null; }
            GameObject obj = UnityEngine.Object.Instantiate(entry.GameObject, position, rotation);
            obj.name = entry.Name + "_Instance";
            return obj;
        }

        // ============================================================
        // OBJ Importer - FIXED: StringSplitOptions
        // ============================================================
        private static class ObjImporter
        {
            public static Mesh Import(string path)
            {
                List<Vector3> vertices = new List<Vector3>();
                List<Vector2> uvs = new List<Vector2>();
                List<int> triangles = new List<int>();

                try
                {
                    string[] lines = File.ReadAllLines(path);
                    foreach (string line in lines)
                    {
                        string trimmed = line.Trim();
                        if (trimmed.StartsWith("v "))
                        {
                            string[] parts = trimmed.Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            if (parts.Length >= 3) vertices.Add(new Vector3(float.Parse(parts[0]), float.Parse(parts[1]), float.Parse(parts[2])));
                        }
                        else if (trimmed.StartsWith("vt "))
                        {
                            string[] parts = trimmed.Substring(3).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            if (parts.Length >= 2) uvs.Add(new Vector2(float.Parse(parts[0]), float.Parse(parts[1])));
                        }
                        else if (trimmed.StartsWith("f "))
                        {
                            string[] parts = trimmed.Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string part in parts)
                            {
                                string[] indices = part.Split('/');
                                if (indices.Length > 0 && !string.IsNullOrEmpty(indices[0]))
                                    triangles.Add(int.Parse(indices[0]) - 1);
                            }
                        }
                    }
                }
                catch (Exception ex) { Debug.LogError("[ObjImporter] OBJ import failed: " + ex.Message); return CreateDefaultMesh(); }

                if (vertices.Count == 0 || triangles.Count == 0)
                { Debug.LogWarning("[ObjImporter] ⚠️ OBJ has no valid data, using default mesh"); return CreateDefaultMesh(); }

                Mesh mesh = new Mesh();
                mesh.vertices = vertices.ToArray();
                mesh.triangles = triangles.ToArray();
                if (uvs.Count > 0) mesh.uv = uvs.ToArray();
                mesh.RecalculateNormals();
                mesh.RecalculateBounds();
                return mesh;
            }
        }
    }

    public static class AssetWindow
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(200, 200, 600, 450);
        private static Vector2 scrollPos = Vector2.zero;

        public static void Toggle() { visible = !visible; }
        public static bool IsVisible() => visible;

        public static void Draw()
        {
            if (!visible) return;
            windowRect = GUI.Window(12400, windowRect, DrawWindow, "📦 Asset Manager [Esc to close]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape) { visible = false; return; }

            GUILayout.BeginVertical();
            GUILayout.BeginHorizontal();
            GUILayout.Label("📦 Local Assets (" + AssetManager.GetAllAssets().Count + ")", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("🔄 Refresh", GUILayout.Width(50))) AssetManager.ScanAllAssets();
            if (GUILayout.Button("✖", GUILayout.Width(25))) visible = false;
            GUILayout.EndHorizontal();
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));
            foreach (var asset in AssetManager.GetAllAssets())
            {
                GUILayout.BeginHorizontal("box");
                string icon;
                switch (asset.Type)
                {
                    case "model": icon = "🎨"; break;
                    case "texture": icon = "🖼️"; break;
                    case "audio": icon = "🔊"; break;
                    case "prefab": icon = "📦"; break;
                    case "animation": icon = "🎬"; break;
                    case "material": icon = "🧪"; break;
                    case "bundle": icon = "📚"; break;
                    default: icon = "📄"; break;
                }
                GUILayout.Label(icon, GUILayout.Width(25));
                GUILayout.Label(asset.Name, GUILayout.Width(120));
                GUILayout.Label(asset.Type, GUILayout.Width(60));
                GUILayout.Label(asset.IsLoaded ? "✅" : "⏳", GUILayout.Width(30));
                if (GUILayout.Button("Load", GUILayout.Width(40))) AssetManager.LoadAsset(asset.Name);
                if (GUILayout.Button("Spawn", GUILayout.Width(40)))
                {
                    if (asset.Type == "model" || asset.Type == "prefab")
                    {
                        Camera cam = Camera.main;
                        if (cam != null)
                        {
                            var obj = AssetManager.InstantiateAsset(asset.Name, cam.transform.position + cam.transform.forward * 2, Quaternion.identity);
                            if (obj != null) Debug.Log("✅ Spawned: " + asset.Name);
                        }
                    }
                }
                if (asset.Type == "bundle" && asset.IsLoaded && GUILayout.Button("📋 List", GUILayout.Width(40)))
                {
                    var assets = AssetManager.GetBundleAssets(asset.Name);
                    Debug.Log("[AssetManager] Bundle '" + asset.Name + "' contains " + assets.Count + " assets:");
                    foreach (var a in assets) Debug.Log("  - " + a.name + " (" + a.GetType().Name + ")");
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label("📁 Asset directory: " + Path.Combine(Paths.PluginPath, "SuperConsole", "Assets"), GUILayout.ExpandWidth(true));
            if (GUILayout.Button("Close", GUILayout.Width(60))) visible = false;
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();
            GUI.DragWindow();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SuperConsole
{
    /// <summary>
    /// 带自动补全的输入框
    /// 用法: AutoCompleteInput.Draw("label", ref text, suggestions, ref showDropdown, ref selectedIndex, ref inputRect, params options)
    /// </summary>
    public static class AutoCompleteInput
    {
        // ===== 静态窗口 ID =====
        private static int dropdownWindowId = 9999;
        private static string dropdownResult = "";
        private static bool dropdownClosed = false;

        public static string Draw(string label, string currentText, List<string> suggestions,
            ref bool showDropdown, ref int selectedIndex, ref Rect inputRect, params GUILayoutOption[] options)
        {
            string result = currentText;
            dropdownResult = currentText;

            GUILayout.BeginHorizontal();

            if (!string.IsNullOrEmpty(label))
                GUILayout.Label(label, GUILayout.Width(30));

            GUI.SetNextControlName("autoComplete_" + label + "_" + Guid.NewGuid().ToString().Substring(0, 4));
            result = GUILayout.TextField(currentText, options);

            // 记录输入框位置
            if (Event.current.type == EventType.Repaint)
            {
                inputRect = GUILayoutUtility.GetLastRect();
            }

            if (result != currentText)
            {
                showDropdown = !string.IsNullOrEmpty(result) && suggestions.Any(s => s.ToLower().Contains(result.ToLower()));
                selectedIndex = -1;
                dropdownResult = result;
            }

            GUILayout.EndHorizontal();

            // 绘制浮动下拉菜单
            if (showDropdown && !string.IsNullOrEmpty(result) && inputRect != Rect.zero)
            {
                var matches = suggestions
                    .Where(s => s.ToLower().Contains(result.ToLower()))
                    .Take(10)
                    .ToList();

                if (matches.Count > 0)
                {
                    // 转换到屏幕坐标
                    Vector2 screenPos = GUIUtility.GUIToScreenPoint(new Vector2(inputRect.x, inputRect.y + inputRect.height));
                    Rect dropdownRect = new Rect(screenPos.x, screenPos.y, inputRect.width, Math.Min(matches.Count * 22, 150));

                    // 用临时变量捕获，避免 ref 问题
                    int localSelectedIndex = selectedIndex;
                    string localResult = result;
                    bool localShowDropdown = showDropdown;

                    // 使用 GUI.Window
                    GUI.Window(dropdownWindowId, dropdownRect, (id) =>
                    {
                        for (int i = 0; i < matches.Count; i++)
                        {
                            if (i == localSelectedIndex)
                                GUI.backgroundColor = new Color(0.3f, 0.5f, 0.8f);

                            if (GUILayout.Button(matches[i], GUILayout.ExpandWidth(true)))
                            {
                                // 选择后更新值
                                dropdownResult = matches[i];
                                dropdownClosed = true;
                                GUI.FocusControl(null);
                            }

                            GUI.backgroundColor = Color.white;
                        }
                    }, "", GUI.skin.box);

                    // 点击其他地方关闭下拉
                    if (Event.current.type == EventType.MouseDown && !dropdownRect.Contains(Event.current.mousePosition))
                    {
                        showDropdown = false;
                        selectedIndex = -1;
                    }

                    // 如果用户选择了，更新结果
                    if (dropdownClosed)
                    {
                        result = dropdownResult;
                        showDropdown = false;
                        selectedIndex = -1;
                        dropdownClosed = false;
                    }
                }
                else
                {
                    // 没有匹配项，关闭下拉
                    showDropdown = false;
                }
            }

            // 键盘事件
            if (showDropdown && Event.current.type == EventType.KeyDown)
            {
                var matches = suggestions
                    .Where(s => s.ToLower().Contains(result.ToLower()))
                    .Take(10)
                    .ToList();

                if (matches.Count > 0)
                {
                    if (Event.current.keyCode == KeyCode.DownArrow)
                    {
                        selectedIndex = Math.Min(selectedIndex + 1, matches.Count - 1);
                        Event.current.Use();
                    }
                    else if (Event.current.keyCode == KeyCode.UpArrow)
                    {
                        selectedIndex = Math.Max(selectedIndex - 1, 0);
                        Event.current.Use();
                    }
                    else if (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.Tab)
                    {
                        if (selectedIndex >= 0 && selectedIndex < matches.Count)
                        {
                            result = matches[selectedIndex];
                            showDropdown = false;
                            selectedIndex = -1;
                            GUI.FocusControl(null);
                            Event.current.Use();
                        }
                    }
                    else if (Event.current.keyCode == KeyCode.Escape)
                    {
                        showDropdown = false;
                        selectedIndex = -1;
                        Event.current.Use();
                    }
                }
            }

            return result;
        }

        // 重载：兼容旧调用方式
        public static string Draw(string label, string currentText, List<string> suggestions,
            ref bool showDropdown, ref int selectedIndex, params GUILayoutOption[] options)
        {
            Rect dummyRect = Rect.zero;
            return Draw(label, currentText, suggestions, ref showDropdown, ref selectedIndex, ref dummyRect, options);
        }
    }
}
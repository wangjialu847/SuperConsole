﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SuperConsole
{
    public class AssetInfo
    {
        public string Name;
        public string Type;
        public UnityEngine.Object Asset;
        public GameObject Owner;
        public string OwnerName;
        public string Path;
    }

    public static class GameAssetBrowser
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 750, 550);
        private static Vector2 scrollPos = Vector2.zero;
        private static string searchText = "";
        private static int currentTab = 0;
        private static List<AssetInfo> assets = new List<AssetInfo>();
        private static List<AssetInfo> filteredAssets = new List<AssetInfo>();

        public static Rect GetWindowRect()
        {
            return windowRect;
        }

        public static void ResetPosition()
        {
            windowRect = new Rect(100, 100, 750, 550);
        }

        public static void Toggle() { visible = !visible; if (visible) Scan(); }
        public static bool IsVisible() => visible;

        public static void Scan()
        {
            assets.Clear();
            var added = new HashSet<string>();

            try
            {
                GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
                foreach (var obj in allObjects)
                {
                    if (obj == null || string.IsNullOrEmpty(obj.scene.name)) continue;

                    foreach (var renderer in obj.GetComponentsInChildren<Renderer>())
                    {
                        if (renderer == null) continue;
                        foreach (var mat in renderer.sharedMaterials)
                        {
                            if (mat == null || mat.mainTexture == null) continue;
                            string key = "tex_" + mat.mainTexture.name;
                            if (!added.Contains(key))
                            {
                                added.Add(key);
                                assets.Add(new AssetInfo
                                {
                                    Name = mat.mainTexture.name,
                                    Type = "Texture",
                                    Asset = mat.mainTexture,
                                    Owner = obj,
                                    OwnerName = obj.name
                                });
                            }
                        }
                    }

                    foreach (var mf in obj.GetComponentsInChildren<MeshFilter>())
                    {
                        if (mf == null || mf.mesh == null) continue;
                        string key = "mesh_" + mf.mesh.name;
                        if (!added.Contains(key))
                        {
                            added.Add(key);
                            assets.Add(new AssetInfo
                            {
                                Name = mf.mesh.name,
                                Type = "Mesh",
                                Asset = mf.mesh,
                                Owner = obj,
                                OwnerName = obj.name
                            });
                        }
                    }

                    foreach (var audio in obj.GetComponentsInChildren<AudioSource>())
                    {
                        if (audio == null || audio.clip == null) continue;
                        string key = "audio_" + audio.clip.name;
                        if (!added.Contains(key))
                        {
                            added.Add(key);
                            assets.Add(new AssetInfo
                            {
                                Name = audio.clip.name,
                                Type = "AudioClip",
                                Asset = audio.clip,
                                Owner = obj,
                                OwnerName = obj.name
                            });
                        }
                    }

                    foreach (var renderer in obj.GetComponentsInChildren<Renderer>())
                    {
                        if (renderer == null) continue;
                        foreach (var mat in renderer.sharedMaterials)
                        {
                            if (mat == null) continue;
                            string key = "mat_" + mat.name;
                            if (!added.Contains(key))
                            {
                                added.Add(key);
                                assets.Add(new AssetInfo
                                {
                                    Name = mat.name,
                                    Type = "Material",
                                    Asset = mat,
                                    Owner = obj,
                                    OwnerName = obj.name
                                });
                            }
                        }
                    }

                    foreach (var anim in obj.GetComponentsInChildren<Animation>())
                    {
                        if (anim == null) continue;
                        foreach (AnimationState state in anim)
                        {
                            if (state == null || state.clip == null) continue;
                            string key = "anim_" + state.clip.name;
                            if (!added.Contains(key))
                            {
                                added.Add(key);
                                assets.Add(new AssetInfo
                                {
                                    Name = state.clip.name,
                                    Type = "AnimationClip",
                                    Asset = state.clip,
                                    Owner = obj,
                                    OwnerName = obj.name
                                });
                            }
                        }
                    }

                    foreach (var animator in obj.GetComponentsInChildren<Animator>())
                    {
                        if (animator == null) continue;
                        var clips = animator.runtimeAnimatorController?.animationClips;
                        if (clips == null) continue;
                        foreach (var clip in clips)
                        {
                            if (clip == null) continue;
                            string key = "anim_" + clip.name;
                            if (!added.Contains(key))
                            {
                                added.Add(key);
                                assets.Add(new AssetInfo
                                {
                                    Name = clip.name,
                                    Type = "AnimationClip",
                                    Asset = clip,
                                    Owner = obj,
                                    OwnerName = obj.name
                                });
                            }
                        }
                    }
                }
                Debug.Log("[GameAssetBrowser] 扫描完成，找到 " + assets.Count + " 个资源");
                ApplyFilter();
            }
            catch (Exception ex) { Debug.LogError("[GameAssetBrowser] 扫描失败: " + ex.Message); }
        }

        private static void ApplyFilter()
        {
            filteredAssets = assets;
            string typeFilter = "";
            switch (currentTab)
            {
                case 1: typeFilter = "Texture"; break;
                case 2: typeFilter = "Mesh"; break;
                case 3: typeFilter = "AudioClip"; break;
                case 4: typeFilter = "Material"; break;
                case 5: typeFilter = "AnimationClip"; break;
            }
            if (!string.IsNullOrEmpty(typeFilter))
                filteredAssets = filteredAssets.Where(a => a.Type == typeFilter).ToList();
            if (!string.IsNullOrEmpty(searchText))
            {
                string s = searchText.ToLower();
                filteredAssets = filteredAssets.Where(a =>
                    a.Name.ToLower().Contains(s) ||
                    (a.OwnerName != null && a.OwnerName.ToLower().Contains(s))
                ).ToList();
            }
            filteredAssets = filteredAssets.OrderBy(a => a.Type).ThenBy(a => a.Name).ToList();
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12353);
            windowRect = GUI.Window(12353, windowRect, DrawWindow, "游戏资源提取器 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            // ❌ 删除所有 GUI.FocusControl 调用
            // 焦点由 SuperConsole.OnGUI() 统一管理

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            string[] tabs = { "全部", "纹理", "模型", "音频", "材质", "动画" };
            int newTab = GUILayout.SelectionGrid(currentTab, tabs, 6, GUILayout.ExpandWidth(true));
            if (newTab != currentTab) { currentTab = newTab; ApplyFilter(); }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(45));
            GUI.SetNextControlName("assetSearch");
            string newSearch = GUILayout.TextField(searchText, GUILayout.ExpandWidth(true));
            if (newSearch != searchText) { searchText = newSearch; ApplyFilter(); }
            if (GUILayout.Button("刷新", GUILayout.Width(50))) Scan();
            if (GUILayout.Button("关闭", GUILayout.Width(25))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("共 " + filteredAssets.Count + " 个资源", GUILayout.ExpandWidth(true));
            GUILayout.Label("纹理:" + assets.Count(a => a.Type == "Texture") + " 模型:" + assets.Count(a => a.Type == "Mesh") + " 音频:" + assets.Count(a => a.Type == "AudioClip") + " 材质:" + assets.Count(a => a.Type == "Material") + " 动画:" + assets.Count(a => a.Type == "AnimationClip"));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));
            if (filteredAssets.Count == 0)
                GUILayout.Label("没有找到资源，点击「刷新」扫描");
            else
            {
                foreach (var asset in filteredAssets)
                {
                    GUILayout.BeginHorizontal("box");
                    string icon = asset.Type == "Texture" ? "▣" : asset.Type == "Mesh" ? "◆" : asset.Type == "AudioClip" ? "♪" : asset.Type == "Material" ? "●" : asset.Type == "AnimationClip" ? "▶" : "·";
                    GUILayout.Label(icon, GUILayout.Width(25));
                    GUILayout.Label(asset.Name, GUILayout.Width(150));
                    GUILayout.Label(asset.Type, GUILayout.Width(80));
                    string ownerName = asset.OwnerName ?? "无";
                    if (ownerName.Length > 35) ownerName = ownerName.Substring(0, 32) + "...";
                    GUILayout.Label(ownerName, GUILayout.ExpandWidth(true));
                    if (GUILayout.Button("提取", GUILayout.Width(50))) ExtractAsset(asset);
                    if (GUILayout.Button("定位", GUILayout.Width(50)))
                        if (asset.Owner != null) Debug.Log("[GameAssetBrowser] 已定位: " + asset.OwnerName);
                    GUILayout.EndHorizontal();
                }
            }
            GUILayout.EndScrollView();
            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private static void ExtractAsset(AssetInfo asset)
        {
            try
            {
                if (asset.Asset == null) { Debug.Log("[GameAssetBrowser] 资源为空: " + asset.Name); return; }
                Debug.Log("[GameAssetBrowser] 已提取: " + asset.Name + " (" + asset.Type + ")");
                if (asset.Type == "Texture" && asset.Asset is Texture2D tex)
                    Debug.Log("[GameAssetBrowser] 纹理尺寸: " + tex.width + "x" + tex.height);
                else if (asset.Type == "AudioClip" && asset.Asset is AudioClip clip)
                    Debug.Log("[GameAssetBrowser] 音频时长: " + clip.length + "s");
                else if (asset.Type == "Mesh" && asset.Asset is Mesh mesh)
                    Debug.Log("[GameAssetBrowser] 顶点数: " + mesh.vertexCount);
            }
            catch (Exception ex) { Debug.LogError("[GameAssetBrowser] 提取失败: " + ex.Message); }
        }
    }
}
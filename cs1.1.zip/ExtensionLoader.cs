﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using BepInEx;
using UnityEngine;

namespace SuperConsole
{
    // ============================================================
    // 扩展接口定义 - 用于"全局扩展 DLL"
    // ============================================================

    public interface IScript { void Run(); }
    public interface IHookPreset
    {
        string DisplayName { get; }
        string TypeName { get; }
        string MethodName { get; }
        string Description { get; }
        string HookType { get; }
        bool Prefix();
    }
    public interface ICommand
    {
        string Name { get; }
        string Code { get; }
        string Description { get; }
    }
    public interface ILogicEntity
    {
        string Name { get; }
        string Description { get; }
        void Execute();
    }
    public interface IWindow
    {
        string Title { get; }
        void Draw();
    }
    public interface IPrefabProvider
    {
        string Name { get; }
        GameObject GetPrefab();
    }

    /// <summary>
    /// 扩展初始化接口 - 全局扩展必须实现
    /// </summary>
    public interface IExtensionInit
    {
        void OnLoad();
        void OnUnload();
    }

    /// <summary>
    /// 万能扩展接口 - 实现这个可以做任何事（推荐）
    /// </summary>
    public interface IUniversalExtension
    {
        void OnLoad(ExtensionContext context);
        void OnUnload();
    }

    /// <summary>
    /// 扩展上下文 - 给全局扩展访问 SuperConsole 的能力
    /// </summary>
    public class ExtensionContext
    {
        public string ExtensionPath { get; set; }
        public string ExtensionName { get; set; }
        public Assembly Assembly { get; set; }

        public void RegisterCommand(string name, Action<string[]> action)
        {
            ExtensionCommands.RegisterCommand(name, action);
        }

        public void RegisterWindow(string title, Action drawAction)
        {
            ExtensionCommands.RegisterWindow(title, drawAction);
        }

        public void Log(string msg) { Debug.Log($"[Ext:{ExtensionName}] {msg}"); }
        public void LogWarning(string msg) { Debug.LogWarning($"[Ext:{ExtensionName}] {msg}"); }
        public void LogError(string msg) { Debug.LogError($"[Ext:{ExtensionName}] {msg}"); }

        // ✅ 新增：向控制台输出（显示在 SuperConsole 的 UI 中）
        public void Output(string msg)
        {
            if (ExtensionCommands.OnOutput != null)
                ExtensionCommands.OnOutput($"[{ExtensionName}] {msg}");
            else
                Debug.Log($"[Ext:{ExtensionName}] {msg}");
        }
    }

    // ============================================================
    // 扩展数据类
    // ============================================================
    public class ExtensionData
    {
        public string FileName;
        public string FilePath;
        public Assembly Assembly;
        public List<Type> AllTypes = new List<Type>();
        public List<Type> Components = new List<Type>();
        public List<IScript> Scripts = new List<IScript>();
        public List<IHookPreset> Hooks = new List<IHookPreset>();
        public List<ICommand> Commands = new List<ICommand>();
        public List<ILogicEntity> Logics = new List<ILogicEntity>();
        public List<IWindow> Windows = new List<IWindow>();
        public List<IPrefabProvider> Prefabs = new List<IPrefabProvider>();
        public IExtensionInit Init = null;
        public IUniversalExtension Universal = null;
        public ExtensionContext Context = null;
        public bool IsLoaded = false;
        public DateTime LoadTime;
    }

    // ============================================================
    // 扩展注册表
    // ============================================================
    public static class ExtensionRegistry
    {
        public static List<ExtensionData> AllExtensions = new List<ExtensionData>();
        public static List<Type> RegisteredComponents = new List<Type>();
        public static List<IScript> RegisteredScripts = new List<IScript>();
        public static List<IHookPreset> RegisteredHooks = new List<IHookPreset>();
        public static List<ICommand> RegisteredCommands = new List<ICommand>();
        public static List<ILogicEntity> RegisteredLogics = new List<ILogicEntity>();
        public static List<IWindow> RegisteredWindows = new List<IWindow>();
        public static List<IPrefabProvider> RegisteredPrefabs = new List<IPrefabProvider>();
        public static Dictionary<string, Action> CustomWindows = new Dictionary<string, Action>();

        public static void Clear()
        {
            AllExtensions.Clear();
            RegisteredComponents.Clear();
            RegisteredScripts.Clear();
            RegisteredHooks.Clear();
            RegisteredCommands.Clear();
            RegisteredLogics.Clear();
            RegisteredWindows.Clear();
            RegisteredPrefabs.Clear();
            CustomWindows.Clear();
        }

        public static void PrintStats()
        {
            Debug.Log($"[ExtensionRegistry] 扩展统计:");
            Debug.Log($"  扩展包: {AllExtensions.Count}");
            Debug.Log($"  组件: {RegisteredComponents.Count}");
            Debug.Log($"  脚本: {RegisteredScripts.Count}");
            Debug.Log($"  Hook: {RegisteredHooks.Count}");
            Debug.Log($"  命令: {RegisteredCommands.Count}");
            Debug.Log($"  逻辑体: {RegisteredLogics.Count}");
            Debug.Log($"  窗口: {RegisteredWindows.Count}");
            Debug.Log($"  预制体: {RegisteredPrefabs.Count}");
            Debug.Log($"  自定义窗口: {CustomWindows.Count}");
        }
    }

    // ============================================================
    // DLL 扩展加载器 - 加载"全局扩展"
    // ============================================================
    public static class ExtensionLoader
    {
        private static string extensionPath = Path.Combine(Paths.PluginPath, "SuperConsole", "extensions");
        private static string disabledPath = Path.Combine(extensionPath, "Disabled");

        static ExtensionLoader()
        {
            EnsureDirectories();
            AppDomain.CurrentDomain.AssemblyResolve += OnAssemblyResolve;
        }

        private static void EnsureDirectories()
        {
            if (!Directory.Exists(extensionPath)) Directory.CreateDirectory(extensionPath);
            if (!Directory.Exists(disabledPath)) Directory.CreateDirectory(disabledPath);
        }

        private static Assembly OnAssemblyResolve(object sender, ResolveEventArgs args)
        {
            string assemblyName = new AssemblyName(args.Name).Name;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (asm.GetName().Name == assemblyName)
                    return asm;
            }
            string dllPath = Path.Combine(extensionPath, assemblyName + ".dll");
            if (File.Exists(dllPath))
            {
                try { return Assembly.LoadFrom(dllPath); }
                catch { }
            }
            return null;
        }

        public static void LoadAll()
        {
            Debug.Log("[ExtensionLoader] 开始加载全局扩展...");
            ExtensionRegistry.Clear();

            if (!Directory.Exists(extensionPath))
            {
                Debug.Log("[ExtensionLoader] 扩展目录不存在");
                return;
            }

            string[] dllFiles = Directory.GetFiles(extensionPath, "*.dll", SearchOption.TopDirectoryOnly);
            Debug.Log($"[ExtensionLoader] 找到 {dllFiles.Length} 个 DLL 文件");

            foreach (string dllPath in dllFiles)
            {
                LoadExtension(dllPath);
            }

            // ============================================================
            // ✅ 注册内置示例命令（让 cmd:hello 和 cmd:ping 能显示在控制台）
            // ============================================================
            RegisterBuiltinCommands();

            foreach (var ext in ExtensionRegistry.AllExtensions)
            {
                if (ext.IsLoaded)
                {
                    InitializeExtension(ext);
                }
            }

            ExtensionRegistry.PrintStats();
            Debug.Log("[ExtensionLoader] 全局扩展加载完成！");
        }

        // ============================================================
        // ✅ 注册内置示例命令
        // ============================================================
        private static void RegisterBuiltinCommands()
        {
            ExtensionCommands.RegisterCommand("hello", (args) =>
            {
                string msg = "👋 Hello from SuperConsole Extension System!";
                Debug.Log(msg);
                if (ExtensionCommands.OnOutput != null)
                    ExtensionCommands.OnOutput(msg);
                else
                    Debug.Log(msg);
            });

            ExtensionCommands.RegisterCommand("ping", (args) =>
            {
                string msg = "🏓 Pong! Extension system is alive and running.";
                Debug.Log(msg);
                if (ExtensionCommands.OnOutput != null)
                    ExtensionCommands.OnOutput(msg);
                else
                    Debug.Log(msg);
            });

            // 额外有用的命令
            ExtensionCommands.RegisterCommand("extensions", (args) =>
            {
                string list = ListExtensions();
                Debug.Log(list);
                if (ExtensionCommands.OnOutput != null)
                    ExtensionCommands.OnOutput(list);
                else
                    Debug.Log(list);
            });

            ExtensionCommands.RegisterCommand("reload", (args) =>
            {
                string msg = "🔄 重新加载所有扩展...";
                Debug.Log(msg);
                if (ExtensionCommands.OnOutput != null)
                    ExtensionCommands.OnOutput(msg);
                ReloadAll();
                string doneMsg = "✅ 扩展已重新加载";
                Debug.Log(doneMsg);
                if (ExtensionCommands.OnOutput != null)
                    ExtensionCommands.OnOutput(doneMsg);
            });

            Debug.Log("[ExtensionLoader] ✅ 已注册内置命令: hello, ping, extensions, reload");
        }

        private static void LoadExtension(string dllPath)
        {
            var extData = new ExtensionData
            {
                FileName = Path.GetFileName(dllPath),
                FilePath = dllPath,
                IsLoaded = false,
                LoadTime = DateTime.Now
            };

            try
            {
                Debug.Log($"[ExtensionLoader] 加载: {extData.FileName}");
                Assembly assembly = Assembly.LoadFrom(dllPath);
                extData.Assembly = assembly;

                foreach (Type type in assembly.GetTypes())
                {
                    if (type.IsAbstract || type.IsInterface || type.IsEnum) continue;
                    extData.AllTypes.Add(type);

                    if (typeof(MonoBehaviour).IsAssignableFrom(type))
                    {
                        if (!ExtensionRegistry.RegisteredComponents.Contains(type))
                        {
                            ExtensionRegistry.RegisteredComponents.Add(type);
                            extData.Components.Add(type);
                            Debug.Log($"[ExtensionLoader]   - 组件: {type.Name}");
                        }
                    }

                    ScanInterfaces(type, extData);
                }

                // 查找 IUniversalExtension
                foreach (Type type in assembly.GetTypes())
                {
                    if (typeof(IUniversalExtension).IsAssignableFrom(type) && !type.IsInterface && !type.IsAbstract)
                    {
                        try
                        {
                            extData.Universal = (IUniversalExtension)Activator.CreateInstance(type);
                            extData.Context = new ExtensionContext
                            {
                                ExtensionPath = Path.GetDirectoryName(dllPath),
                                ExtensionName = extData.FileName,
                                Assembly = assembly
                            };
                            Debug.Log($"[ExtensionLoader]   - 万能扩展: {type.Name}");
                            break;
                        }
                        catch (Exception ex)
                        {
                            Debug.LogWarning($"[ExtensionLoader] 实例化万能扩展失败 {type.Name}: {ex.Message}");
                        }
                    }
                }

                extData.IsLoaded = true;
                ExtensionRegistry.AllExtensions.Add(extData);
                Debug.Log($"[ExtensionLoader] 加载完成: {extData.FileName}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[ExtensionLoader] 加载失败: {extData.FileName} - {ex.Message}");
            }
        }

        private static void ScanInterfaces(Type type, ExtensionData extData)
        {
            if (typeof(IScript).IsAssignableFrom(type))
            {
                try
                {
                    IScript script = (IScript)Activator.CreateInstance(type);
                    ExtensionRegistry.RegisteredScripts.Add(script);
                    extData.Scripts.Add(script);
                    Debug.Log($"[ExtensionLoader]   - 脚本: {type.Name}");
                }
                catch (Exception ex) { Debug.LogWarning($"  脚本实例化失败: {ex.Message}"); }
            }

            if (typeof(IHookPreset).IsAssignableFrom(type))
            {
                try
                {
                    IHookPreset hook = (IHookPreset)Activator.CreateInstance(type);
                    ExtensionRegistry.RegisteredHooks.Add(hook);
                    extData.Hooks.Add(hook);
                    Debug.Log($"[ExtensionLoader]   - Hook: {hook.DisplayName}");
                }
                catch (Exception ex) { Debug.LogWarning($"  Hook实例化失败: {ex.Message}"); }
            }

            if (typeof(ICommand).IsAssignableFrom(type))
            {
                try
                {
                    ICommand cmd = (ICommand)Activator.CreateInstance(type);
                    ExtensionRegistry.RegisteredCommands.Add(cmd);
                    extData.Commands.Add(cmd);
                    Debug.Log($"[ExtensionLoader]   - 命令: {cmd.Name}");
                }
                catch (Exception ex) { Debug.LogWarning($"  命令实例化失败: {ex.Message}"); }
            }

            if (typeof(ILogicEntity).IsAssignableFrom(type))
            {
                try
                {
                    ILogicEntity logic = (ILogicEntity)Activator.CreateInstance(type);
                    ExtensionRegistry.RegisteredLogics.Add(logic);
                    extData.Logics.Add(logic);
                    Debug.Log($"[ExtensionLoader]   - 逻辑体: {logic.Name}");
                }
                catch (Exception ex) { Debug.LogWarning($"  逻辑体实例化失败: {ex.Message}"); }
            }

            if (typeof(IWindow).IsAssignableFrom(type))
            {
                try
                {
                    IWindow window = (IWindow)Activator.CreateInstance(type);
                    ExtensionRegistry.RegisteredWindows.Add(window);
                    extData.Windows.Add(window);
                    Debug.Log($"[ExtensionLoader]   - 窗口: {window.Title}");
                }
                catch (Exception ex) { Debug.LogWarning($"  窗口实例化失败: {ex.Message}"); }
            }

            if (typeof(IPrefabProvider).IsAssignableFrom(type))
            {
                try
                {
                    IPrefabProvider prefab = (IPrefabProvider)Activator.CreateInstance(type);
                    ExtensionRegistry.RegisteredPrefabs.Add(prefab);
                    extData.Prefabs.Add(prefab);
                    Debug.Log($"[ExtensionLoader]   - 预制体: {prefab.Name}");
                }
                catch (Exception ex) { Debug.LogWarning($"  预制体实例化失败: {ex.Message}"); }
            }

            if (typeof(IExtensionInit).IsAssignableFrom(type))
            {
                try
                {
                    extData.Init = (IExtensionInit)Activator.CreateInstance(type);
                    Debug.Log($"[ExtensionLoader]   - 初始化: {type.Name}");
                }
                catch (Exception ex) { Debug.LogWarning($"  初始化实例化失败: {ex.Message}"); }
            }
        }

        private static void InitializeExtension(ExtensionData ext)
        {
            if (ext.Init != null)
            {
                try { ext.Init.OnLoad(); }
                catch (Exception ex) { Debug.LogError($"[ExtensionLoader] OnLoad 失败: {ext.FileName} - {ex.Message}"); }
            }

            if (ext.Universal != null && ext.Context != null)
            {
                try { ext.Universal.OnLoad(ext.Context); }
                catch (Exception ex) { Debug.LogError($"[ExtensionLoader] 万能扩展 OnLoad 失败: {ext.FileName} - {ex.Message}"); }
            }
        }

        public static void UnloadAll()
        {
            foreach (var ext in ExtensionRegistry.AllExtensions)
            {
                if (ext.Init != null && ext.IsLoaded)
                {
                    try { ext.Init.OnUnload(); }
                    catch (Exception ex) { Debug.LogError($"[ExtensionLoader] OnUnload 失败: {ext.FileName} - {ex.Message}"); }
                }
                if (ext.Universal != null)
                {
                    try { ext.Universal.OnUnload(); }
                    catch (Exception ex) { Debug.LogError($"[ExtensionLoader] 万能扩展 OnUnload 失败: {ext.FileName} - {ex.Message}"); }
                }
            }
            ExtensionRegistry.Clear();
            Debug.Log("[ExtensionLoader] 所有全局扩展已卸载");
        }

        public static void ReloadAll() { UnloadAll(); LoadAll(); }

        public static Type FindType(string typeName)
        {
            foreach (var ext in ExtensionRegistry.AllExtensions)
            {
                foreach (var type in ext.AllTypes)
                {
                    if (type.Name == typeName || type.FullName == typeName)
                        return type;
                }
            }
            return null;
        }

        public static bool IsExtensionLoaded(string fileName)
            => ExtensionRegistry.AllExtensions.Any(e => e.FileName == fileName && e.IsLoaded);

        public static void DisableExtension(string fileName)
        {
            string src = Path.Combine(extensionPath, fileName);
            string dst = Path.Combine(disabledPath, fileName);
            if (File.Exists(src))
            {
                File.Move(src, dst);
                Debug.Log($"[ExtensionLoader] 已禁用扩展: {fileName}");
                ReloadAll();
            }
        }

        public static void EnableExtension(string fileName)
        {
            string src = Path.Combine(disabledPath, fileName);
            string dst = Path.Combine(extensionPath, fileName);
            if (File.Exists(src))
            {
                File.Move(src, dst);
                Debug.Log($"[ExtensionLoader] 已启用扩展: {fileName}");
                ReloadAll();
            }
        }

        public static string ListExtensions()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("已加载全局扩展:");
            if (ExtensionRegistry.AllExtensions.Count == 0)
            {
                sb.AppendLine("  (无)");
            }
            else
            {
                foreach (var ext in ExtensionRegistry.AllExtensions)
                {
                    sb.AppendLine($"  [{ext.FileName}] 类型:{ext.AllTypes.Count} 组件:{ext.Components.Count} 已加载:{ext.IsLoaded}");
                }
            }
            // 添加内置命令
            sb.AppendLine("内置命令: hello, ping, extensions, reload");
            return sb.ToString();
        }
    }

    // ============================================================
    // 扩展命令
    // ============================================================
    public static class ExtensionCommands
    {
        private static Dictionary<string, Action<string[]>> commands = new Dictionary<string, Action<string[]>>();
        private static Dictionary<string, Action> customWindows = new Dictionary<string, Action>();

        // ✅ 输出回调 - 让扩展命令能向 SuperConsole 控制台输出
        public static Action<string> OnOutput = null;

        public static void RegisterCommand(string name, Action<string[]> action)
        {
            if (!commands.ContainsKey(name))
            {
                commands[name] = action;
                Debug.Log($"[ExtensionCommands] 注册命令: {name}");
            }
            else
            {
                Debug.LogWarning($"[ExtensionCommands] 命令已存在: {name}");
            }
        }

        public static void RegisterWindow(string title, Action drawAction)
        {
            if (!customWindows.ContainsKey(title))
            {
                customWindows[title] = drawAction;
                Debug.Log($"[ExtensionCommands] 注册窗口: {title}");
            }
        }

        public static bool Execute(string command)
        {
            string[] parts = command.Split(' ');
            if (parts.Length < 1) return false;

            string cmd = parts[0].ToLower();

            // 处理 ext 命令（内置）
            if (cmd == "ext" || cmd == "extension")
            {
                HandleExtensionCommand(parts);
                return true;
            }

            // 处理注册的命令
            if (commands.ContainsKey(cmd))
            {
                commands[cmd](parts);
                return true;
            }

            return false;
        }

        private static void HandleExtensionCommand(string[] parts)
        {
            if (parts.Length < 2)
            {
                string msg = "[ExtensionCommands] 用法: ext list | ext reload | ext disable <文件名> | ext enable <文件名>";
                Debug.Log(msg);
                if (OnOutput != null) OnOutput(msg);
                return;
            }

            switch (parts[1].ToLower())
            {
                case "list":
                    string list = ExtensionLoader.ListExtensions();
                    Debug.Log(list);
                    if (OnOutput != null) OnOutput(list);
                    break;
                case "load":
                case "reload":
                    ExtensionLoader.ReloadAll();
                    string reloadMsg = "[ExtensionCommands] ✅ 已重新加载所有扩展";
                    Debug.Log(reloadMsg);
                    if (OnOutput != null) OnOutput(reloadMsg);
                    break;
                case "disable":
                    if (parts.Length > 2)
                    {
                        ExtensionLoader.DisableExtension(parts[2]);
                        string disableMsg = $"[ExtensionCommands] ⏹️ 已禁用扩展: {parts[2]}";
                        Debug.Log(disableMsg);
                        if (OnOutput != null) OnOutput(disableMsg);
                    }
                    else
                    {
                        string msg = "[ExtensionCommands] 请指定文件名: ext disable <文件名>";
                        Debug.Log(msg);
                        if (OnOutput != null) OnOutput(msg);
                    }
                    break;
                case "enable":
                    if (parts.Length > 2)
                    {
                        ExtensionLoader.EnableExtension(parts[2]);
                        string enableMsg = $"[ExtensionCommands] ▶️ 已启用扩展: {parts[2]}";
                        Debug.Log(enableMsg);
                        if (OnOutput != null) OnOutput(enableMsg);
                    }
                    else
                    {
                        string msg = "[ExtensionCommands] 请指定文件名: ext enable <文件名>";
                        Debug.Log(msg);
                        if (OnOutput != null) OnOutput(msg);
                    }
                    break;
                default:
                    string unknownMsg = $"[ExtensionCommands] 未知命令: {parts[1]}";
                    Debug.Log(unknownMsg);
                    if (OnOutput != null) OnOutput(unknownMsg);
                    break;
            }
        }

        public static void DrawCustomWindows()
        {
            foreach (var kv in customWindows)
            {
                try { kv.Value(); }
                catch (Exception ex) { Debug.LogError($"[ExtensionCommands] 窗口绘制失败 {kv.Key}: {ex.Message}"); }
            }
        }
    }

    // ============================================================
    // 特性定义
    // ============================================================

    /// <summary>
    /// 标记静态入口方法，加载时自动执行（仅全局扩展）
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public class ExtensionEntryAttribute : Attribute
    {
        public int Priority { get; set; } = 0;
        public string Name { get; set; } = null;
        public ExtensionEntryAttribute() { }
        public ExtensionEntryAttribute(string name) { Name = name; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SuperConsole
{
    public static class AutoCompleteInput
    {
        // ===== 每个输入框独立的滚动位置 =====
        private static Dictionary<string, Vector2> scrollPositions = new Dictionary<string, Vector2>();
        private static string pendingResult = "";
        private static bool pendingClose = false;

        public static string Draw(string label, string currentText, List<string> suggestions,
            ref bool showDropdown, ref int selectedIndex, ref Rect inputRect, params GUILayoutOption[] options)
        {
            string result = currentText;
            string controlName = "autoComplete_" + label + "_" + Guid.NewGuid().ToString().Substring(0, 4);

            GUILayout.BeginHorizontal();

            if (!string.IsNullOrEmpty(label))
                GUILayout.Label(label, GUILayout.Width(30));

            GUI.SetNextControlName(controlName);
            result = GUILayout.TextField(currentText, options);

            if (Event.current.type == EventType.Repaint)
            {
                inputRect = GUILayoutUtility.GetLastRect();
            }

            if (result != currentText)
            {
                showDropdown = !string.IsNullOrEmpty(result) && suggestions.Any(s => s.StartsWith(result, StringComparison.OrdinalIgnoreCase));
                selectedIndex = -1;
                if (!scrollPositions.ContainsKey(controlName))
                    scrollPositions[controlName] = Vector2.zero;
                else
                    scrollPositions[controlName] = Vector2.zero;
            }

            GUILayout.EndHorizontal();

            // 检查是否有待选中的结果
            if (pendingClose)
            {
                result = pendingResult;
                showDropdown = false;
                selectedIndex = -1;
                pendingClose = false;
                pendingResult = "";
                return result;
            }

            // ✅ 带滚轮的下拉列表
            if (showDropdown && !string.IsNullOrEmpty(result))
            {
                var matches = suggestions
                    .Where(s => s.StartsWith(result, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                if (matches.Count > 0)
                {
                    float maxHeight = 200f;
                    float itemHeight = 22f;
                    float totalHeight = Math.Min(matches.Count * itemHeight, maxHeight);
                    bool needsScroll = matches.Count * itemHeight > maxHeight;

                    Rect dropdownRect = new Rect(
                        inputRect.x + 20,
                        inputRect.y + inputRect.height + 5,
                        220,
                        totalHeight + (needsScroll ? 18 : 0)
                    );

                    if (dropdownRect.x + dropdownRect.width > Screen.width)
                        dropdownRect.x = Screen.width - dropdownRect.width - 10;
                    if (dropdownRect.y + dropdownRect.height > Screen.height)
                        dropdownRect.y = Screen.height - dropdownRect.height - 10;

                    // ✅ 用局部变量捕获，避免 ref 问题
                    int localSelectedIndex = selectedIndex;
                    string localControlName = controlName;

                    if (!scrollPositions.ContainsKey(localControlName))
                        scrollPositions[localControlName] = Vector2.zero;

                    int windowId = 6666 + localControlName.GetHashCode();

                    GUI.Window(windowId, dropdownRect, (id) =>
                    {
                        Vector2 scrollPos = scrollPositions[localControlName];
                        scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(totalHeight));

                        for (int i = 0; i < matches.Count; i++)
                        {
                            GUILayout.BeginHorizontal();

                            if (i == localSelectedIndex)
                                GUI.backgroundColor = new Color(0.3f, 0.5f, 0.8f);

                            if (GUILayout.Button(matches[i], GUILayout.ExpandWidth(true)))
                            {
                                // ✅ 用静态字段传递结果，而不是直接改 ref
                                pendingResult = matches[i];
                                pendingClose = true;
                                GUI.FocusControl(null);
                            }

                            GUI.backgroundColor = Color.white;
                            GUILayout.EndHorizontal();
                        }

                        GUILayout.EndScrollView();

                        scrollPositions[localControlName] = scrollPos;

                    }, "", GUI.skin.box);
                }
                else
                {
                    showDropdown = false;
                }
            }

            // 键盘事件
            if (showDropdown && Event.current.type == EventType.KeyDown)
            {
                var matches = suggestions
                    .Where(s => s.StartsWith(result, StringComparison.OrdinalIgnoreCase))
                    .ToList();

                if (matches.Count > 0)
                {
                    if (Event.current.keyCode == KeyCode.DownArrow)
                    {
                        selectedIndex = Math.Min(selectedIndex + 1, matches.Count - 1);
                        Event.current.Use();
                    }
                    else if (Event.current.keyCode == KeyCode.UpArrow)
                    {
                        selectedIndex = Math.Max(selectedIndex - 1, 0);
                        Event.current.Use();
                    }
                    else if (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.Tab)
                    {
                        if (selectedIndex >= 0 && selectedIndex < matches.Count)
                        {
                            pendingResult = matches[selectedIndex];
                            pendingClose = true;
                            GUI.FocusControl(null);
                            Event.current.Use();
                        }
                    }
                    else if (Event.current.keyCode == KeyCode.Escape)
                    {
                        showDropdown = false;
                        selectedIndex = -1;
                        Event.current.Use();
                    }
                }
            }

            return result;
        }

        // 兼容旧调用
        public static string Draw(string label, string currentText, List<string> suggestions,
            ref bool showDropdown, ref int selectedIndex, params GUILayoutOption[] options)
        {
            Rect dummyRect = Rect.zero;
            return Draw(label, currentText, suggestions, ref showDropdown, ref selectedIndex, ref dummyRect, options);
        }
    }
}
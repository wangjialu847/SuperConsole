﻿using System;
using UnityEngine;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace SuperConsole
{
    public static class TeleportUI
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(200, 200, 450, 330);
        private static Vector2 scrollPos = Vector2.zero;

        private static int mode = 0;
        private static string posX = "0";
        private static string posY = "0";
        private static string posZ = "0";
        private static GameObject targetObject = null;
        private static GameObject selectedGameObject = null;
        private static bool waitingForObjectPick = false;
        private static string statusMessage = "就绪";

        public static void ResetPosition()
        {
            windowRect = new Rect(200, 200, 450, 330);
        }

        public static void Toggle(GameObject selectedObj)
        {
            visible = !visible;
            selectedGameObject = selectedObj;
            targetObject = null;
            waitingForObjectPick = false;
            statusMessage = "就绪";
            if (selectedGameObject != null)
            {
                Vector3 pos = selectedGameObject.transform.position;
                posX = pos.x.ToString("F2");
                posY = pos.y.ToString("F2");
                posZ = pos.z.ToString("F2");
            }
        }

        public static bool IsVisible() => visible;

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12356);
            windowRect = GUI.Window(12356, windowRect, DrawWindow, "📍 传送对象 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape) { visible = false; return; }

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("🎯 传送: " + (selectedGameObject != null ? selectedGameObject.name : "未选中"), GUILayout.ExpandWidth(true));
            if (GUILayout.Button("✖", GUILayout.Width(25))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (selectedGameObject != null)
                GUILayout.Label($"📌 当前位置: {selectedGameObject.transform.position}");
            else
                GUILayout.Label("⚠️ 请先在对象浏览器中选中一个对象");

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("模式:", GUILayout.Width(40));
            if (GUILayout.Button(mode == 0 ? "✅ 坐标" : "   坐标", GUILayout.Width(100)))
            {
                mode = 0;
                waitingForObjectPick = false;
                statusMessage = "坐标模式";
            }
            if (GUILayout.Button(mode == 1 ? "✅ 物体" : "   物体", GUILayout.Width(80)))
            {
                mode = 1;
                waitingForObjectPick = false;
                statusMessage = "物体模式 - 点击下方按钮选择";
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (mode == 0)
            {
                GUILayout.Label("📝 输入目标坐标:");
                GUILayout.BeginHorizontal();
                GUILayout.Label("X:", GUILayout.Width(20));
                posX = GUILayout.TextField(posX, GUILayout.Width(80));
                GUILayout.Label("Y:", GUILayout.Width(20));
                posY = GUILayout.TextField(posY, GUILayout.Width(80));
                GUILayout.Label("Z:", GUILayout.Width(20));
                posZ = GUILayout.TextField(posZ, GUILayout.Width(80));
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                if (GUILayout.Button("📌 使用当前位置", GUILayout.Width(140)))
                {
                    if (selectedGameObject != null)
                    {
                        Vector3 pos = selectedGameObject.transform.position;
                        posX = pos.x.ToString("F2");
                        posY = pos.y.ToString("F2");
                        posZ = pos.z.ToString("F2");
                        statusMessage = "已填入当前位置";
                    }
                }
                if (GUILayout.Button("📌 使用摄像机位置", GUILayout.Width(140)))
                {
                    Camera cam = Camera.main;
                    if (cam != null)
                    {
                        Vector3 pos = cam.transform.position;
                        posX = pos.x.ToString("F2");
                        posY = pos.y.ToString("F2");
                        posZ = pos.z.ToString("F2");
                        statusMessage = "已填入摄像机位置";
                    }
                }
                GUILayout.EndHorizontal();

                GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

                if (GUILayout.Button("🚀 传送到坐标", GUILayout.Height(30)))
                {
                    if (selectedGameObject == null)
                        statusMessage = "❌ 没有选中任何对象";
                    else
                    {
                        try
                        {
                            float x = float.Parse(posX);
                            float y = float.Parse(posY);
                            float z = float.Parse(posZ);
                            selectedGameObject.transform.position = new Vector3(x, y, z);
                            statusMessage = $"✅ 已传送 {selectedGameObject.name} 到 ({x:F2}, {y:F2}, {z:F2})";
                            Debug.Log($"[TeleportUI] ✅ 传送 {selectedGameObject.name} 到 ({x}, {y}, {z})");
                        }
                        catch (Exception ex) { statusMessage = $"❌ 坐标格式错误: {ex.Message}"; }
                    }
                }
            }

            if (mode == 1)
            {
                GUILayout.Label("🎯 选择目标对象:");

                if (waitingForObjectPick)
                {
                    GUILayout.Label("🔄 请在游戏场景中点击一个物体...", GUILayout.Height(30));
                    GUILayout.Label("💡 点击后自动返回此窗口确认", GUILayout.Height(20));
                }
                else
                {
                    if (targetObject != null)
                    {
                        GUILayout.Label($"✅ 目标: {targetObject.name}", GUILayout.Height(30));
                        GUILayout.Label($"📍 位置: {targetObject.transform.position}");
                    }
                    else
                        GUILayout.Label("⚠️ 尚未选择目标物体", GUILayout.Height(30));
                }

                GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

                GUILayout.BeginHorizontal();
                if (GUILayout.Button(waitingForObjectPick ? "⏹ 取消选择" : "🔍 点击选择物体", GUILayout.Height(30)))
                {
                    if (waitingForObjectPick) { waitingForObjectPick = false; statusMessage = "已取消选择"; }
                    else { waitingForObjectPick = true; statusMessage = "请在游戏中点击一个物体"; }
                }
                if (GUILayout.Button("🗑 清除目标", GUILayout.Height(30)))
                {
                    targetObject = null;
                    waitingForObjectPick = false;
                    statusMessage = "已清除目标";
                }
                GUILayout.EndHorizontal();

                GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

                if (GUILayout.Button("🚀 传送到物体", GUILayout.Height(30)))
                {
                    if (selectedGameObject == null)
                        statusMessage = "❌ 没有选中要传送的对象";
                    else if (targetObject == null)
                        statusMessage = "❌ 请先选择目标物体";
                    else
                    {
                        selectedGameObject.transform.position = targetObject.transform.position;
                        statusMessage = $"✅ 已传送 {selectedGameObject.name} 到 {targetObject.name} 的位置";
                        Debug.Log($"[TeleportUI] ✅ 传送 {selectedGameObject.name} 到 {targetObject.name}");
                    }
                }
            }

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.Label($"📊 状态: {statusMessage}", GUILayout.ExpandWidth(true));
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("💡 按 Esc 关闭", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("关闭", GUILayout.Width(60))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow(new Rect(0, 0, windowRect.width, 20));
        }

        public static void HandleClick(GameObject clickedObject)
        {
            if (!visible || !waitingForObjectPick) return;
            if (clickedObject == null) return;
            targetObject = clickedObject;
            waitingForObjectPick = false;
            statusMessage = $"✅ 已选择: {clickedObject.name}";
            Debug.Log($"[TeleportUI] 🎯 选中目标: {clickedObject.name}");
        }
    }
}
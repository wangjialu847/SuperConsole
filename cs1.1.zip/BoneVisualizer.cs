﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Messaging;
using UnityEngine;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace SuperConsole
{
    public static class BoneVisualizer
    {
        private static bool visible = false;
        private static GameObject targetObject = null;
        private static List<BoneInfo> bones = new List<BoneInfo>();
        private static List<GameObject> boneMarkers = new List<GameObject>();
        private static List<LineRenderer> boneLines = new List<LineRenderer>();
        private static Material lineMaterial;
        private static Color boneColor = Color.cyan;
        private static float lineWidth = 0.02f;
        private static bool showSkeleton = true;
        private static bool showOutline = true;
        private static bool showBoneNames = false;
        private static int selectedBoneIndex = -1;
        private static Vector2 scrollPos = Vector2.zero;
        private static Rect windowRect = new Rect(50, 50, 400, 500);
        private static bool windowVisible = false;

        public class BoneInfo
        {
            public Transform transform;
            public string name;
            public Transform parent;
            public List<Transform> children = new List<Transform>();
            public Vector3 position;
            public Quaternion rotation;
            public Vector3 localPosition;
            public Quaternion localRotation;
            public Vector3 lossyScale;
        }

        // ===== 重置位置 =====
        public static void ResetPosition()
        {
            windowRect = new Rect(50, 50, 400, 500);
        }

        public static void Toggle(GameObject obj)
        {
            if (obj == null) return;
            if (targetObject == obj && visible) { Hide(); return; }
            targetObject = obj;
            visible = true;
            windowVisible = true;
            BuildBoneTree();
            CreateVisuals();
            Debug.Log("🦴 Skeleton shown: " + obj.name);
        }

        public static void ToggleWindow() { windowVisible = !windowVisible; if (windowVisible && targetObject != null) { BuildBoneTree(); CreateVisuals(); } }
        public static void Hide() { visible = false; windowVisible = false; ClearVisuals(); targetObject = null; Debug.Log("🦴 Skeleton hidden"); }
        public static void SetTarget(GameObject obj) { if (obj == null) return; targetObject = obj; if (visible) { BuildBoneTree(); CreateVisuals(); } }
        public static bool IsVisible() => visible;
        public static GameObject GetTarget() => targetObject;

        public static void Draw()
        {
            if (!windowVisible || targetObject == null) return;
            windowRect = GUI.Window(12351, windowRect, DrawWindow, "🦴 Skeleton Viewer [Esc to close]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.MouseDown)
            {
                GUI.FocusControl(null);
            }

            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape) { windowVisible = false; return; }

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("🎯 " + targetObject.name, GUILayout.ExpandWidth(true));
            if (GUILayout.Button("✖", GUILayout.Width(25))) { windowVisible = false; Hide(); return; }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("Color:", GUILayout.Width(40));
            if (GUILayout.Button("🔵", GUILayout.Width(25))) { boneColor = Color.cyan; UpdateColors(); }
            if (GUILayout.Button("🔴", GUILayout.Width(25))) { boneColor = Color.red; UpdateColors(); }
            if (GUILayout.Button("🟢", GUILayout.Width(25))) { boneColor = Color.green; UpdateColors(); }
            if (GUILayout.Button("🟡", GUILayout.Width(25))) { boneColor = Color.yellow; UpdateColors(); }
            if (GUILayout.Button("🟣", GUILayout.Width(25))) { boneColor = Color.magenta; UpdateColors(); }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            showSkeleton = GUILayout.Toggle(showSkeleton, "Skeleton", GUILayout.Width(80));
            showOutline = GUILayout.Toggle(showOutline, "Outline", GUILayout.Width(80));
            showBoneNames = GUILayout.Toggle(showBoneNames, "Names", GUILayout.Width(80));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("🔄 Refresh")) { BuildBoneTree(); CreateVisuals(); }
            if (GUILayout.Button("🗑️ Clear")) { ClearVisuals(); visible = false; windowVisible = false; }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.Label("📋 Bones (" + bones.Count + ")", GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            for (int i = 0; i < bones.Count; i++)
            {
                var bone = bones[i];
                if (bone == null || bone.transform == null) continue;
                GUILayout.BeginHorizontal();

                string indent = "";
                Transform current = bone.transform.parent;
                while (current != null && current != targetObject.transform)
                {
                    indent += "  ";
                    current = current.parent;
                }
                GUILayout.Label(indent, GUILayout.Width(Math.Min(indent.Length * 10, 60)));

                if (GUILayout.Button("▶", GUILayout.Width(20))) { selectedBoneIndex = i; HighlightBone(bone); }

                Color originalColor = GUI.color;
                if (i == selectedBoneIndex) GUI.color = Color.yellow;
                if (GUILayout.Button(bone.name, GUILayout.ExpandWidth(true))) { selectedBoneIndex = i; HighlightBone(bone); }
                GUI.color = originalColor;
                GUILayout.Label("(" + bone.children.Count + ")", GUILayout.Width(30));
                GUILayout.EndHorizontal();
            }

            GUILayout.EndScrollView();

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
            {
                var bone = bones[selectedBoneIndex];
                if (bone != null && bone.transform != null)
                {
                    GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
                    GUILayout.Label("📌 " + bone.name);
                    GUILayout.Label("  Position: " + bone.transform.position);
                    GUILayout.Label("  Rotation: " + bone.transform.rotation.eulerAngles);
                    GUILayout.Label("  Scale: " + bone.transform.localScale);
                }
            }

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private static void BuildBoneTree()
        {
            bones.Clear();
            if (targetObject == null) return;
            CollectBones(targetObject.transform, null);
        }

        private static void CollectBones(Transform t, Transform parent)
        {
            if (t == null) return;
            var bone = new BoneInfo
            {
                transform = t,
                name = t.name,
                parent = parent,
                position = t.position,
                rotation = t.rotation,
                localPosition = t.localPosition,
                localRotation = t.localRotation,
                lossyScale = t.lossyScale
            };
            foreach (Transform child in t)
            {
                bone.children.Add(child);
                CollectBones(child, t);
            }
            bones.Add(bone);
        }

        private static void CreateVisuals()
        {
            ClearVisuals();
            if (targetObject == null) return;
            if (showSkeleton) { CreateBoneLines(); CreateBoneMarkers(); }
            if (showOutline) CreateOutline();
        }

        private static void CreateBoneLines()
        {
            if (lineMaterial == null)
            {
                lineMaterial = new Material(Shader.Find("Sprites/Default"));
                lineMaterial.hideFlags = HideFlags.DontSave;
            }

            foreach (var bone in bones)
            {
                if (bone.transform == null) continue;
                foreach (var child in bone.children)
                {
                    if (child == null) continue;
                    GameObject lineObj = new GameObject("BoneLine_" + bone.name + "_" + child.name);
                    lineObj.transform.SetParent(targetObject.transform, false);
                    lineObj.hideFlags = HideFlags.DontSave;
                    LineRenderer lr = lineObj.AddComponent<LineRenderer>();
                    lr.material = lineMaterial;
                    lr.startColor = boneColor;
                    lr.endColor = boneColor;
                    lr.startWidth = lineWidth;
                    lr.endWidth = lineWidth;
                    lr.positionCount = 2;
                    lr.SetPosition(0, bone.transform.position);
                    lr.SetPosition(1, child.position);
                    boneLines.Add(lr);
                }
            }
        }

        private static void CreateBoneMarkers()
        {
            foreach (var bone in bones)
            {
                if (bone.transform == null) continue;
                GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                marker.name = "BoneMarker_" + bone.name;
                marker.transform.SetParent(targetObject.transform, false);
                marker.transform.position = bone.transform.position;
                marker.transform.localScale = Vector3.one * 0.05f;
                marker.hideFlags = HideFlags.DontSave;
                Renderer renderer = marker.GetComponent<Renderer>();
                if (renderer != null)
                {
                    renderer.material.color = boneColor;
                    renderer.material.hideFlags = HideFlags.DontSave;
                }
                boneMarkers.Add(marker);
            }
        }

        private static void CreateOutline()
        {
            if (targetObject == null) return;
            Renderer[] renderers = targetObject.GetComponentsInChildren<Renderer>();
            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;
                Bounds bounds = renderer.bounds;
                GameObject outlineObj = new GameObject("Outline_" + renderer.name);
                outlineObj.transform.SetParent(targetObject.transform, false);
                outlineObj.hideFlags = HideFlags.DontSave;
                LineRenderer lr = outlineObj.AddComponent<LineRenderer>();
                lr.material = lineMaterial;
                lr.startColor = Color.green;
                lr.endColor = Color.green;
                lr.startWidth = 0.015f;
                lr.endWidth = 0.015f;
                Vector3[] corners = GetBoundsCorners(bounds);
                lr.positionCount = corners.Length;
                lr.SetPositions(corners);
                boneLines.Add(lr);
            }
        }

        private static Vector3[] GetBoundsCorners(Bounds bounds)
        {
            Vector3 center = bounds.center;
            Vector3 extents = bounds.extents;
            Vector3[] corners = new Vector3[]
            {
                center + new Vector3(-extents.x, -extents.y, -extents.z),
                center + new Vector3( extents.x, -extents.y, -extents.z),
                center + new Vector3( extents.x,  extents.y, -extents.z),
                center + new Vector3(-extents.x,  extents.y, -extents.z),
                center + new Vector3(-extents.x, -extents.y,  extents.z),
                center + new Vector3( extents.x, -extents.y,  extents.z),
                center + new Vector3( extents.x,  extents.y,  extents.z),
                center + new Vector3(-extents.x,  extents.y,  extents.z)
            };
            return new Vector3[]
            {
                corners[0], corners[1], corners[2], corners[3], corners[0],
                corners[4], corners[5], corners[6], corners[7], corners[4],
                corners[0], corners[4],
                corners[1], corners[5],
                corners[2], corners[6],
                corners[3], corners[7]
            };
        }

        private static void HighlightBone(BoneInfo bone)
        {
            if (bone == null || bone.transform == null) return;
            foreach (var marker in boneMarkers)
            {
                if (marker == null) continue;
                Renderer r = marker.GetComponent<Renderer>();
                if (r != null) r.material.color = boneColor;
                marker.transform.localScale = Vector3.one * 0.05f;
            }
            foreach (var marker in boneMarkers)
            {
                if (marker == null) continue;
                if (marker.name == "BoneMarker_" + bone.name)
                {
                    Renderer r = marker.GetComponent<Renderer>();
                    if (r != null) r.material.color = Color.yellow;
                    marker.transform.localScale = Vector3.one * 0.1f;
                    break;
                }
            }
        }

        private static void UpdateColors()
        {
            foreach (var lr in boneLines)
                if (lr != null) { lr.startColor = boneColor; lr.endColor = boneColor; }
        }

        private static void ClearVisuals()
        {
            foreach (var lr in boneLines)
                if (lr != null && lr.gameObject != null) UnityEngine.Object.Destroy(lr.gameObject);
            boneLines.Clear();
            foreach (var marker in boneMarkers)
                if (marker != null) UnityEngine.Object.Destroy(marker);
            boneMarkers.Clear();
        }

        public static void ShowBones(GameObject obj) { Toggle(obj); }
        public static void HideBones() { Hide(); }
    }
}
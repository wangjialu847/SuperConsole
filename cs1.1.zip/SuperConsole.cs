﻿using BepInEx;
using HarmonyLib;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CSharp;
using SuperConsole;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SuperConsole
{
    // ============================================================
    // 1. 命令模板类
    // ============================================================
    public class CommandTemplate
    {
        public string name;
        public string code;
        public string desc;
        public CommandTemplate(string name, string code, string desc)
        {
            this.name = name;
            this.code = code;
            this.desc = desc;
        }
    }

    // ============================================================
    // 2. 内存搜索结果类
    // ============================================================
    public class MemoryResult
    {
        public GameObject gameObject;
        public Component component;
        public FieldInfo fieldInfo;
        public PropertyInfo propertyInfo;
        public object value;
        public string valueType;
        public string objectName;
        public string memberName;
        public bool isField;
    }

    // ============================================================
    // 3. 内存搜索辅助类
    // ============================================================
    public static class MemorySearcher
    {
        public static readonly Type[] SupportedTypes = new Type[]
        {
            typeof(float), typeof(double), typeof(decimal),
            typeof(int), typeof(uint), typeof(long), typeof(ulong),
            typeof(short), typeof(ushort), typeof(byte), typeof(sbyte),
            typeof(bool), typeof(string),
            typeof(Vector2), typeof(Vector3), typeof(Vector4),
            typeof(Quaternion), typeof(Color)
        };

        public static bool IsNumericType(Type type)
        {
            return type == typeof(float) || type == typeof(double) || type == typeof(decimal) ||
                   type == typeof(int) || type == typeof(uint) || type == typeof(long) || type == typeof(ulong) ||
                   type == typeof(short) || type == typeof(ushort) || type == typeof(byte) || type == typeof(sbyte);
        }

        public static bool IsValueType(Type type)
        {
            return IsNumericType(type) || type == typeof(bool) || type == typeof(string);
        }

        public static double GetNumericValue(object obj)
        {
            if (obj == null) return 0;
            Type t = obj.GetType();
            if (t == typeof(float)) return (float)obj;
            if (t == typeof(double)) return (double)obj;
            if (t == typeof(decimal)) return (double)(decimal)obj;
            if (t == typeof(int)) return (int)obj;
            if (t == typeof(uint)) return (uint)obj;
            if (t == typeof(long)) return (long)obj;
            if (t == typeof(ulong)) return (ulong)obj;
            if (t == typeof(short)) return (short)obj;
            if (t == typeof(ushort)) return (ushort)obj;
            if (t == typeof(byte)) return (byte)obj;
            if (t == typeof(sbyte)) return (sbyte)obj;
            return 0;
        }

        public static string GetValueString(object obj)
        {
            if (obj == null) return "null";
            Type t = obj.GetType();
            if (t == typeof(Vector2)) return ((Vector2)obj).ToString();
            if (t == typeof(Vector3)) return ((Vector3)obj).ToString();
            if (t == typeof(Quaternion)) return ((Quaternion)obj).eulerAngles.ToString();
            if (t == typeof(Color)) return ((Color)obj).ToString();
            if (t == typeof(string)) return (string)obj;
            if (IsNumericType(t))
            {
                double val = GetNumericValue(obj);
                if (val == Math.Floor(val)) return ((long)val).ToString();
                return val.ToString("F4");
            }
            if (t == typeof(bool)) return ((bool)obj).ToString();
            return obj.ToString();
        }
    }

    // ============================================================
    // 4. 对象锁定系统
    // ============================================================
    public static class ObjectLocker
    {
        private class LockedObject
        {
            public string objectName;
            public string componentType;
            public string fieldName;
            public object targetValue;
            public bool isActive = true;
        }

        private static Dictionary<string, LockedObject> lockedObjects = new Dictionary<string, LockedObject>();
        private static bool isRunning = false;
        private static float updateInterval = 0.1f;
        private static float timer = 0f;

        public static void Lock(string objectName, string componentType, string fieldName, object value)
        {
            string key = objectName + "." + componentType + "." + fieldName;
            if (!lockedObjects.ContainsKey(key))
            {
                lockedObjects[key] = new LockedObject
                {
                    objectName = objectName,
                    componentType = componentType,
                    fieldName = fieldName,
                    targetValue = value,
                    isActive = true
                };
                if (!isRunning) StartLocker();
                Debug.Log("锁已锁定: " + key + " = " + value);
            }
            else
            {
                lockedObjects[key].targetValue = value;
                Debug.Log("更新锁定: " + key + " = " + value);
            }
        }

        public static void LockSelectedAll(GameObject obj)
        {
            if (obj == null) { Debug.Log("对象为空"); return; }
            Component[] comps = obj.GetComponents<Component>();
            foreach (var comp in comps)
            {
                if (comp == null) continue;
                var fields = comp.GetType().GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (var field in fields)
                {
                    if (field.Name.StartsWith("m_") || field.Name.StartsWith("<")) continue;
                    if (field.FieldType == typeof(float) || field.FieldType == typeof(int) || field.FieldType == typeof(bool))
                    {
                        object val = field.GetValue(comp);
                        if (val != null) Lock(obj.name, comp.GetType().Name, field.Name, val);
                    }
                }
            }
            Debug.Log("已锁定 " + obj.name + " 的所有数值字段");
        }

        public static void UnlockObject(GameObject obj)
        {
            if (obj == null) { Debug.Log("对象为空"); return; }

            List<string> keysToRemove = new List<string>();
            foreach (var kv in lockedObjects)
            {
                if (kv.Value.objectName == obj.name)
                {
                    keysToRemove.Add(kv.Key);
                }
            }

            foreach (var key in keysToRemove)
            {
                lockedObjects.Remove(key);
                Debug.Log("已解锁: " + key);
            }

            if (keysToRemove.Count == 0)
            {
                Debug.Log("该对象没有激活的锁定: " + obj.name);
            }
        }

        public static void Unlock(string objectName, string componentType, string fieldName)
        {
            string key = objectName + "." + componentType + "." + fieldName;
            if (lockedObjects.ContainsKey(key))
            {
                lockedObjects.Remove(key);
                Debug.Log("已解锁: " + key);
            }
            else
            {
                Debug.Log("找不到该锁定: " + key);
            }
        }

        public static void UnlockAll()
        {
            lockedObjects.Clear();
            isRunning = false;
            Debug.Log("已解锁所有");
        }

        public static void StartLocker()
        {
            isRunning = true;
            Debug.Log("对象锁定系统已启动");
        }

        public static void StopLocker()
        {
            isRunning = false;
            Debug.Log("对象锁定系统已停止");
        }

        public static void Update()
        {
            if (!isRunning || lockedObjects.Count == 0) return;
            timer += Time.deltaTime;
            if (timer < updateInterval) return;
            timer = 0f;

            foreach (var kv in lockedObjects)
            {
                var locked = kv.Value;
                if (!locked.isActive) continue;
                try
                {
                    GameObject obj = GameObject.Find(locked.objectName);
                    if (obj == null) continue;
                    Component[] comps = obj.GetComponents<Component>();
                    foreach (var comp in comps)
                    {
                        if (comp == null) continue;
                        if (comp.GetType().Name != locked.componentType && comp.GetType().FullName != locked.componentType)
                            continue;
                        var field = comp.GetType().GetField(locked.fieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                        if (field != null) field.SetValue(comp, locked.targetValue);
                    }
                }
                catch { }
            }
        }

        public static string GetStatus()
        {
            if (lockedObjects.Count == 0) return "没有激活的锁定";
            string result = "激活的锁定:\n";
            foreach (var kv in lockedObjects)
            {
                var locked = kv.Value;
                result += "  - " + kv.Key + " = " + locked.targetValue + (locked.isActive ? " 已启用" : " 已禁用") + "\n";
            }
            return result;
        }
    }

    // ============================================================
    // 5. 对象编辑器（修复版）
    // ============================================================
    public static class ObjectEditor
    {
        public static void SetPosition(GameObject obj, Vector3 pos)
        {
            if (obj == null) return;
            obj.transform.position = pos;
            Debug.Log("已移动 " + obj.name + " 到 " + pos);
        }

        public static void SetScale(GameObject obj, Vector3 scale)
        {
            if (obj == null) return;
            obj.transform.localScale = scale;
            Debug.Log("已缩放 " + obj.name + " 到 " + scale);
        }

        public static void SetRotation(GameObject obj, Vector3 rotation)
        {
            if (obj == null) return;
            obj.transform.rotation = Quaternion.Euler(rotation);
            Debug.Log("已旋转 " + obj.name + " 到 " + rotation);
        }

        public static void TeleportTo(GameObject obj, GameObject target)
        {
            if (obj == null || target == null) return;
            obj.transform.position = target.transform.position;
            Debug.Log("已传送 " + obj.name + " 到 " + target.name + " 的位置");
        }

        public static void Duplicate(GameObject obj)
        {
            if (obj == null) return;
            GameObject copy = UnityEngine.Object.Instantiate(obj, obj.transform.position, obj.transform.rotation);
            copy.name = obj.name + "_Copy";
            Debug.Log("已复制 " + obj.name + " -> " + copy.name);
        }

        public static void Delete(GameObject obj)
        {
            if (obj == null) return;
            Debug.Log("已删除 " + obj.name);
            UnityEngine.Object.Destroy(obj);
        }

        public static void DeleteAll(string nameFilter)
        {
            GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
            int count = 0;
            foreach (var obj in allObjects)
            {
                if (obj != null && !string.IsNullOrEmpty(obj.scene.name) &&
                    obj.name.ToLower().Contains(nameFilter.ToLower()))
                {
                    UnityEngine.Object.Destroy(obj);
                    count++;
                }
            }
            Debug.Log("已删除 " + count + " 个包含 '" + nameFilter + "' 的对象");
        }

        // ✅ 修复：添加组件（不再崩溃）
        public static void AddComponent(GameObject obj, string componentTypeName)
        {
            if (obj == null) return;
            try
            {
                Type componentType = FindTypeByName(componentTypeName);
                if (componentType != null && typeof(Component).IsAssignableFrom(componentType))
                {
                    // 检查是否已有该组件
                    if (obj.GetComponent(componentType) != null)
                    {
                        Debug.Log($"对象 {obj.name} 已有组件 {componentTypeName}");
                        return;
                    }
                    obj.AddComponent(componentType);
                    Debug.Log($"✅ 已添加组件 {componentTypeName} 到 {obj.name}");
                }
                else
                {
                    Debug.Log($"❌ 找不到组件类型: {componentTypeName}");
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"添加组件失败: {ex.Message}");
            }
        }

        public static void RemoveComponent(GameObject obj, string componentTypeName)
        {
            if (obj == null) return;
            try
            {
                Type componentType = FindTypeByName(componentTypeName);
                if (componentType != null && typeof(Component).IsAssignableFrom(componentType))
                {
                    Component comp = obj.GetComponent(componentType);
                    if (comp != null)
                    {
                        UnityEngine.Object.Destroy(comp);
                        Debug.Log("已移除组件 " + componentTypeName + " 从 " + obj.name);
                    }
                    else
                    {
                        Debug.Log("对象 " + obj.name + " 没有组件 " + componentTypeName);
                    }
                }
                else
                {
                    Debug.Log("找不到组件类型: " + componentTypeName);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("移除组件失败: " + ex.Message);
            }
        }

        // ✅ 修复：查找类型（支持短名称）
        private static Type FindTypeByName(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;

            // 尝试直接查找
            Type t = Type.GetType(typeName);
            if (t != null) return t;

            // 尝试在所有程序集中查找
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    foreach (var type in asm.GetTypes())
                    {
                        if (type.Name == typeName || type.FullName == typeName)
                            return type;
                    }
                }
                catch { }
            }

            // 尝试常见 Unity 组件
            string[] commonTypes = new string[]
            {
                "UnityEngine.Transform, UnityEngine.CoreModule",
                "UnityEngine.MeshFilter, UnityEngine.CoreModule",
                "UnityEngine.MeshRenderer, UnityEngine.CoreModule",
                "UnityEngine.SkinnedMeshRenderer, UnityEngine.CoreModule",
                "UnityEngine.BoxCollider, UnityEngine.CoreModule",
                "UnityEngine.SphereCollider, UnityEngine.CoreModule",
                "UnityEngine.CapsuleCollider, UnityEngine.CoreModule",
                "UnityEngine.MeshCollider, UnityEngine.CoreModule",
                "UnityEngine.Rigidbody, UnityEngine.CoreModule",
                "UnityEngine.Animator, UnityEngine.CoreModule",
                "UnityEngine.Animation, UnityEngine.CoreModule",
                "UnityEngine.AudioSource, UnityEngine.CoreModule",
                "UnityEngine.Light, UnityEngine.CoreModule",
                "UnityEngine.Camera, UnityEngine.CoreModule",
                "UnityEngine.ParticleSystem, UnityEngine.CoreModule",
                "UnityEngine.Canvas, UnityEngine.UI",
                "UnityEngine.UI.Image, UnityEngine.UI",
                "UnityEngine.UI.Text, UnityEngine.UI",
                "UnityEngine.UI.Button, UnityEngine.UI",
                "UnityEngine.RectTransform, UnityEngine.CoreModule"
            };

            foreach (string fullName in commonTypes)
            {
                t = Type.GetType(fullName);
                if (t != null && t.Name == typeName)
                    return t;
            }

            return null;
        }
    }

    // ============================================================
    // 6. Hook 管理器（内置）
    // ============================================================
    public static class HookManagerBuiltin
    {
        private static Harmony harmony = new Harmony("SuperConsole.Hooks");
        private static Dictionary<string, bool> activeHooks = new Dictionary<string, bool>();
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 500, 400);
        private static Vector2 scrollPos = Vector2.zero;
        private static string searchText = "";
        private static List<HookEntry> hookEntries = new List<HookEntry>();
        private static List<HookEntry> filteredEntries = new List<HookEntry>();

        public class HookEntry
        {
            public string displayName;
            public string typeName;
            public string methodName;
            public string description;
            public HookEntry(string displayName, string typeName, string methodName, string description)
            {
                this.displayName = displayName;
                this.typeName = typeName;
                this.methodName = methodName;
                this.description = description;
            }
        }

        static HookManagerBuiltin()
        {
            hookEntries.Add(new HookEntry("禁用晕倒", "RagdollController", "Knockout", "阻止 Knockout 执行"));
            hookEntries.Add(new HookEntry("禁用伤害", "PlayerCharacter", "TakeDamage", "阻止 TakeDamage 执行"));
            hookEntries.Add(new HookEntry("禁用死亡", "PlayerCharacter", "Die", "阻止 Die 执行"));
            hookEntries.Add(new HookEntry("禁用扣血", "PlayerCharacter", "ApplyDamage", "阻止 ApplyDamage 执行"));
            hookEntries.Add(new HookEntry("禁用重力", "Rigidbody", "UpdateGravity", "阻止重力更新"));
            hookEntries.Add(new HookEntry("禁用物理", "Physics", "Simulate", "阻止物理模拟"));
        }

        public static void Toggle() { visible = !visible; if (visible) RefreshFilter(); }
        public static void RefreshFilter()
        {
            filteredEntries.Clear();
            foreach (var entry in hookEntries)
            {
                if (string.IsNullOrEmpty(searchText) ||
                    entry.displayName.ToLower().Contains(searchText.ToLower()) ||
                    entry.typeName.ToLower().Contains(searchText.ToLower()) ||
                    entry.methodName.ToLower().Contains(searchText.ToLower()))
                {
                    filteredEntries.Add(entry);
                }
            }
        }

        public static void Draw()
        {
            if (!visible) return;
            windowRect = GUI.Window(12349, windowRect, DrawWindow, "Hook 管理器 [Home键关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Home)
            {
                visible = false;
                return;
            }

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(50));
            string newSearch = GUILayout.TextField(searchText, GUILayout.ExpandWidth(true));
            if (newSearch != searchText) { searchText = newSearch; RefreshFilter(); }
            if (GUILayout.Button("刷新", GUILayout.Width(50))) RefreshFilter();
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("安装所有")) InstallAll();
            if (GUILayout.Button("卸载所有")) UninstallAll();
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            if (filteredEntries.Count == 0)
            {
                GUILayout.Label("没有匹配的 Hook 预设");
            }
            else
            {
                foreach (var entry in filteredEntries)
                {
                    GUILayout.BeginVertical("box");

                    GUILayout.BeginHorizontal();
                    GUILayout.Label(entry.displayName, GUILayout.Width(100));
                    GUILayout.Label(entry.typeName + "." + entry.methodName, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.Label(entry.description, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    bool isActive = activeHooks.ContainsKey(entry.typeName + "." + entry.methodName) && activeHooks[entry.typeName + "." + entry.methodName];
                    GUILayout.Label(isActive ? "已安装" : "未安装", GUILayout.Width(100));
                    if (GUILayout.Button(isActive ? "卸载" : "安装", GUILayout.Width(60)))
                    {
                        if (isActive) UninstallHook(entry);
                        else InstallHook(entry);
                    }
                    GUILayout.EndHorizontal();

                    GUILayout.EndVertical();
                    GUILayout.Space(2);
                }
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label("共 " + filteredEntries.Count + " 个预设", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("关闭", GUILayout.Width(80))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            Rect dragRect = new Rect(0, 0, windowRect.width, 20);
            GUI.DragWindow(dragRect);
        }

        public static void InstallHook(HookEntry entry)
        {
            try
            {
                Type targetType = FindTypeByName(entry.typeName);
                if (targetType == null) { Debug.Log("找不到类型: " + entry.typeName); return; }

                var method = AccessTools.Method(targetType, entry.methodName);
                if (method == null) { Debug.Log("找不到方法: " + entry.methodName); return; }

                string key = entry.typeName + "." + entry.methodName;
                if (activeHooks.ContainsKey(key) && activeHooks[key]) { Debug.Log("Hook 已存在"); return; }

                harmony.Patch(method, prefix: new HarmonyMethod(typeof(HookManagerBuiltin), nameof(Prefix)));
                activeHooks[key] = true;
                Debug.Log("Hook 已安装: " + entry.displayName);
            }
            catch (Exception ex) { Debug.Log("Hook 失败: " + ex.Message); }
        }

        public static void UninstallHook(HookEntry entry)
        {
            string key = entry.typeName + "." + entry.methodName;
            if (activeHooks.ContainsKey(key)) activeHooks.Remove(key);
            Debug.Log("已卸载: " + entry.displayName);
        }

        public static void InstallAll()
        {
            foreach (var entry in hookEntries) InstallHook(entry);
        }

        public static void UninstallAll()
        {
            harmony.UnpatchSelf();
            activeHooks.Clear();
            Debug.Log("所有 Hook 已卸载");
        }

        public static bool Prefix() { return false; }

        private static Type FindTypeByName(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;
            Type t = Type.GetType(typeName);
            if (t != null) return t;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    foreach (var type in asm.GetTypes())
                    {
                        if (type.Name == typeName || type.FullName == typeName)
                            return type;
                    }
                }
                catch { }
            }
            return null;
        }
    }

    // ============================================================
    // 7. 方法管理器（内置）
    // ============================================================
    public static class MethodManagerBuiltin
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 600, 500);
        private static Vector2 scrollPos = Vector2.zero;
        private static string searchText = "";
        private static List<MethodEntry> methodEntries = new List<MethodEntry>();
        private static List<MethodEntry> filteredEntries = new List<MethodEntry>();
        private static Harmony harmony = new Harmony("MethodManager.Hooks");
        private static Dictionary<string, bool> activeHooks = new Dictionary<string, bool>();

        public class MethodEntry
        {
            public string displayName;
            public string typeName;
            public string methodName;
            public string description;
            public MethodEntry(string displayName, string typeName, string methodName, string description)
            {
                this.displayName = displayName;
                this.typeName = typeName;
                this.methodName = methodName;
                this.description = description;
            }
        }

        static MethodManagerBuiltin()
        {
            methodEntries.Add(new MethodEntry("Knockout", "RagdollController", "Knockout", "晕倒方法"));
            methodEntries.Add(new MethodEntry("TakeDamage", "PlayerCharacter", "TakeDamage", "受伤方法"));
            methodEntries.Add(new MethodEntry("Die", "PlayerCharacter", "Die", "死亡方法"));
            methodEntries.Add(new MethodEntry("ApplyDamage", "PlayerCharacter", "ApplyDamage", "应用伤害"));
            methodEntries.Add(new MethodEntry("Heal", "PlayerCharacter", "Heal", "治疗方法"));
            methodEntries.Add(new MethodEntry("Revive", "PlayerCharacter", "Revive", "复活方法"));
            methodEntries.Add(new MethodEntry("SetSpeed", "PlayerCharacterMovement", "SetSpeed", "设置速度"));
            methodEntries.Add(new MethodEntry("Jump", "PlayerCharacterMovement", "Jump", "跳跃方法"));
        }

        public static void Toggle() { visible = !visible; if (visible) RefreshFilter(); }
        public static void RefreshFilter()
        {
            filteredEntries.Clear();
            foreach (var entry in methodEntries)
            {
                if (string.IsNullOrEmpty(searchText) ||
                    entry.displayName.ToLower().Contains(searchText.ToLower()) ||
                    entry.typeName.ToLower().Contains(searchText.ToLower()) ||
                    entry.methodName.ToLower().Contains(searchText.ToLower()))
                {
                    filteredEntries.Add(entry);
                }
            }
        }

        public static void Draw()
        {
            if (!visible) return;
            windowRect = GUI.Window(12350, windowRect, DrawWindow, "方法管理器 [End键关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.End)
            {
                visible = false;
                return;
            }

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(50));
            string newSearch = GUILayout.TextField(searchText, GUILayout.ExpandWidth(true));
            if (newSearch != searchText) { searchText = newSearch; RefreshFilter(); }
            if (GUILayout.Button("刷新", GUILayout.Width(50))) RefreshFilter();
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            if (filteredEntries.Count == 0)
            {
                GUILayout.Label("没有匹配的方法预设");
            }
            else
            {
                foreach (var entry in filteredEntries)
                {
                    GUILayout.BeginVertical("box");

                    GUILayout.BeginHorizontal();
                    GUILayout.Label(entry.displayName, GUILayout.Width(120));
                    GUILayout.Label(entry.typeName + "." + entry.methodName, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.Label(entry.description, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();

                    if (GUILayout.Button("执行", GUILayout.Width(60)))
                    {
                        ExecuteMethod(entry);
                    }

                    bool isBlocked = activeHooks.ContainsKey(entry.typeName + "." + entry.methodName) && activeHooks[entry.typeName + "." + entry.methodName];
                    if (GUILayout.Button(isBlocked ? "解除拦截" : "拦截", GUILayout.Width(80)))
                    {
                        if (isBlocked) UnblockMethod(entry);
                        else BlockMethod(entry);
                    }

                    GUILayout.Label(isBlocked ? "已拦截" : "正常", GUILayout.Width(80));

                    GUILayout.EndHorizontal();

                    GUILayout.EndVertical();
                    GUILayout.Space(2);
                }
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label("共 " + filteredEntries.Count + " 个方法", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("拦截所有", GUILayout.Width(80))) BlockAll();
            if (GUILayout.Button("解除所有", GUILayout.Width(80))) UnblockAll();
            if (GUILayout.Button("关闭", GUILayout.Width(80))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        public static void ExecuteMethod(MethodEntry entry)
        {
            try
            {
                Type targetType = FindTypeByName(entry.typeName);
                if (targetType == null) { Debug.Log("找不到类型: " + entry.typeName); return; }

                var method = AccessTools.Method(targetType, entry.methodName);
                if (method == null) { Debug.Log("找不到方法: " + entry.methodName); return; }

                if (method.IsStatic)
                {
                    method.Invoke(null, null);
                    Debug.Log("已执行: " + entry.displayName + " (静态)");
                    return;
                }

                object instance = null;
                if (typeof(Component).IsAssignableFrom(targetType))
                {
                    instance = UnityEngine.Object.FindObjectOfType(targetType);
                }

                if (instance == null) { Debug.Log("找不到该类型的实例"); return; }

                var result = method.Invoke(instance, null);
                Debug.Log("已执行: " + entry.displayName + (result != null ? " -> 返回值: " + result : ""));
            }
            catch (Exception ex) { Debug.Log("执行失败: " + ex.Message); }
        }

        public static void BlockMethod(MethodEntry entry)
        {
            try
            {
                Type targetType = FindTypeByName(entry.typeName);
                if (targetType == null) { Debug.Log("找不到类型: " + entry.typeName); return; }

                var method = AccessTools.Method(targetType, entry.methodName);
                if (method == null) { Debug.Log("找不到方法: " + entry.methodName); return; }

                string key = entry.typeName + "." + entry.methodName;
                if (activeHooks.ContainsKey(key) && activeHooks[key]) { Debug.Log("该方法已被拦截"); return; }

                harmony.Patch(method, prefix: new HarmonyMethod(typeof(MethodManagerBuiltin), nameof(Prefix)));
                activeHooks[key] = true;
                Debug.Log("已拦截: " + entry.displayName);
            }
            catch (Exception ex) { Debug.Log("拦截失败: " + ex.Message); }
        }

        public static void UnblockMethod(MethodEntry entry)
        {
            string key = entry.typeName + "." + entry.methodName;
            if (activeHooks.ContainsKey(key)) activeHooks.Remove(key);
            Debug.Log("已解除拦截: " + entry.displayName);
        }

        public static void BlockAll()
        {
            foreach (var entry in methodEntries) BlockMethod(entry);
        }

        public static void UnblockAll()
        {
            harmony.UnpatchSelf();
            activeHooks.Clear();
            Debug.Log("已解除所有拦截");
        }

        public static bool Prefix() { return false; }

        private static Type FindTypeByName(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;
            Type t = Type.GetType(typeName);
            if (t != null) return t;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    foreach (var type in asm.GetTypes())
                    {
                        if (type.Name == typeName || type.FullName == typeName)
                            return type;
                    }
                }
                catch { }
            }
            return null;
        }
    }

    // ============================================================
    // 8. 主插件 - 超级控制台（完整版）
    // ============================================================
    [BepInPlugin("com.example.superconsole", "超级控制台", "1.0.0")]
    public class SuperConsole : BaseUnityPlugin
    {
        // ===== 控制台状态 =====
        private bool consoleVisible = false;
        private string inputText = "";
        private static List<string> outputLogs = new List<string>();
        private Rect consoleRect = new Rect(50, 50, 600, 500);
        private Vector2 scrollPosition = Vector2.zero;
        private static string currentOutput = "";

        // ===== 字典 =====
        private bool dictVisible = false;
        private Rect dictRect = new Rect(100, 100, 700, 500);
        private Vector2 dictScroll = Vector2.zero;
        private string searchText = "";
        private List<CommandTemplate> templates = new List<CommandTemplate>();

        // ===== 内存搜索 =====
        private bool memSearchVisible = false;
        private Rect memRect = new Rect(100, 100, 800, 650);
        private Vector2 memScroll = Vector2.zero;
        private string memSearchInput = "";
        private string memSearchMode = "精确";
        private string memValueType = "自动";
        private string memSearchValue2 = "";
        private bool memSearchAllFields = true;
        private bool memIncludePrivate = true;
        private bool memSearchProperties = false;
        private string memTypeFilter = "";
        private List<MemoryResult> memResults = new List<MemoryResult>();
        private List<MemoryResult> memPreviousResults = new List<MemoryResult>();
        private bool memHasResults = false;
        private string memStatus = "就绪";
        private string memModifyInput = "";
        private int memSelectedIndex = -1;

        // ===== 对象浏览器 =====
        private bool objectBrowserVisible = false;
        private Rect browserRect = new Rect(0, 0, Screen.width, Screen.height);
        private Vector2 browserScroll = Vector2.zero;
        private Vector2 inspectorScroll = Vector2.zero;
        private string browserSearchText = "";
        private string componentSearchText = "";
        private string addComponentInput = "";
        private List<GameObject> searchResults = new List<GameObject>();
        public static GameObject selectedObject = null;
        private Dictionary<Component, bool> componentExpanded = new Dictionary<Component, bool>();
        private Dictionary<Transform, bool> hierarchyExpanded = new Dictionary<Transform, bool>();

        // ===== 自动补全 =====
        private bool showAutoComplete = false;
        private int autoCompleteIndex = -1;
        private List<string> autoCompleteList = new List<string>();
        private Vector2 autoCompleteScroll = Vector2.zero;
        private Rect autoCompleteRect = Rect.zero;
        private const string AUTOCOMPLETE_CONTROL = "browserAutoComplete";

        private bool hookUIVisible = false;
        private bool methodUIVisible = false;
        private string focusedWindow = "console";

        // ===== 窗口缩放 =====
        private bool isResizingConsole = false;
        private bool isResizingDict = false;
        private bool isResizingMem = false;
        private bool isResizingBrowser = false;
        private Vector2 resizeStartMouse;
        private Vector2 resizeStartSize;

        // ===== 自由视角 =====
        private bool freeCameraEnabled = false;
        private float freeCamSpeed = 10f;
        private float freeCamSensitivity = 2f;
        private Vector3 freeCamPosition;
        private Quaternion freeCamRotation;
        private Camera mainCamera;
        private Vector3 originalCameraPos;
        private Quaternion originalCameraRot;

        private GameObject ctrlSelectedObject = null;

        // ============================================================
        // Awake
        // ============================================================
        void Awake()
        {
            CreateDirectories();

            ExtensionCommands.OnOutput = (msg) => {
                AddOutput(msg);
            };

            HelpSystem.AutoExport();
            ExtensionLoader.LoadAll();
            LogicManagerV2.Initialize();

            Logger.LogInfo("超级控制台已加载！按 Insert 键召唤。");
            Logger.LogInfo("按 Home 键打开 Hook 管理器 | 按 End 键打开方法管理器");
            Logger.LogInfo("Ctrl+左键 选择物体 | 自由视角: 按 F 切换");
            InitTemplates();
            RefreshScene();
        }

        // ============================================================
        // 创建目录
        // ============================================================
        private void CreateDirectories()
        {
            string basePath = Path.Combine(Paths.PluginPath, "SuperConsole");
            string[] dirs = new string[]
            {
                basePath,
                Path.Combine(basePath, "Assets"),
                Path.Combine(basePath, "Assets", "Models"),
                Path.Combine(basePath, "Assets", "Textures"),
                Path.Combine(basePath, "Assets", "Audio"),
                Path.Combine(basePath, "Assets", "Prefabs"),
                Path.Combine(basePath, "Assets", "Animations"),
                Path.Combine(basePath, "Assets", "Materials"),
                Path.Combine(basePath, "extensions"),
                Path.Combine(basePath, "extensions", "Disabled"),
                Path.Combine(basePath, "logics"),
                Path.Combine(basePath, "scripts"),
                Path.Combine(basePath, "Hooks"),
                Path.Combine(basePath, "config"),
            };

            foreach (string dir in dirs)
            {
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
            }
        }

        // ============================================================
        // 初始化模板
        // ============================================================
        void InitTemplates()
        {
            templates.Add(new CommandTemplate("查找对象", "GameObject.Find(\"对象名\");", "按名字查找游戏对象"));
            templates.Add(new CommandTemplate("获取组件", "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<组件名>();", "获取对象上的组件"));
            templates.Add(new CommandTemplate("修改数值", "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<PlayerCharacter>().字段名 = 新值;", "修改任何字段"));
            templates.Add(new CommandTemplate("修改速度", "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<PlayerCharacterMovement>().speedMultiplier = 999f;", "修改移动速度"));
            templates.Add(new CommandTemplate("禁用组件", "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<RagdollController>().enabled = false;", "禁用组件"));
            templates.Add(new CommandTemplate("瞬移", "GameObject.Find(\"PlayerCharacter(Clone)\").transform.position = new Vector3(X, Y, Z);", "瞬移到指定坐标"));
            templates.Add(new CommandTemplate("修改血量", "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<PlayerCharacter>().health = 9999;", "修改玩家血量"));
            templates.Add(new CommandTemplate("游戏速度", "Time.timeScale = 5f;", "修改游戏速度"));
            templates.Add(new CommandTemplate("遍历所有玩家", "PlayerCharacter[] players = FindObjectsOfType<PlayerCharacter>(); foreach (var p in players) { p.health = 9999; }", "修改所有玩家"));
            templates.Add(new CommandTemplate("输出日志", "Debug.Log(\"消息内容\");", "在控制台输出消息"));
            templates.Add(new CommandTemplate("锁定速度", "ObjectLocker.Lock(\"PlayerCharacter(Clone)\", \"PlayerCharacterMovement\", \"speedMultiplier\", 999f);", "锁定速度"));
            templates.Add(new CommandTemplate("查看锁定", "ObjectLocker.GetStatus();", "查看所有激活的锁定"));
            templates.Add(new CommandTemplate("解锁所有", "ObjectLocker.UnlockAll();", "解除所有锁定"));
            templates.Add(new CommandTemplate("启动锁定系统", "ObjectLocker.StartLocker();", "启动对象锁定系统"));
            templates.Add(new CommandTemplate("删除对象", "ObjectEditor.Delete(GameObject.Find(\"对象名\"));", "删除指定对象"));
            templates.Add(new CommandTemplate("复制对象", "ObjectEditor.Duplicate(GameObject.Find(\"对象名\"));", "复制指定对象"));
            templates.Add(new CommandTemplate("传送对象", "ObjectEditor.TeleportTo(GameObject.Find(\"对象1\"), GameObject.Find(\"对象2\"));", "传送对象1到对象2的位置"));
            templates.Add(new CommandTemplate("添加组件", "ObjectEditor.AddComponent(GameObject.Find(\"对象名\"), \"组件类型名\");", "添加组件到对象"));
        }

        // ============================================================
        // 刷新场景
        // ============================================================
        void RefreshScene()
        {
            searchResults.Clear();
            hierarchyExpanded.Clear();
            GameObject[] rootObjects = SceneManager.GetActiveScene().GetRootGameObjects();
            searchResults.AddRange(rootObjects);
        }

        void SearchObjects(string text)
        {
            if (string.IsNullOrEmpty(text)) { RefreshScene(); return; }
            searchResults.Clear();
            hierarchyExpanded.Clear();
            GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
            foreach (var obj in allObjects)
            {
                if (obj != null && !string.IsNullOrEmpty(obj.name) &&
                    obj.name.ToLower().Contains(text.ToLower()) &&
                    !string.IsNullOrEmpty(obj.scene.name))
                {
                    searchResults.Add(obj);
                    Transform t = obj.transform;
                    while (t != null && t.parent != null)
                    {
                        if (!hierarchyExpanded.ContainsKey(t.parent))
                            hierarchyExpanded[t.parent] = true;
                        t = t.parent;
                    }
                }
            }
        }

        // ============================================================
        // 自由视角
        // ============================================================
        void ToggleFreeCamera()
        {
            freeCameraEnabled = !freeCameraEnabled;

            if (freeCameraEnabled)
            {
                mainCamera = Camera.main;
                if (mainCamera != null)
                {
                    originalCameraPos = mainCamera.transform.position;
                    originalCameraRot = mainCamera.transform.rotation;
                    freeCamPosition = originalCameraPos;
                    freeCamRotation = originalCameraRot;
                    Cursor.lockState = CursorLockMode.Locked;
                    Cursor.visible = false;
                    Debug.Log("自由视角已开启 (WASD移动, 鼠标旋转, Esc退出)");
                }
                else
                {
                    freeCameraEnabled = false;
                    Debug.Log("找不到主摄像机");
                }
            }
            else
            {
                if (mainCamera != null)
                {
                    mainCamera.transform.position = originalCameraPos;
                    mainCamera.transform.rotation = originalCameraRot;
                }
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
                Debug.Log("自由视角已关闭");
            }
        }

        void UpdateFreeCamera()
        {
            if (!freeCameraEnabled || mainCamera == null) return;

            float mouseX = Input.GetAxis("Mouse X") * freeCamSensitivity;
            float mouseY = Input.GetAxis("Mouse Y") * freeCamSensitivity;

            freeCamRotation *= Quaternion.Euler(-mouseY, mouseX, 0);
            freeCamRotation = Quaternion.Euler(freeCamRotation.eulerAngles.x, freeCamRotation.eulerAngles.y, 0);

            Vector3 move = Vector3.zero;
            if (Input.GetKey(KeyCode.W)) move += Vector3.forward;
            if (Input.GetKey(KeyCode.S)) move += Vector3.back;
            if (Input.GetKey(KeyCode.A)) move += Vector3.left;
            if (Input.GetKey(KeyCode.D)) move += Vector3.right;
            if (Input.GetKey(KeyCode.Q)) move += Vector3.down;
            if (Input.GetKey(KeyCode.E)) move += Vector3.up;

            float speed = freeCamSpeed;
            if (Input.GetKey(KeyCode.LeftShift)) speed *= 2f;

            move = freeCamRotation * move * speed * Time.deltaTime;
            freeCamPosition += move;

            mainCamera.transform.position = freeCamPosition;
            mainCamera.transform.rotation = freeCamRotation;

            if (Input.GetKeyDown(KeyCode.F)) ToggleFreeCamera();
            if (Input.GetKeyDown(KeyCode.Escape)) ToggleFreeCamera();
        }

        // ============================================================
        // Update
        // ============================================================
        void Update()
        {
            if (consoleVisible || dictVisible || memSearchVisible || objectBrowserVisible || hookUIVisible || methodUIVisible)
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else
            {
                if (!freeCameraEnabled)
                {
                    Cursor.lockState = CursorLockMode.Locked;
                    Cursor.visible = false;
                }
            }

            ObjectLocker.Update();
            UpdateFreeCamera();

            // Ctrl + 左键 选择物体
            if (Input.GetKey(KeyCode.LeftControl) && Input.GetMouseButtonDown(0))
            {
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    ctrlSelectedObject = hit.collider.gameObject;
                    while (ctrlSelectedObject.transform.parent != null)
                        ctrlSelectedObject = ctrlSelectedObject.transform.parent.gameObject;
                    selectedObject = ctrlSelectedObject;
                    AddOutput("Ctrl+左键 已选中: " + selectedObject.name);
                }
            }

            // 鼠标点击选中物体
            if (objectBrowserVisible && Input.GetMouseButtonDown(0))
            {
                Vector2 mousePos = Input.mousePosition;
                mousePos.y = Screen.height - mousePos.y;

                bool clickedOnWindow = browserRect.Contains(mousePos);

                if (!clickedOnWindow && !Input.GetKey(KeyCode.LeftControl))
                {
                    Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    RaycastHit hit;
                    if (Physics.Raycast(ray, out hit))
                    {
                        selectedObject = hit.collider.gameObject;
                        while (selectedObject.transform.parent != null)
                            selectedObject = selectedObject.transform.parent.gameObject;
                        AddOutput("已选中: " + selectedObject.name);
                    }
                }
            }

            // Insert 键
            if (Input.GetKeyDown(KeyCode.Insert))
            {
                consoleVisible = !consoleVisible;
                if (consoleVisible) focusedWindow = "console";
                if (dictVisible) dictVisible = false;
                if (memSearchVisible) memSearchVisible = false;
                if (objectBrowserVisible) objectBrowserVisible = false;
                if (hookUIVisible) hookUIVisible = false;
                if (methodUIVisible) methodUIVisible = false;
            }

            // Home 键 - Hook 管理器
            if (Input.GetKeyDown(KeyCode.Home))
            {
                hookUIVisible = !hookUIVisible;
                if (hookUIVisible) { consoleVisible = true; focusedWindow = "hook"; HookManagerBuiltin.RefreshFilter(); }
                if (methodUIVisible) methodUIVisible = false;
            }
            // End 键 - 方法管理器
            if (Input.GetKeyDown(KeyCode.End))
            {
                methodUIVisible = !methodUIVisible;
                if (methodUIVisible) { consoleVisible = true; focusedWindow = "method"; MethodManagerBuiltin.RefreshFilter(); }
                if (hookUIVisible) hookUIVisible = false;
            }

            // PageUp 打开帮助
            if (Input.GetKeyDown(KeyCode.PageUp))
            {
                HelpSystem.Toggle();
            }

            // ESC 层级关闭
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (freeCameraEnabled) { ToggleFreeCamera(); return; }
                if (hookUIVisible) { hookUIVisible = false; return; }
                if (methodUIVisible) { methodUIVisible = false; return; }
                if (dictVisible) { dictVisible = false; return; }
                if (memSearchVisible) { memSearchVisible = false; return; }
                if (objectBrowserVisible) { objectBrowserVisible = false; return; }
                consoleVisible = false;
            }
        }

        // ============================================================
        // 执行代码（支持 C# 和扩展命令）
        // ============================================================
        void ExecuteCode(string code)
        {
            if (string.IsNullOrEmpty(code) || code.Trim().Length == 0)
            {
                AddOutput("请输入代码");
                return;
            }

            // ===== 扩展命令 (cmd:xxx) =====
            if (code.StartsWith("cmd:"))
            {
                string cmd = code.Substring(4);
                bool handled = ExtensionCommands.Execute(cmd);
                if (handled)
                {
                    AddOutput("扩展命令已执行: " + cmd);
                }
                else
                {
                    AddOutput("未找到扩展命令: " + cmd);
                    AddOutput("可用: hello, ping");
                }
                return;
            }

            // ===== help =====
            if (code.Trim().ToLower() == "help")
            {
                AddOutput("可用命令:");
                AddOutput("  cmd:hello     - 测试扩展命令");
                AddOutput("  cmd:ping      - 测试扩展命令");
                AddOutput("  ext list      - 列出所有扩展");
                AddOutput("  ext reload    - 重新加载扩展");
                AddOutput("  help          - 显示此帮助");
                AddOutput("  clear         - 清屏");
                AddOutput("其他输入将作为 C# 代码执行");
                return;
            }

            // ===== clear =====
            if (code.Trim().ToLower() == "clear")
            {
                outputLogs.Clear();
                currentOutput = "";
                AddOutput("已清屏");
                return;
            }

            // ===== C# 代码 =====
            try
            {
                CompileAndExecute(code);
            }
            catch (Exception ex)
            {
                AddOutput("错误: " + ex.Message);
            }
        }

        // ============================================================
        // 编译执行 C# 代码（使用 Roslyn）
        // ============================================================
        void CompileAndExecute(string code)
        {
            try
            {
                var references = new List<MetadataReference>();

                foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (!assembly.IsDynamic && !string.IsNullOrEmpty(assembly.Location))
                    {
                        try
                        {
                            references.Add(MetadataReference.CreateFromFile(assembly.Location));
                        }
                        catch { }
                    }
                }

                string[] requiredDlls = new string[]
                {
                    "System.dll",
                    "System.Core.dll",
                    "System.Private.CoreLib.dll",
                    "UnityEngine.CoreModule.dll",
                    "UnityEngine.IMGUIModule.dll",
                    "UnityEngine.UI.dll",
                    "UnityEngine.InputLegacyModule.dll",
                    "Assembly-CSharp.dll",
                    "Game.dll",
                    "BepInEx.dll",
                    "0Harmony.dll"
                };

                foreach (var dll in requiredDlls)
                {
                    try
                    {
                        var found = AppDomain.CurrentDomain.GetAssemblies()
                            .FirstOrDefault(a => a.GetName().Name == dll.Replace(".dll", ""));
                        if (found != null && !string.IsNullOrEmpty(found.Location))
                        {
                            references.Add(MetadataReference.CreateFromFile(found.Location));
                        }
                    }
                    catch { }
                }

                var options = new CSharpCompilationOptions(
                    OutputKind.DynamicallyLinkedLibrary,
                    optimizationLevel: OptimizationLevel.Release,
                    allowUnsafe: true
                );

                string fullCode = @"
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Reflection;
using HarmonyLib;

public class ScriptRunner
{
    public static object Run()
    {
        " + code + @"
        return null;
    }
}";

                var syntaxTree = SyntaxFactory.ParseSyntaxTree(fullCode);
                var compilation = CSharpCompilation.Create(
                    "ScriptRunner",
                    new[] { syntaxTree },
                    references,
                    options
                );

                using (var ms = new MemoryStream())
                {
                    var result = compilation.Emit(ms);

                    if (!result.Success)
                    {
                        string errors = "";
                        foreach (var diagnostic in result.Diagnostics)
                        {
                            if (diagnostic.Severity == DiagnosticSeverity.Error)
                            {
                                errors += diagnostic.ToString() + "\n";
                            }
                        }
                        AddOutput("编译错误:\n" + errors);
                        return;
                    }

                    ms.Seek(0, SeekOrigin.Begin);
                    var assembly = Assembly.Load(ms.ToArray());
                    var type = assembly.GetType("ScriptRunner");
                    if (type != null)
                    {
                        var method = type.GetMethod("Run");
                        if (method != null)
                        {
                            object resultObj = method.Invoke(null, null);
                            if (resultObj != null)
                                AddOutput("" + resultObj.ToString());
                            else
                                AddOutput("执行成功");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AddOutput("编译异常: " + ex.Message);
                if (ex.InnerException != null)
                    AddOutput("内部异常: " + ex.InnerException.Message);
            }
        }

        // ============================================================
        // 添加输出
        // ============================================================
        public static void AddOutput(string msg)
        {
            outputLogs.Add("[" + DateTime.Now.ToString("HH:mm:ss") + "] " + msg);
            if (outputLogs.Count > 100)
                outputLogs.RemoveAt(0);
            currentOutput = string.Join("\n", outputLogs.ToArray());
        }
        // ============================================================
        // OnGUI - 所有窗口
        // ============================================================
        void OnGUI()
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.N)
            {
                consoleRect = new Rect(50, 50, 600, 500);
                dictRect = new Rect(100, 100, 700, 500);
                memRect = new Rect(100, 100, 800, 650);
                browserRect = new Rect(0, 0, Screen.width, Screen.height);

                LogicUI.ResetPosition();
                LogicUI_V2.ResetPosition();
                GameAssetBrowser.ResetPosition();
                TeleportUI.ResetPosition();
                BoneVisualizer.ResetPosition();
                BonePoseEditor.ResetPosition();

                Debug.Log("[SuperConsole] 所有窗口已重置位置");
            }

            if (!consoleVisible) return;

            // ===== 鼠标点击时：设置当前活动窗口 + 聚焦到正确的输入框 =====
            if (Event.current.type == EventType.MouseDown)
            {
                Vector2 mousePos = Event.current.mousePosition;

                if (HelpSystem.IsVisible() && new Rect(100, 100, 800, 650).Contains(mousePos))
                {
                    focusedWindow = "help";
                    GUI.FocusWindow(12355);
                }
                else if (LogicUI.IsVisible() && LogicUI.GetWindowRect().Contains(mousePos))
                {
                    focusedWindow = "logic";
                    GUI.FocusWindow(12352);
                    GUI.FocusControl("logicName");
                }
                else if (LogicEditorWindow.IsVisible() && LogicEditorWindow.GetWindowRect().Contains(mousePos))
                {
                    focusedWindow = "logic_editor";
                    GUI.FocusWindow(12363);
                    GUI.FocusControl("logicEditorName");
                }
                else if (LogicExtractorUI.IsVisible() && LogicExtractorUI.GetWindowRect().Contains(mousePos))
                {
                    focusedWindow = "extractor";
                    GUI.FocusWindow(12365);
                }
                else if (GameAssetBrowser.IsVisible() && GameAssetBrowser.GetWindowRect().Contains(mousePos))
                {
                    focusedWindow = "asset";
                    GUI.FocusWindow(12353);
                    GUI.FocusControl("assetSearch");
                }
                else if (LogicUI_V2.IsVisible() && LogicUI_V2.GetWindowRect().Contains(mousePos))
                {
                    focusedWindow = "logic_v2";
                    GUI.FocusWindow(12360);
                    GUI.FocusControl("v2_name");
                }
                else if (hookUIVisible)
                {
                    focusedWindow = "hook";
                    GUI.FocusWindow(12349);
                }
                else if (methodUIVisible)
                {
                    focusedWindow = "method";
                    GUI.FocusWindow(12350);
                }
                else if (objectBrowserVisible && browserRect.Contains(mousePos))
                {
                    focusedWindow = "browser";
                    GUI.FocusWindow(12348);
                    GUI.FocusControl("objSearch");
                }
                else if (memSearchVisible && memRect.Contains(mousePos))
                {
                    focusedWindow = "mem";
                    GUI.FocusWindow(12347);
                    GUI.FocusControl("memSearchInput");
                }
                else if (dictVisible && dictRect.Contains(mousePos))
                {
                    focusedWindow = "dict";
                    GUI.FocusWindow(12346);
                    GUI.FocusControl("dictSearch");
                }
                else if (consoleRect.Contains(mousePos))
                {
                    focusedWindow = "console";
                    GUI.FocusWindow(12345);
                    GUI.FocusControl("inputField");
                }
            }

            // ===== 绘制主控制台 =====
            consoleRect = GUI.Window(12345, consoleRect, ConsoleWindow, "超级控制台 [Insert切换 | Esc关闭]");
            HandleResize(ref consoleRect, ref isResizingConsole, ref resizeStartMouse, ref resizeStartSize);

            // ===== 绘制字典 =====
            if (dictVisible)
            {
                dictRect = GUI.Window(12346, dictRect, DictionaryWindow, "C# 命令字典 [Esc关闭]");
                HandleResize(ref dictRect, ref isResizingDict, ref resizeStartMouse, ref resizeStartSize);
            }

            // ===== 绘制内存搜索 =====
            if (memSearchVisible)
            {
                memRect = GUI.Window(12347, memRect, MemorySearchWindow, "内存搜索 [Esc关闭]");
                HandleResize(ref memRect, ref isResizingMem, ref resizeStartMouse, ref resizeStartSize);
            }

            // ===== 绘制对象浏览器 =====
            if (objectBrowserVisible)
            {
                browserRect = GUI.Window(12348, browserRect, BrowserWindow, "对象浏览器 [Esc关闭 | N重置]");
                HandleResize(ref browserRect, ref isResizingBrowser, ref resizeStartMouse, ref resizeStartSize);

                // ✅ 绘制自动补全下拉列表
                DrawAutoCompleteWindow();
            }

            // ===== 绘制 Hook 管理器 =====
            if (hookUIVisible)
            {
                HookManagerBuiltin.Draw();
            }

            // ===== 绘制方法管理器 =====
            if (methodUIVisible)
            {
                MethodManagerBuiltin.Draw();
            }

            // ===== 绘制其他窗口 =====
            LogicUI.Draw();
            LogicUI_V2.Draw();
            GameAssetBrowser.Draw();
            HelpSystem.Draw();
            TeleportUI.Draw();
            BonePoseEditor.Draw();
            LogicPreview3D.Draw();
            LogicEditorWindow.Draw();
            LogicResourceBrowser.Draw();
            LogicExtractorUI.Draw();
        }

        private void HandleResize(ref Rect windowRect, ref bool isResizing, ref Vector2 resizeStartMouse, ref Vector2 resizeStartSize)
        {
            Rect resizeRect = new Rect(windowRect.width - 16, windowRect.height - 16, 16, 16);
            GUI.Box(resizeRect, "▽", GUIStyle.none);

            if (Event.current.type == EventType.MouseDown && resizeRect.Contains(Event.current.mousePosition))
            {
                isResizing = true;
                resizeStartMouse = Event.current.mousePosition;
                resizeStartSize = new Vector2(windowRect.width, windowRect.height);
                Event.current.Use();
            }

            if (isResizing && Event.current.type == EventType.MouseDrag)
            {
                Vector2 delta = Event.current.mousePosition - resizeStartMouse;
                windowRect.width = Mathf.Max(300, resizeStartSize.x + delta.x);
                windowRect.height = Mathf.Max(200, resizeStartSize.y + delta.y);
                Event.current.Use();
            }

            if (isResizing && Event.current.type == EventType.MouseUp)
            {
                isResizing = false;
                Event.current.Use();
            }
        }

        // ============================================================
        // 控制台窗口
        // ============================================================
        void ConsoleWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown &&
                Event.current.keyCode == KeyCode.Return &&
                GUI.GetNameOfFocusedControl() == "inputField")
            {
                if (!string.IsNullOrEmpty(inputText))
                {
                    ExecuteCode(inputText);
                    inputText = "";
                }
                Event.current.Use();
            }

            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                consoleVisible = false;
                return;
            }

            GUIStyle outputStyle = new GUIStyle(GUI.skin.textArea);
            outputStyle.fontSize = 14;
            outputStyle.richText = true;
            outputStyle.wordWrap = true;

            GUILayout.BeginVertical();

            scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Height(250));
            GUILayout.TextArea(currentOutput, outputStyle, GUILayout.ExpandHeight(true));
            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label(">", GUILayout.Width(20));
            GUI.SetNextControlName("inputField");
            inputText = GUILayout.TextField(inputText, GUILayout.ExpandWidth(true));
            GUILayout.Label("(回车执行)", GUILayout.Width(100));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("焦点: " + focusedWindow, GUILayout.Width(100));
            GUILayout.Label("自由视角: " + (freeCameraEnabled ? "开启" : "关闭"), GUILayout.Width(130));
            if (GUILayout.Button(freeCameraEnabled ? "关闭自由视角" : "开启自由视角", GUILayout.Width(130)))
            {
                ToggleFreeCamera();
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // 第一排按钮
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("字典"))
            {
                dictVisible = !dictVisible;
                if (dictVisible) focusedWindow = "dict";
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            if (GUILayout.Button("内存搜索"))
            {
                memSearchVisible = !memSearchVisible;
                if (memSearchVisible) focusedWindow = "mem";
                dictVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            if (GUILayout.Button("对象浏览器"))
            {
                objectBrowserVisible = !objectBrowserVisible;
                if (objectBrowserVisible) { focusedWindow = "browser"; RefreshScene(); }
                dictVisible = false;
                memSearchVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            if (GUILayout.Button("Hook"))
            {
                hookUIVisible = !hookUIVisible;
                if (hookUIVisible) { focusedWindow = "hook"; HookManagerBuiltin.RefreshFilter(); }
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                methodUIVisible = false;
            }
            if (GUILayout.Button("方法"))
            {
                methodUIVisible = !methodUIVisible;
                if (methodUIVisible) { focusedWindow = "method"; MethodManagerBuiltin.RefreshFilter(); }
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
            }
            if (GUILayout.Button("逻辑体"))
            {
                LogicUI_V2.Toggle();
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            if (GUILayout.Button("资源提取"))
            {
                GameAssetBrowser.Toggle();
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            GUILayout.EndHorizontal();

            // 第二排按钮
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("启动锁定"))
            {
                ObjectLocker.StartLocker();
                AddOutput("锁定系统已启动");
            }
            if (GUILayout.Button("解锁所有"))
            {
                ObjectLocker.UnlockAll();
                AddOutput("已解锁所有");
            }
            if (GUILayout.Button("锁定选中"))
            {
                if (selectedObject == null)
                    AddOutput("请先在对象浏览器中选中一个对象");
                else
                {
                    ObjectLocker.LockSelectedAll(selectedObject);
                    AddOutput("已锁定: " + selectedObject.name);
                }
            }
            if (GUILayout.Button("解锁选中"))
            {
                if (selectedObject == null)
                    AddOutput("请先选中一个对象");
                else
                {
                    ObjectLocker.UnlockObject(selectedObject);
                    AddOutput("已解锁: " + selectedObject.name);
                }
            }
            if (GUILayout.Button("复制对象"))
            {
                if (selectedObject == null)
                    AddOutput("请先选中一个对象");
                else
                {
                    ObjectEditor.Duplicate(selectedObject);
                    AddOutput("已复制: " + selectedObject.name);
                }
            }
            if (GUILayout.Button("删除对象"))
            {
                if (selectedObject == null)
                    AddOutput("请先选中一个对象");
                else
                {
                    string name = selectedObject.name;
                    ObjectEditor.Delete(selectedObject);
                    selectedObject = null;
                    AddOutput("已删除: " + name);
                }
            }
            GUILayout.EndHorizontal();

            // 第三排按钮
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("nofall"))
                inputText = "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<RagdollController>().enabled = false;";
            if (GUILayout.Button("加速"))
                inputText = "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<PlayerCharacterMovement>().speedMultiplier = 999f;";
            if (GUILayout.Button("无敌"))
                inputText = "GameObject.Find(\"PlayerCharacter(Clone)\").GetComponent<PlayerCharacter>().health = 99999;";

            if (GUILayout.Button("传送玩家到选中"))
            {
                if (selectedObject == null)
                {
                    AddOutput("请先在对象浏览器中选中一个目标对象");
                }
                else
                {
                    GameObject player = GameObject.Find("PlayerCharacter(Clone)");
                    if (player == null)
                        player = GameObject.FindGameObjectWithTag("Player");
                    if (player == null)
                        player = GameObject.Find("Player");

                    if (player != null)
                    {
                        player.transform.position = selectedObject.transform.position;
                        AddOutput("已传送玩家到 " + selectedObject.name + " 的位置 (" + selectedObject.transform.position + ")");
                    }
                    else
                    {
                        AddOutput("找不到玩家对象，请确认玩家名称是 'PlayerCharacter(Clone)' 或 'Player'");
                    }
                }
            }

            // ✅ 新增：切断链接按钮
            if (GUILayout.Button("切断链接"))
            {
                if (selectedObject == null)
                    AddOutput("请先选中一个对象");
                else
                    DetachObject(selectedObject);
            }

            if (GUILayout.Button("清屏"))
            {
                outputLogs.Clear();
                currentOutput = "";
            }
            if (GUILayout.Button("帮助"))
                AddOutput("命令模板 | 内存搜索 | 对象浏览器 | Hook | 方法 | 锁定系统 | Ctrl+左键选物体 | F自由视角");
            GUILayout.EndHorizontal();

            // 第四排按钮
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("📂 资源浏览器"))
            {
                LogicResourceBrowser.Toggle();
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("📝 逻辑编辑器"))
            {
                LogicUI.Toggle();
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            if (GUILayout.Button("📦 逻辑体编辑器"))
            {
                LogicEditorWindow.Toggle();
                dictVisible = false;
                memSearchVisible = false;
                objectBrowserVisible = false;
                hookUIVisible = false;
                methodUIVisible = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            Rect dragRect = new Rect(0, 0, consoleRect.width, 20);
            GUI.DragWindow(dragRect);
        }

        // ============================================================
        // 字典窗口
        // ============================================================
        void DictionaryWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                dictVisible = false;
                return;
            }

            float minW = 400, minH = 300;
            float maxW = Screen.width, maxH = Screen.height;

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(60));
            GUI.SetNextControlName("dictSearch");
            string newSearch = GUILayout.TextField(searchText, GUILayout.ExpandWidth(true));
            if (newSearch != searchText) searchText = newSearch;
            if (GUILayout.Button("清空", GUILayout.Width(50))) searchText = "";
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            dictScroll = GUILayout.BeginScrollView(dictScroll, GUILayout.ExpandHeight(true));

            foreach (var template in templates)
            {
                if (!string.IsNullOrEmpty(searchText))
                {
                    if (!template.name.ToLower().Contains(searchText.ToLower()) &&
                        !template.code.ToLower().Contains(searchText.ToLower()) &&
                        !template.desc.ToLower().Contains(searchText.ToLower()))
                        continue;
                }

                GUILayout.BeginVertical("box");

                GUILayout.BeginHorizontal();
                GUILayout.Label(template.name, GUILayout.Width(150));
                GUILayout.Label(template.desc, GUILayout.ExpandWidth(true));
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                GUIStyle codeStyle = new GUIStyle(GUI.skin.textField);
                codeStyle.fontSize = 12;
                codeStyle.normal.textColor = Color.green;
                codeStyle.wordWrap = true;

                GUILayout.TextArea(template.code, codeStyle, GUILayout.ExpandWidth(true));

                if (GUILayout.Button("填入", GUILayout.Width(60)))
                {
                    inputText = template.code;
                    focusedWindow = "console";
                    AddOutput("已填入输入框");
                }
                if (GUILayout.Button("执行", GUILayout.Width(60)))
                {
                    inputText = template.code;
                    dictVisible = false;
                    focusedWindow = "console";
                    ExecuteCode(inputText);
                    inputText = "";
                }
                GUILayout.EndHorizontal();
                GUILayout.EndVertical();
                GUILayout.Space(5);
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("共 " + templates.Count + " 条命令", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("关闭", GUILayout.Width(80))) dictVisible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            Rect dragRect = new Rect(0, 0, dictRect.width - 20, 20);
            GUI.DragWindow(dragRect);
            Rect resizeRect = new Rect(dictRect.width - 16, dictRect.height - 16, 16, 16);
            GUI.Box(resizeRect, "▽", GUIStyle.none);
            GUI.DragWindow(resizeRect);
            dictRect.width = Mathf.Clamp(dictRect.width, minW, maxW);
            dictRect.height = Mathf.Clamp(dictRect.height, minH, maxH);
        }

        // ============================================================
        // 内存搜索窗口
        // ============================================================
        void MemorySearchWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                memSearchVisible = false;
                return;
            }

            float minW = 550, minH = 450;
            float maxW = Screen.width, maxH = Screen.height;

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("状态: " + memStatus, GUILayout.ExpandWidth(true));
            GUILayout.Label("结果: " + memResults.Count, GUILayout.Width(80));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("模式:", GUILayout.Width(40));
            string[] modes = { "精确", "大于", "小于", "大于等于", "小于等于", "范围", "变化", "不变", "增加", "减少", "模糊" };
            int modeIdx = Array.IndexOf(modes, memSearchMode);
            if (modeIdx < 0) modeIdx = 0;
            int newModeIdx = GUILayout.SelectionGrid(modeIdx, modes, 6, GUILayout.ExpandWidth(true));
            if (newModeIdx != modeIdx) { memSearchMode = modes[newModeIdx]; }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("类型:", GUILayout.Width(40));
            string[] types = { "自动", "float", "int", "double", "long", "short", "byte", "bool", "string" };
            int typeIdx = Array.IndexOf(types, memValueType);
            if (typeIdx < 0) typeIdx = 0;
            int newTypeIdx = GUILayout.SelectionGrid(typeIdx, types, 9, GUILayout.ExpandWidth(true));
            if (newTypeIdx != typeIdx) { memValueType = types[newTypeIdx]; }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            bool needValue = memSearchMode != "变化" && memSearchMode != "不变";
            bool needValue2 = memSearchMode == "范围";

            GUILayout.BeginHorizontal();
            GUILayout.Label("值1:", GUILayout.Width(50));
            if (needValue)
            {
                GUI.SetNextControlName("memSearchInput");
                memSearchInput = GUILayout.TextField(memSearchInput, GUILayout.Width(150));
            }
            else
                GUILayout.Label("(不需要)", GUILayout.Width(150));

            if (needValue2)
            {
                GUILayout.Label("值2:", GUILayout.Width(50));
                GUI.SetNextControlName("memSearchValue2");
                memSearchValue2 = GUILayout.TextField(memSearchValue2, GUILayout.Width(150));
            }
            else
            {
                GUILayout.Label("", GUILayout.Width(200));
            }

            if (GUILayout.Button("搜索", GUILayout.Width(70))) DoMemorySearch();
            if (GUILayout.Button("过滤", GUILayout.Width(70))) DoMemoryFilter();
            if (GUILayout.Button("清空", GUILayout.Width(60)))
            {
                memResults.Clear();
                memPreviousResults.Clear();
                memHasResults = false;
                memStatus = "已清空";
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            bool newAllFields = GUILayout.Toggle(memSearchAllFields, "搜索所有字段", GUILayout.Width(100));
            if (newAllFields != memSearchAllFields) memSearchAllFields = newAllFields;

            bool newIncludePrivate = GUILayout.Toggle(memIncludePrivate, "包含私有", GUILayout.Width(100));
            if (newIncludePrivate != memIncludePrivate) memIncludePrivate = newIncludePrivate;

            bool newSearchProps = GUILayout.Toggle(memSearchProperties, "搜索属性", GUILayout.Width(100));
            if (newSearchProps != memSearchProperties) memSearchProperties = newSearchProps;

            GUILayout.Label("类型过滤:", GUILayout.Width(60));
            GUI.SetNextControlName("memTypeFilter");
            memTypeFilter = GUILayout.TextField(memTypeFilter, GUILayout.Width(100));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("结果 (" + memResults.Count + ")", GUILayout.ExpandWidth(true));
            GUILayout.Label("索引", GUILayout.Width(35));
            GUILayout.Label("值", GUILayout.Width(80));
            GUILayout.Label("类型", GUILayout.Width(60));
            GUILayout.Label("对象/字段", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            memScroll = GUILayout.BeginScrollView(memScroll, GUILayout.Height(250));

            if (memResults.Count == 0)
            {
                GUILayout.Label("暂无结果，请执行搜索");
            }
            else
            {
                int displayCount = Math.Min(memResults.Count, 200);
                for (int i = 0; i < displayCount; i++)
                {
                    var r = memResults[i];
                    GUILayout.BeginHorizontal();

                    if (GUILayout.Button("选择", GUILayout.Width(40)))
                    {
                        memSelectedIndex = i;
                        memModifyInput = MemorySearcher.GetValueString(r.value);
                        memStatus = "已选择 #" + i + " (当前值: " + MemorySearcher.GetValueString(r.value) + ")";
                    }

                    GUILayout.Label(i.ToString(), GUILayout.Width(30));
                    GUILayout.Label(MemorySearcher.GetValueString(r.value), GUILayout.Width(80));
                    GUILayout.Label(r.valueType ?? "?", GUILayout.Width(55));
                    GUILayout.Label(r.objectName, GUILayout.ExpandWidth(true));

                    GUILayout.EndHorizontal();
                }

                if (memResults.Count > 200)
                {
                    GUILayout.Label("... 还有 " + (memResults.Count - 200) + " 个结果未显示");
                }
            }
            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("修改为:", GUILayout.Width(60));
            GUI.SetNextControlName("memModifyInput");
            memModifyInput = GUILayout.TextField(memModifyInput, GUILayout.Width(150));
            if (GUILayout.Button("修改选中", GUILayout.Width(100))) DoModifySelectedEx();
            if (GUILayout.Button("修改所有", GUILayout.Width(80))) DoModifyAllEx();
            if (GUILayout.Button("锁定选中", GUILayout.Width(100))) DoLockSelected();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("提示: 变化/不变/增加/减少 不需要输入值，基于上次搜索结果过滤", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            Rect dragRect = new Rect(0, 0, memRect.width - 20, 20);
            GUI.DragWindow(dragRect);
            Rect resizeRect = new Rect(memRect.width - 16, memRect.height - 16, 16, 16);
            GUI.Box(resizeRect, "▽", GUIStyle.none);
            GUI.DragWindow(resizeRect);
            memRect.width = Mathf.Clamp(memRect.width, minW, maxW);
            memRect.height = Mathf.Clamp(memRect.height, minH, maxH);
        }

        // ============================================================
        // 内存搜索方法
        // ============================================================
        void DoMemorySearch()
        {
            bool needValue = memSearchMode != "变化" && memSearchMode != "不变";
            if (needValue && string.IsNullOrEmpty(memSearchInput))
            {
                memStatus = "请输入搜索值";
                return;
            }

            object searchValue = null;
            Type targetType = null;

            if (needValue)
            {
                searchValue = ParseValue(memSearchInput, memValueType, out targetType);
                if (searchValue == null && memSearchMode != "模糊")
                {
                    memStatus = "无效的搜索值: " + memSearchInput;
                    return;
                }
            }

            if (memSearchMode == "范围")
            {
                if (string.IsNullOrEmpty(memSearchValue2))
                {
                    memStatus = "请输入第二个值";
                    return;
                }
                object val2 = ParseValue(memSearchValue2, memValueType, out _);
                if (val2 == null)
                {
                    memStatus = "无效的第二个值";
                    return;
                }
            }

            memStatus = "正在搜索...";
            memResults.Clear();
            memPreviousResults.Clear();

            try
            {
                GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
                int found = 0;
                int totalChecked = 0;

                foreach (var obj in allObjects)
                {
                    if (obj == null) continue;
                    if (string.IsNullOrEmpty(obj.scene.name)) continue;

                    if (!string.IsNullOrEmpty(memTypeFilter))
                    {
                        if (!obj.name.ToLower().Contains(memTypeFilter.ToLower()))
                            continue;
                    }

                    Component[] components = obj.GetComponents<Component>();
                    foreach (var comp in components)
                    {
                        if (comp == null) continue;

                        BindingFlags flags = BindingFlags.Public | BindingFlags.Instance;
                        if (memIncludePrivate) flags |= BindingFlags.NonPublic;

                        if (memSearchAllFields)
                        {
                            FieldInfo[] fields = comp.GetType().GetFields(flags);
                            foreach (var field in fields)
                            {
                                if (field.Name.StartsWith("m_") || field.Name.StartsWith("<")) continue;
                                totalChecked++;
                                if (CheckField(comp, field, searchValue, targetType, ref found))
                                {
                                    if (found >= 999999999) break;
                                }
                            }
                        }

                        if (memSearchProperties)
                        {
                            PropertyInfo[] props = comp.GetType().GetProperties(flags);
                            foreach (var prop in props)
                            {
                                if (prop.Name.StartsWith("m_") || prop.Name.StartsWith("<")) continue;
                                if (!prop.CanRead) continue;
                                totalChecked++;
                                if (CheckProperty(comp, prop, searchValue, targetType, ref found))
                                {
                                    if (found >= 999999999) break;
                                }
                            }
                        }

                        if (found >= 999999999) break;
                    }
                    if (found >= 999999999) break;
                }

                memPreviousResults = new List<MemoryResult>(memResults);
                memHasResults = true;

                string resultMsg = "搜索完成！检查了 " + totalChecked + " 个字段，找到 " + memResults.Count + " 个结果";
                memStatus = resultMsg;
            }
            catch (Exception ex)
            {
                memStatus = "搜索出错: " + ex.Message;
            }
        }

        bool CheckField(Component comp, FieldInfo field, object searchValue, Type targetType, ref int found)
        {
            try
            {
                object value = field.GetValue(comp);
                if (value == null) return false;

                if (targetType != null && !targetType.IsAssignableFrom(value.GetType()))
                {
                    if (memValueType != "自动")
                    {
                        try
                        {
                            value = Convert.ChangeType(value, targetType);
                        }
                        catch { return false; }
                    }
                }

                bool match = IsValueMatch(value, searchValue);
                if (!match) return false;

                memResults.Add(new MemoryResult
                {
                    gameObject = comp.gameObject,
                    component = comp,
                    fieldInfo = field,
                    value = value,
                    valueType = value.GetType().Name,
                    objectName = comp.gameObject.name + "." + comp.GetType().Name + "." + field.Name,
                    memberName = field.Name,
                    isField = true
                });
                found++;
                return true;
            }
            catch { return false; }
        }

        bool CheckProperty(Component comp, PropertyInfo prop, object searchValue, Type targetType, ref int found)
        {
            try
            {
                object value = prop.GetValue(comp, null);
                if (value == null) return false;

                if (targetType != null && !targetType.IsAssignableFrom(value.GetType()))
                {
                    if (memValueType != "自动")
                    {
                        try
                        {
                            value = Convert.ChangeType(value, targetType);
                        }
                        catch { return false; }
                    }
                }

                bool match = IsValueMatch(value, searchValue);
                if (!match) return false;

                memResults.Add(new MemoryResult
                {
                    gameObject = comp.gameObject,
                    component = comp,
                    propertyInfo = prop,
                    value = value,
                    valueType = value.GetType().Name,
                    objectName = comp.gameObject.name + "." + comp.GetType().Name + "." + prop.Name,
                    memberName = prop.Name,
                    isField = false
                });
                found++;
                return true;
            }
            catch { return false; }
        }

        bool IsValueMatch(object currentValue, object searchValue)
        {
            if (currentValue == null) return false;
            if (searchValue == null) return memSearchMode == "变化" || memSearchMode == "不变";

            Type type = currentValue.GetType();

            if (MemorySearcher.IsNumericType(type))
            {
                double current = MemorySearcher.GetNumericValue(currentValue);
                double search = MemorySearcher.GetNumericValue(searchValue);

                switch (memSearchMode)
                {
                    case "精确": return Math.Abs(current - search) < 0.00001;
                    case "大于": return current > search;
                    case "小于": return current < search;
                    case "大于等于": return current >= search;
                    case "小于等于": return current <= search;
                    case "范围":
                        double search2 = 0;
                        if (!string.IsNullOrEmpty(memSearchValue2))
                        {
                            object val2 = ParseValue(memSearchValue2, memValueType, out _);
                            if (val2 != null) search2 = MemorySearcher.GetNumericValue(val2);
                        }
                        double min = Math.Min(search, search2);
                        double max = Math.Max(search, search2);
                        return current >= min && current <= max;
                    case "模糊":
                        double tolerance = Math.Abs(search) * 0.1 + 0.00001;
                        return Math.Abs(current - search) < tolerance;
                    default: return false;
                }
            }

            if (type == typeof(bool))
            {
                bool current = (bool)currentValue;
                if (searchValue is bool searchBool)
                {
                    return current == searchBool;
                }
                if (searchValue is string searchStr)
                {
                    if (searchStr.ToLower() == "true") return current == true;
                    if (searchStr.ToLower() == "false") return current == false;
                }
                return false;
            }

            if (type == typeof(string))
            {
                string current = (string)currentValue;
                string search = searchValue?.ToString() ?? "";

                switch (memSearchMode)
                {
                    case "精确": return current == search;
                    case "模糊": return current.ToLower().Contains(search.ToLower());
                    default: return false;
                }
            }

            if (type == typeof(Vector2))
            {
                Vector2 current = (Vector2)currentValue;
                if (searchValue is Vector2 searchV2) return current == searchV2;
                if (searchValue is string str)
                {
                    try
                    {
                        string[] parts = str.Replace("(", "").Replace(")", "").Split(',');
                        if (parts.Length == 2)
                        {
                            float x = float.Parse(parts[0]);
                            float y = float.Parse(parts[1]);
                            return current == new Vector2(x, y);
                        }
                    }
                    catch { }
                }
                return false;
            }

            if (type == typeof(Vector3))
            {
                Vector3 current = (Vector3)currentValue;
                if (searchValue is Vector3 searchV3) return current == searchV3;
                if (searchValue is string str)
                {
                    try
                    {
                        string[] parts = str.Replace("(", "").Replace(")", "").Split(',');
                        if (parts.Length == 3)
                        {
                            float x = float.Parse(parts[0]);
                            float y = float.Parse(parts[1]);
                            float z = float.Parse(parts[2]);
                            return current == new Vector3(x, y, z);
                        }
                    }
                    catch { }
                }
                return false;
            }

            return currentValue.Equals(searchValue);
        }

        object ParseValue(string input, string typeHint, out Type targetType)
        {
            targetType = null;

            if (string.IsNullOrEmpty(input)) return null;

            if (typeHint == "自动" || typeHint == "float")
            {
                if (float.TryParse(input, out float f)) { targetType = typeof(float); return f; }
            }
            if (typeHint == "自动" || typeHint == "int")
            {
                if (int.TryParse(input, out int i)) { targetType = typeof(int); return i; }
            }
            if (typeHint == "自动" || typeHint == "double")
            {
                if (double.TryParse(input, out double d)) { targetType = typeof(double); return d; }
            }
            if (typeHint == "自动" || typeHint == "long")
            {
                if (long.TryParse(input, out long l)) { targetType = typeof(long); return l; }
            }
            if (typeHint == "自动" || typeHint == "short")
            {
                if (short.TryParse(input, out short s)) { targetType = typeof(short); return s; }
            }
            if (typeHint == "自动" || typeHint == "byte")
            {
                if (byte.TryParse(input, out byte b)) { targetType = typeof(byte); return b; }
            }
            if (typeHint == "bool")
            {
                if (bool.TryParse(input, out bool bl)) { targetType = typeof(bool); return bl; }
            }
            if (typeHint == "string" || typeHint == "自动")
            {
                targetType = typeof(string);
                return input;
            }

            if (typeHint == "自动")
            {
                if (float.TryParse(input, out float f)) { targetType = typeof(float); return f; }
                if (int.TryParse(input, out int i)) { targetType = typeof(int); return i; }
                if (double.TryParse(input, out double d)) { targetType = typeof(double); return d; }
                if (bool.TryParse(input, out bool b)) { targetType = typeof(bool); return b; }
                targetType = typeof(string);
                return input;
            }

            return null;
        }

        void DoMemoryFilter()
        {
            if (!memHasResults || memPreviousResults.Count == 0)
            {
                if (!string.IsNullOrEmpty(memSearchInput))
                {
                    DoMemorySearch();
                    return;
                }
                memStatus = "请先执行搜索";
                return;
            }

            bool needValue = memSearchMode == "精确" || memSearchMode == "大于" || memSearchMode == "小于" ||
                             memSearchMode == "大于等于" || memSearchMode == "小于等于" || memSearchMode == "模糊" || memSearchMode == "范围";

            if (needValue && string.IsNullOrEmpty(memSearchInput))
            {
                memStatus = "请输入搜索值";
                return;
            }

            object searchValue = null;
            if (needValue)
            {
                searchValue = ParseValue(memSearchInput, memValueType, out _);
                if (searchValue == null && memSearchMode != "模糊" && memSearchMode != "范围")
                {
                    memStatus = "无效的搜索值";
                    return;
                }
            }

            memStatus = "正在筛选...";
            List<MemoryResult> newResults = new List<MemoryResult>();

            try
            {
                foreach (var r in memPreviousResults)
                {
                    object currentValue = null;
                    if (r.isField && r.fieldInfo != null)
                    {
                        currentValue = r.fieldInfo.GetValue(r.component);
                    }
                    else if (!r.isField && r.propertyInfo != null)
                    {
                        currentValue = r.propertyInfo.GetValue(r.component, null);
                    }

                    if (currentValue == null) continue;

                    bool match = false;

                    if (memSearchMode == "变化")
                    {
                        match = !ValuesEqual(currentValue, r.value);
                    }
                    else if (memSearchMode == "不变")
                    {
                        match = ValuesEqual(currentValue, r.value);
                    }
                    else if (memSearchMode == "增加")
                    {
                        match = IsValueGreater(currentValue, r.value);
                    }
                    else if (memSearchMode == "减少")
                    {
                        match = IsValueLess(currentValue, r.value);
                    }
                    else
                    {
                        match = IsValueMatch(currentValue, searchValue);
                    }

                    if (match)
                    {
                        r.value = currentValue;
                        newResults.Add(r);
                    }
                }

                memResults = newResults;
                memPreviousResults = new List<MemoryResult>(memResults);
                memStatus = "筛选完成，剩余 " + memResults.Count + " 个结果";
            }
            catch (Exception ex)
            {
                memStatus = "筛选出错: " + ex.Message;
            }
        }

        bool ValuesEqual(object a, object b)
        {
            if (a == null && b == null) return true;
            if (a == null || b == null) return false;

            Type ta = a.GetType();
            Type tb = b.GetType();

            if (MemorySearcher.IsNumericType(ta) && MemorySearcher.IsNumericType(tb))
            {
                return Math.Abs(MemorySearcher.GetNumericValue(a) - MemorySearcher.GetNumericValue(b)) < 0.00001;
            }

            return a.Equals(b);
        }

        bool IsValueGreater(object a, object b)
        {
            if (a == null || b == null) return false;
            if (MemorySearcher.IsNumericType(a.GetType()) && MemorySearcher.IsNumericType(b.GetType()))
            {
                return MemorySearcher.GetNumericValue(a) > MemorySearcher.GetNumericValue(b) + 0.00001;
            }
            return false;
        }

        bool IsValueLess(object a, object b)
        {
            if (a == null || b == null) return false;
            if (MemorySearcher.IsNumericType(a.GetType()) && MemorySearcher.IsNumericType(b.GetType()))
            {
                return MemorySearcher.GetNumericValue(a) < MemorySearcher.GetNumericValue(b) - 0.00001;
            }
            return false;
        }

        void DoModifySelectedEx()
        {
            if (memSelectedIndex < 0 || memSelectedIndex >= memResults.Count)
            {
                memStatus = "请先选择一个结果";
                return;
            }
            if (string.IsNullOrEmpty(memModifyInput))
            {
                memStatus = "请输入要修改的值";
                return;
            }

            try
            {
                var r = memResults[memSelectedIndex];
                object newValue = ParseValue(memModifyInput, "自动", out Type targetType);

                if (newValue == null)
                {
                    memStatus = "无效的值: " + memModifyInput;
                    return;
                }

                if (r.value != null && targetType == null)
                {
                    targetType = r.value.GetType();
                }

                if (targetType != null && newValue.GetType() != targetType)
                {
                    try
                    {
                        newValue = Convert.ChangeType(newValue, targetType);
                    }
                    catch
                    {
                        memStatus = "类型转换失败";
                        return;
                    }
                }

                if (r.isField && r.fieldInfo != null)
                {
                    r.fieldInfo.SetValue(r.component, newValue);
                }
                else if (!r.isField && r.propertyInfo != null)
                {
                    r.propertyInfo.SetValue(r.component, newValue, null);
                }
                else
                {
                    memStatus = "无法修改";
                    return;
                }

                r.value = newValue;
                memStatus = "已修改 #" + memSelectedIndex + " 为 " + MemorySearcher.GetValueString(newValue);
            }
            catch (Exception ex)
            {
                memStatus = "修改失败: " + ex.Message;
            }
        }

        void DoModifyAllEx()
        {
            if (memResults.Count == 0)
            {
                memStatus = "没有结果可修改";
                return;
            }
            if (string.IsNullOrEmpty(memModifyInput))
            {
                memStatus = "请输入要修改的值";
                return;
            }

            try
            {
                object newValue = ParseValue(memModifyInput, "自动", out Type targetType);
                if (newValue == null)
                {
                    memStatus = "无效的值: " + memModifyInput;
                    return;
                }

                int count = 0;
                foreach (var r in memResults)
                {
                    try
                    {
                        Type valType = r.value?.GetType() ?? targetType;
                        object converted = newValue;
                        if (valType != null && converted.GetType() != valType)
                        {
                            try { converted = Convert.ChangeType(converted, valType); } catch { continue; }
                        }

                        if (r.isField && r.fieldInfo != null)
                        {
                            r.fieldInfo.SetValue(r.component, converted);
                        }
                        else if (!r.isField && r.propertyInfo != null)
                        {
                            r.propertyInfo.SetValue(r.component, converted, null);
                        }
                        else
                        {
                            continue;
                        }

                        r.value = converted;
                        count++;
                    }
                    catch { }
                }

                memStatus = "已修改 " + count + " 个结果";
            }
            catch (Exception ex)
            {
                memStatus = "批量修改失败: " + ex.Message;
            }
        }

        void DoLockSelected()
        {
            if (memSelectedIndex < 0 || memSelectedIndex >= memResults.Count)
            {
                memStatus = "请先选择一个结果";
                return;
            }

            var r = memResults[memSelectedIndex];
            if (r.gameObject == null)
            {
                memStatus = "无法锁定，对象不存在";
                return;
            }

            ObjectLocker.Lock(
                r.gameObject.name,
                r.component.GetType().Name,
                r.memberName,
                r.value
            );

            memStatus = "已锁定: " + r.objectName + " = " + MemorySearcher.GetValueString(r.value);
        }

        // ============================================================
        // 对象浏览器窗口（带自动补全 + 位置/旋转/缩放编辑）
        // ============================================================
        void BrowserWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                objectBrowserVisible = false;
                return;
            }

            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.N)
            {
                browserRect = new Rect(0, 0, Screen.width, Screen.height);
                return;
            }

            GUILayout.BeginHorizontal();

            // ===== 左侧：对象列表 =====
            GUILayout.BeginVertical(GUILayout.Width(350));
            DrawBrowserLeftPanel();
            GUILayout.EndVertical();

            // ===== 分隔线 =====
            GUILayout.Box("", GUILayout.Width(2), GUILayout.ExpandHeight(true));

            // ===== 右侧：检查器 =====
            GUILayout.BeginVertical(GUILayout.ExpandWidth(true));
            DrawBrowserInspector();
            GUILayout.EndVertical();

            GUILayout.EndHorizontal();

            GUI.DragWindow(new Rect(0, 0, browserRect.width, 20));
        }

        // ============================================================
        // 左侧面板
        // ============================================================
        void DrawBrowserLeftPanel()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(45));
            GUI.SetNextControlName("objSearch");
            string newSearch = GUILayout.TextField(browserSearchText, GUILayout.ExpandWidth(true));
            if (newSearch != browserSearchText) { browserSearchText = newSearch; SearchObjects(browserSearchText); }
            if (GUILayout.Button("搜", GUILayout.Width(30))) SearchObjects(browserSearchText);
            if (GUILayout.Button("刷新", GUILayout.Width(40))) { browserSearchText = ""; RefreshScene(); }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("全部展开", GUILayout.Width(70))) ExpandBrowserAll();
            if (GUILayout.Button("全部折叠", GUILayout.Width(70))) CollapseBrowserAll();
            GUILayout.Label($"共 {searchResults.Count} 个对象", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            browserScroll = GUILayout.BeginScrollView(browserScroll, GUILayout.ExpandHeight(true));

            if (searchResults.Count == 0)
                GUILayout.Label("没有找到对象");
            else
            {
                foreach (var obj in searchResults)
                {
                    if (obj == null) continue;
                    if (obj.transform.parent == null)
                        DrawBrowserHierarchyNode(obj.transform, 0);
                }
            }

            GUILayout.EndScrollView();
        }

        void DrawBrowserHierarchyNode(Transform t, int depth)
        {
            if (t == null) return;

            if (!string.IsNullOrEmpty(browserSearchText))
            {
                if (!t.name.ToLower().Contains(browserSearchText.ToLower()))
                {
                    bool childMatches = false;
                    foreach (Transform child in t.GetComponentsInChildren<Transform>())
                    {
                        if (child != t && child.name.ToLower().Contains(browserSearchText.ToLower()))
                        {
                            childMatches = true;
                            break;
                        }
                    }
                    if (!childMatches) return;
                }
            }

            GameObject obj = t.gameObject;
            string indent = "";
            for (int i = 0; i < depth; i++) indent += "  ";

            GUILayout.BeginHorizontal();

            if (depth > 0)
                GUILayout.Label(indent, GUILayout.Width(depth * 15));

            int childCount = t.childCount;
            if (childCount > 0)
            {
                if (!hierarchyExpanded.ContainsKey(t))
                    hierarchyExpanded[t] = false;
                string icon = hierarchyExpanded[t] ? "▼" : "▶";
                if (GUILayout.Button(icon, GUILayout.Width(20)))
                    hierarchyExpanded[t] = !hierarchyExpanded[t];
            }
            else
            {
                GUILayout.Label("  ", GUILayout.Width(20));
            }

            Color originalColor = GUI.backgroundColor;
            if (obj == selectedObject)
                GUI.backgroundColor = new Color(0.3f, 0.6f, 1f);

            if (GUILayout.Button(obj.name, GUILayout.ExpandWidth(true)))
            {
                selectedObject = obj;
                inspectorScroll = Vector2.zero;
                AddOutput("已选中: " + obj.name);
            }

            GUI.backgroundColor = originalColor;

            bool active = obj.activeSelf;
            bool newActive = GUILayout.Toggle(active, "", GUILayout.Width(20));
            if (newActive != active) obj.SetActive(newActive);

            GUILayout.EndHorizontal();

            if (childCount > 0 && hierarchyExpanded.ContainsKey(t) && hierarchyExpanded[t])
            {
                foreach (Transform child in t)
                    DrawBrowserHierarchyNode(child, depth + 1);
            }
        }

        // ============================================================
        // 右侧检查器（带自动补全 + 位置/旋转/缩放编辑）
        // ============================================================
        void DrawBrowserInspector()
        {
            if (selectedObject == null)
            {
                GUILayout.Label("点击左侧对象查看详细信息");
                GUILayout.Label("或 Ctrl+左键 点击游戏中的物体");
                return;
            }

            // ===== 对象信息 =====
            GUILayout.BeginHorizontal();
            GUILayout.Label(selectedObject.name, GUILayout.ExpandWidth(true));
            GUILayout.Label("ID: " + selectedObject.GetInstanceID(), GUILayout.Width(100));
            if (GUILayout.Button("锁定", GUILayout.Width(50)))
            {
                ObjectLocker.LockSelectedAll(selectedObject);
                AddOutput("已锁定: " + selectedObject.name);
            }
            if (GUILayout.Button("解锁", GUILayout.Width(50)))
            {
                ObjectLocker.UnlockObject(selectedObject);
                AddOutput("已解锁: " + selectedObject.name);
            }
            if (GUILayout.Button("骨骼", GUILayout.Width(50)))
            {
                BoneVisualizer.Toggle(selectedObject);
            }
            if (GUILayout.Button("隐藏骨骼", GUILayout.Width(50)))
            {
                BoneVisualizer.Hide();
            }
            if (GUILayout.Button("碰撞箱", GUILayout.Width(50)))
            {
                if (selectedObject != null)
                    LogicColliderVisualizer.Toggle(selectedObject);
            }
            if (GUILayout.Button("提取", GUILayout.Width(50)))
            {
                if (selectedObject != null)
                    LogicExtractorUI.Toggle(selectedObject);
            }
            // ✅ 新增：切断链接和绑定按钮
            if (GUILayout.Button("切断链接", GUILayout.Width(60)))
            {
                DetachObject(selectedObject);
            }
            if (GUILayout.Button("绑定到选中", GUILayout.Width(70)))
            {
                if (SuperConsole.selectedObject != null && SuperConsole.selectedObject != selectedObject)
                {
                    AttachObject(selectedObject, SuperConsole.selectedObject);
                }
                else
                {
                    AddOutput("❌ 请先在浏览器中选择另一个对象作为父对象");
                }
            }
            if (GUILayout.Button("显示路径", GUILayout.Width(60)))
            {
                string path = GetObjectPath(selectedObject);
                AddOutput($"📂 路径: {path}");
            }
            GUILayout.EndHorizontal();

            // ✅ 位置/旋转/缩放编辑（可输入）
            GUILayout.BeginHorizontal();
            GUILayout.Label("位置:", GUILayout.Width(35));
            string posX = GUILayout.TextField(selectedObject.transform.position.x.ToString("F2"), GUILayout.Width(60));
            string posY = GUILayout.TextField(selectedObject.transform.position.y.ToString("F2"), GUILayout.Width(60));
            string posZ = GUILayout.TextField(selectedObject.transform.position.z.ToString("F2"), GUILayout.Width(60));
            if (GUILayout.Button("应用位置", GUILayout.Width(60)))
            {
                try
                {
                    float x = float.Parse(posX);
                    float y = float.Parse(posY);
                    float z = float.Parse(posZ);
                    selectedObject.transform.position = new Vector3(x, y, z);
                    AddOutput($"✅ 位置已设置为 ({x:F2}, {y:F2}, {z:F2})");
                }
                catch { AddOutput("❌ 位置格式错误"); }
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("旋转:", GUILayout.Width(35));
            string rotX = GUILayout.TextField(selectedObject.transform.rotation.eulerAngles.x.ToString("F2"), GUILayout.Width(60));
            string rotY = GUILayout.TextField(selectedObject.transform.rotation.eulerAngles.y.ToString("F2"), GUILayout.Width(60));
            string rotZ = GUILayout.TextField(selectedObject.transform.rotation.eulerAngles.z.ToString("F2"), GUILayout.Width(60));
            if (GUILayout.Button("应用旋转", GUILayout.Width(60)))
            {
                try
                {
                    float x = float.Parse(rotX);
                    float y = float.Parse(rotY);
                    float z = float.Parse(rotZ);
                    selectedObject.transform.rotation = Quaternion.Euler(x, y, z);
                    AddOutput($"✅ 旋转已设置为 ({x:F2}, {y:F2}, {z:F2})");
                }
                catch { AddOutput("❌ 旋转格式错误"); }
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("缩放:", GUILayout.Width(35));
            string scaleX = GUILayout.TextField(selectedObject.transform.localScale.x.ToString("F2"), GUILayout.Width(60));
            string scaleY = GUILayout.TextField(selectedObject.transform.localScale.y.ToString("F2"), GUILayout.Width(60));
            string scaleZ = GUILayout.TextField(selectedObject.transform.localScale.z.ToString("F2"), GUILayout.Width(60));
            if (GUILayout.Button("应用缩放", GUILayout.Width(60)))
            {
                try
                {
                    float x = float.Parse(scaleX);
                    float y = float.Parse(scaleY);
                    float z = float.Parse(scaleZ);
                    selectedObject.transform.localScale = new Vector3(x, y, z);
                    AddOutput($"✅ 缩放已设置为 ({x:F2}, {y:F2}, {z:F2})");
                }
                catch { AddOutput("❌ 缩放格式错误"); }
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 组件搜索 =====
            GUILayout.BeginHorizontal();
            GUILayout.Label("组件搜索:", GUILayout.Width(50));
            GUI.SetNextControlName("compSearch");
            string newCompSearch = GUILayout.TextField(componentSearchText, GUILayout.ExpandWidth(true));
            if (newCompSearch != componentSearchText) componentSearchText = newCompSearch;
            if (GUILayout.Button("清除", GUILayout.Width(40))) componentSearchText = "";
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 组件列表 =====
            inspectorScroll = GUILayout.BeginScrollView(inspectorScroll, GUILayout.ExpandHeight(true));

            Component[] components = selectedObject.GetComponents<Component>();
            foreach (var comp in components)
            {
                if (comp == null) continue;
                if (!string.IsNullOrEmpty(componentSearchText) &&
                    !comp.GetType().Name.ToLower().Contains(componentSearchText.ToLower()))
                    continue;

                if (!componentExpanded.ContainsKey(comp))
                    componentExpanded[comp] = false;

                GUILayout.BeginVertical("box");

                GUILayout.BeginHorizontal();
                string toggleIcon = componentExpanded[comp] ? "▼" : "▶";
                if (GUILayout.Button(toggleIcon, GUILayout.Width(20)))
                    componentExpanded[comp] = !componentExpanded[comp];

                GUILayout.Label(comp.GetType().Name, GUILayout.ExpandWidth(true));

                if (comp is Behaviour behaviour)
                {
                    bool enabled = behaviour.enabled;
                    bool newEnabled = GUILayout.Toggle(enabled, "启用", GUILayout.Width(50));
                    if (newEnabled != enabled) behaviour.enabled = newEnabled;
                }

                if (GUILayout.Button("删除", GUILayout.Width(25)))
                {
                    string compName = comp.GetType().Name;
                    UnityEngine.Object.Destroy(comp);
                    if (componentExpanded.ContainsKey(comp))
                        componentExpanded.Remove(comp);
                    AddOutput("已删除组件: " + compName);
                    break;
                }
                GUILayout.EndHorizontal();

                if (componentExpanded[comp])
                {
                    var fields = comp.GetType().GetFields(
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic |
                        System.Reflection.BindingFlags.Instance);

                    foreach (var field in fields)
                    {
                        if (field.Name.StartsWith("m_") || field.Name.StartsWith("<")) continue;
                        try
                        {
                            object value = field.GetValue(comp);
                            string valStr = value != null ? value.ToString() : "null";

                            if (value is MonoBehaviour && valStr.Length > 50) valStr = "MonoBehaviour";
                            if (value is GameObject go) valStr = go.name;
                            if (value is Transform t) valStr = t.position.ToString();
                            if (valStr.Length > 80) valStr = valStr.Substring(0, 80) + "...";

                            GUILayout.BeginHorizontal();
                            GUILayout.Label("  " + field.Name + ":", GUILayout.Width(140));
                            GUILayout.Label(valStr, GUILayout.ExpandWidth(true));

                            if (field.FieldType == typeof(float) || field.FieldType == typeof(int) || field.FieldType == typeof(bool))
                            {
                                string input = GUILayout.TextField(valStr, GUILayout.Width(80));
                                if (GUILayout.Button("设置", GUILayout.Width(35)))
                                {
                                    try
                                    {
                                        if (field.FieldType == typeof(float))
                                            field.SetValue(comp, float.Parse(input));
                                        else if (field.FieldType == typeof(int))
                                            field.SetValue(comp, int.Parse(input));
                                        else if (field.FieldType == typeof(bool))
                                            field.SetValue(comp, bool.Parse(input));
                                    }
                                    catch { }
                                }
                            }
                            GUILayout.EndHorizontal();
                        }
                        catch { }
                    }
                }

                GUILayout.EndVertical();
            }

            // ===== 碰撞箱列表 =====
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.Label("碰撞箱", GUILayout.ExpandWidth(true));

            Collider[] colliders = selectedObject.GetComponentsInChildren<Collider>(true);
            if (colliders.Length == 0)
            {
                GUILayout.Label("  没有碰撞箱");
            }
            else
            {
                foreach (var collider in colliders)
                {
                    if (collider == null) continue;
                    GUILayout.BeginHorizontal("box");
                    GUILayout.Label(collider.GetType().Name, GUILayout.Width(100));
                    GUILayout.Label(collider.enabled ? "启用" : "禁用", GUILayout.Width(60));
                    if (GUILayout.Button("高亮", GUILayout.Width(40)))
                        LogicColliderVisualizer.Highlight(collider);
                    if (GUILayout.Button("删除", GUILayout.Width(25)))
                        UnityEngine.Object.Destroy(collider);
                    GUILayout.EndHorizontal();
                }
            }

            GUILayout.EndScrollView();

            // ============================================================
            // ✅ 添加组件（带自动补全）
            // ============================================================
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("添加组件:", GUILayout.Width(45));

            GUI.SetNextControlName(AUTOCOMPLETE_CONTROL);
            string newInput = GUILayout.TextField(addComponentInput, GUILayout.ExpandWidth(true));

            if (Event.current.type == EventType.Repaint)
            {
                Rect lastRect = GUILayoutUtility.GetLastRect();
                autoCompleteRect = new Rect(
                    lastRect.x + browserRect.x,
                    lastRect.y + browserRect.y + lastRect.height + 2,
                    Math.Max(220, lastRect.width),
                    200
                );
            }

            if (newInput != addComponentInput)
            {
                addComponentInput = newInput;
                autoCompleteIndex = -1;
                autoCompleteScroll = Vector2.zero;

                if (!string.IsNullOrEmpty(addComponentInput))
                {
                    autoCompleteList = GetAutoCompleteMatches(addComponentInput);
                    showAutoComplete = autoCompleteList.Count > 0;
                }
                else
                {
                    showAutoComplete = false;
                }
            }

            if (GUILayout.Button("添加", GUILayout.Width(50)))
            {
                AddBrowserComponent();
            }
            GUILayout.EndHorizontal();

            if (showAutoComplete && !string.IsNullOrEmpty(addComponentInput))
            {
                GUILayout.Label($"💡 找到 {autoCompleteList.Count} 个匹配组件 (按 ↑↓ 选择，Enter 确认)", GUILayout.ExpandWidth(true));
            }
        }

        // ============================================================
        // ✅ 自动补全核心方法
        // ============================================================

        private List<string> GetAutoCompleteMatches(string input)
        {
            if (string.IsNullOrEmpty(input))
                return new List<string>();

            string inputLower = input.ToLower();

            var allTypes = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(a => { try { return a.GetTypes(); } catch { return new Type[0]; } })
                .Where(t => typeof(Component).IsAssignableFrom(t) && !t.IsAbstract && !t.IsInterface)
                .Select(t => t.Name)
                .Distinct()
                .OrderBy(n => n)
                .ToList();

            if (allTypes.Count == 0)
            {
                allTypes = new List<string>
                {
                    "Transform", "GameObject", "MonoBehaviour",
                    "MeshFilter", "MeshRenderer", "SkinnedMeshRenderer",
                    "BoxCollider", "SphereCollider", "CapsuleCollider", "MeshCollider",
                    "Rigidbody", "Rigidbody2D", "Animator", "Animation",
                    "AudioSource", "AudioListener", "Light", "Camera",
                    "ParticleSystem", "LineRenderer", "TrailRenderer",
                    "Canvas", "Image", "Text", "Button", "Slider", "Toggle",
                    "RectTransform", "LayoutGroup", "NavMeshAgent",
                    "PlayerController", "PlayerCharacter", "PlayerMovement", "PlayerHealth",
                    "EnemyController", "EnemyAI", "EnemyHealth", "WeaponController",
                    "GameManager", "UIManager", "SoundManager"
                };
            }

            return allTypes
                .Where(s => s.ToLower().Contains(inputLower))
                .OrderBy(s => s.ToLower().StartsWith(inputLower) ? 0 : 1)
                .ThenBy(s => s)
                .Take(50)
                .ToList();
        }

        void DrawAutoCompleteWindow()
        {
            if (!showAutoComplete || string.IsNullOrEmpty(addComponentInput))
                return;

            if (autoCompleteList.Count == 0)
            {
                showAutoComplete = false;
                return;
            }

            Rect rect = autoCompleteRect;
            if (rect.x + rect.width > Screen.width)
                rect.x = Screen.width - rect.width - 10;
            if (rect.x < 0) rect.x = 0;
            if (rect.y + rect.height > Screen.height)
                rect.y = Screen.height - rect.height - 10;
            if (rect.y < 0) rect.y = 0;

            GUI.Window(12399, rect, (id) =>
            {
                if (Event.current.type == EventType.KeyDown)
                {
                    string focused = GUI.GetNameOfFocusedControl();
                    if (focused == AUTOCOMPLETE_CONTROL)
                    {
                        if (Event.current.keyCode == KeyCode.DownArrow)
                        {
                            autoCompleteIndex = Math.Min(autoCompleteIndex + 1, autoCompleteList.Count - 1);
                            Event.current.Use();
                        }
                        else if (Event.current.keyCode == KeyCode.UpArrow)
                        {
                            autoCompleteIndex = Math.Max(autoCompleteIndex - 1, 0);
                            Event.current.Use();
                        }
                        else if (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.Tab)
                        {
                            if (autoCompleteIndex >= 0 && autoCompleteIndex < autoCompleteList.Count)
                            {
                                addComponentInput = autoCompleteList[autoCompleteIndex];
                                showAutoComplete = false;
                                autoCompleteIndex = -1;
                                GUI.FocusControl(null);
                                Event.current.Use();
                            }
                        }
                        else if (Event.current.keyCode == KeyCode.Escape)
                        {
                            showAutoComplete = false;
                            autoCompleteIndex = -1;
                            Event.current.Use();
                        }
                    }
                }

                autoCompleteScroll = GUILayout.BeginScrollView(autoCompleteScroll, GUILayout.Height(rect.height - 16));

                for (int i = 0; i < autoCompleteList.Count; i++)
                {
                    string match = autoCompleteList[i];
                    GUILayout.BeginHorizontal();

                    if (i == autoCompleteIndex)
                        GUI.backgroundColor = new Color(0.3f, 0.5f, 0.8f);

                    if (GUILayout.Button(match, GUILayout.ExpandWidth(true), GUILayout.Height(20)))
                    {
                        addComponentInput = match;
                        showAutoComplete = false;
                        autoCompleteIndex = -1;
                        GUI.FocusControl(null);
                    }

                    GUI.backgroundColor = Color.white;
                    GUILayout.EndHorizontal();
                }

                GUILayout.EndScrollView();

            }, "", GUI.skin.box);
        }

        private void AddBrowserComponent()
        {
            if (string.IsNullOrEmpty(addComponentInput) || selectedObject == null)
                return;

            string match = FindBestComponentMatch(addComponentInput);
            if (!string.IsNullOrEmpty(match))
            {
                ObjectEditor.AddComponent(selectedObject, match);
                AddOutput($"✅ 已添加组件: {match}");
            }
            else
            {
                ObjectEditor.AddComponent(selectedObject, addComponentInput);
                AddOutput($"✅ 尝试添加组件: {addComponentInput}");
            }

            addComponentInput = "";
            showAutoComplete = false;
            autoCompleteIndex = -1;
            GUI.FocusControl(null);
        }

        private string FindBestComponentMatch(string input)
        {
            if (string.IsNullOrEmpty(input)) return null;

            string inputLower = input.ToLower();

            var allTypes = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(a => { try { return a.GetTypes(); } catch { return new Type[0]; } })
                .Where(t => typeof(Component).IsAssignableFrom(t) && !t.IsAbstract && !t.IsInterface)
                .Select(t => t.Name)
                .Distinct()
                .ToList();

            if (allTypes.Count == 0)
            {
                allTypes = new List<string>
                {
                    "Transform", "GameObject", "MonoBehaviour", "MeshFilter", "MeshRenderer",
                    "BoxCollider", "SphereCollider", "Rigidbody", "Animator", "AudioSource",
                    "Light", "Camera", "Canvas", "Image", "Text", "Button", "RectTransform"
                };
            }

            var exact = allTypes.FirstOrDefault(s => s.ToLower() == inputLower);
            if (exact != null) return exact;

            var startsWith = allTypes.FirstOrDefault(s => s.ToLower().StartsWith(inputLower));
            if (startsWith != null) return startsWith;

            return allTypes.FirstOrDefault(s => s.ToLower().Contains(inputLower));
        }

        // ============================================================
        // 对象链接管理
        // ============================================================

        public static void DetachObject(GameObject obj)
        {
            if (obj == null) return;
            if (obj.transform.parent == null)
            {
                AddOutput($"⚠️ {obj.name} 已经是根对象，没有父对象");
                return;
            }
            Transform parent = obj.transform.parent;
            obj.transform.parent = null;
            AddOutput($"✅ 已切断 {obj.name} 与 {parent.name} 的链接");
        }

        public static void AttachObject(GameObject child, GameObject parent)
        {
            if (child == null || parent == null) return;
            if (child == parent)
            {
                AddOutput("❌ 不能将对象绑定到自己");
                return;
            }
            // 检查是否会形成循环引用
            Transform t = parent.transform;
            while (t != null)
            {
                if (t == child.transform)
                {
                    AddOutput("❌ 不能将对象绑定到自己的子对象（会形成循环）");
                    return;
                }
                t = t.parent;
            }
            child.transform.parent = parent.transform;
            AddOutput($"✅ 已将 {child.name} 绑定到 {parent.name}");
        }

        public static string GetObjectPath(GameObject obj)
        {
            if (obj == null) return "";
            List<string> path = new List<string>();
            Transform t = obj.transform;
            while (t != null)
            {
                path.Insert(0, t.name);
                t = t.parent;
            }
            return string.Join(" → ", path);
        }

        // ============================================================
        // 场景辅助方法
        // ============================================================
        void ExpandBrowserAll()
        {
            foreach (var obj in searchResults)
                ExpandBrowserAllChildren(obj.transform);
        }

        void ExpandBrowserAllChildren(Transform t)
        {
            if (t == null) return;
            if (t.childCount > 0)
            {
                hierarchyExpanded[t] = true;
                foreach (Transform child in t)
                    ExpandBrowserAllChildren(child);
            }
        }

        void CollapseBrowserAll()
        {
            hierarchyExpanded.Clear();
        }
    }
}
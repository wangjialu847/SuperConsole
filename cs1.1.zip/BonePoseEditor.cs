﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SuperConsole
{
    /// <summary>
    /// 骨骼姿势编辑器 - 实时调整骨骼位置/旋转/缩放
    /// </summary>
    public static class BonePoseEditor
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 500, 650);
        private static Vector2 scrollPos = Vector2.zero;
        private static GameObject targetObject = null;

        // ===== 骨骼数据 =====
        private static List<BonePoseData> bones = new List<BonePoseData>();
        private static Dictionary<string, Transform> boneTransforms = new Dictionary<string, Transform>();
        private static int selectedBoneIndex = -1;
        private static string searchFilter = "";

        // ===== 编辑模式 =====
        private static int editMode = 0; // 0=位置, 1=旋转, 2=缩放
        private static string posX = "0", posY = "0", posZ = "0";
        private static string rotX = "0", rotY = "0", rotZ = "0";
        private static string scaleX = "1", scaleY = "1", scaleZ = "1";

        // ===== 批量操作 =====
        private static bool batchMode = false;
        private static string batchValue = "0";
        private static int batchAxis = 0; // 0=X, 1=Y, 2=Z, 3=全部

        // ===== 姿势保存 =====
        private static string poseName = "";
        private static Dictionary<string, SavedPose> savedPoses = new Dictionary<string, SavedPose>();

        public class BonePoseData
        {
            public string name;
            public Transform transform;
            public Vector3 localPosition;
            public Quaternion localRotation;
            public Vector3 localScale;
            public Vector3 position;
            public Quaternion rotation;
            public bool isSelected;
        }

        [Serializable]
        public class SavedPose
        {
            public string name;
            public Dictionary<string, Vector3> positions = new Dictionary<string, Vector3>();
            public Dictionary<string, Quaternion> rotations = new Dictionary<string, Quaternion>();
            public Dictionary<string, Vector3> scales = new Dictionary<string, Vector3>();
            public DateTime savedTime;
        }

        // ===== 显示/隐藏 =====
        public static void Toggle(GameObject obj)
        {
            if (obj == null) { Debug.Log("[BonePoseEditor] ❌ 请先选中一个对象"); return; }

            if (visible && targetObject == obj)
            {
                visible = false;
                return;
            }

            targetObject = obj;
            visible = true;
            LoadBones();
            Debug.Log($"[BonePoseEditor] 🦴 骨骼姿势编辑器已打开: {obj.name}");
        }

        public static bool IsVisible() => visible;

        public static void ResetPosition()
        {
            windowRect = new Rect(100, 100, 500, 650);
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12357);
            windowRect = GUI.Window(12357, windowRect, DrawWindow, "🦴 骨骼姿势编辑器 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.MouseDown)
            {
                GUI.FocusControl(null);
            }

            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            GUILayout.BeginVertical();

            // ===== 标题 =====
            GUILayout.BeginHorizontal();
            GUILayout.Label($"🎯 {targetObject?.name ?? "无"} 的骨骼", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("🔄 刷新", GUILayout.Width(60))) LoadBones();
            if (GUILayout.Button("✖", GUILayout.Width(25))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 骨骼列表 =====
            GUILayout.BeginHorizontal();
            GUILayout.Label("🔍 搜索:", GUILayout.Width(45));
            GUI.SetNextControlName("boneSearch");
            string newSearch = GUILayout.TextField(searchFilter, GUILayout.ExpandWidth(true));
            if (newSearch != searchFilter) searchFilter = newSearch;
            GUILayout.Label($"共 {bones.Count} 个骨骼", GUILayout.Width(100));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            var filteredBones = string.IsNullOrEmpty(searchFilter)
                ? bones
                : bones.Where(b => b.name.ToLower().Contains(searchFilter.ToLower())).ToList();

            for (int i = 0; i < filteredBones.Count; i++)
            {
                var bone = filteredBones[i];
                bool isSelected = (selectedBoneIndex == i && !batchMode);

                GUILayout.BeginHorizontal("box");

                if (GUILayout.Button(isSelected ? "✅" : "▶", GUILayout.Width(25)))
                {
                    selectedBoneIndex = i;
                    batchMode = false;
                    LoadBoneValues(bone);
                }

                Color nameColor = isSelected ? Color.yellow : Color.white;
                GUI.color = nameColor;
                GUILayout.Label(bone.name, GUILayout.ExpandWidth(true));
                GUI.color = Color.white;

                if (GUILayout.Button("🔦", GUILayout.Width(25)))
                {
                    HighlightBone(bone);
                }

                if (GUILayout.Button("↺", GUILayout.Width(25)))
                {
                    ResetBone(bone);
                }

                GUILayout.EndHorizontal();
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 编辑面板 =====
            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
            {
                var bone = bones[selectedBoneIndex];
                DrawEditPanel(bone);
            }
            else
            {
                GUILayout.Label("点击左侧 ▶ 选择骨骼");
            }

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 批量操作 =====
            DrawBatchPanel();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 保存/加载姿势 =====
            DrawPosePanel();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        // ===== 加载骨骼 =====
        private static void LoadBones()
        {
            if (targetObject == null) return;

            bones.Clear();
            boneTransforms.Clear();
            selectedBoneIndex = -1;

            foreach (var t in targetObject.GetComponentsInChildren<Transform>())
            {
                if (t == targetObject.transform) continue;

                bones.Add(new BonePoseData
                {
                    name = t.name,
                    transform = t,
                    localPosition = t.localPosition,
                    localRotation = t.localRotation,
                    localScale = t.localScale,
                    position = t.position,
                    rotation = t.rotation,
                    isSelected = false
                });
                boneTransforms[t.name] = t;
            }

            Debug.Log($"[BonePoseEditor] 🦴 加载了 {bones.Count} 个骨骼");
        }

        // ===== 加载骨骼值到编辑框 =====
        private static void LoadBoneValues(BonePoseData bone)
        {
            if (bone == null) return;

            posX = bone.localPosition.x.ToString("F3");
            posY = bone.localPosition.y.ToString("F3");
            posZ = bone.localPosition.z.ToString("F3");

            Vector3 euler = bone.localRotation.eulerAngles;
            rotX = euler.x.ToString("F2");
            rotY = euler.y.ToString("F2");
            rotZ = euler.z.ToString("F2");

            scaleX = bone.localScale.x.ToString("F3");
            scaleY = bone.localScale.y.ToString("F3");
            scaleZ = bone.localScale.z.ToString("F3");
        }

        // ===== 绘制编辑面板 =====
        private static void DrawEditPanel(BonePoseData bone)
        {
            GUILayout.Label($"📌 编辑: {bone.name}", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            string[] modes = { "📍 位置", "🔄 旋转", "📐 缩放" };
            int newMode = GUILayout.SelectionGrid(editMode, modes, 3, GUILayout.ExpandWidth(true));
            if (newMode != editMode) editMode = newMode;
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label($"📍 位置: {bone.localPosition}", GUILayout.Width(200));
            GUILayout.Label($"🔄 旋转: {bone.localRotation.eulerAngles}", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label($"📐 缩放: {bone.localScale}", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();

            if (editMode == 0) // 位置
            {
                GUILayout.Label("X:", GUILayout.Width(15));
                GUI.SetNextControlName("posePosX");
                string x = GUILayout.TextField(posX, GUILayout.Width(60));
                if (x != posX) posX = x;

                GUILayout.Label("Y:", GUILayout.Width(15));
                GUI.SetNextControlName("posePosY");
                string y = GUILayout.TextField(posY, GUILayout.Width(60));
                if (y != posY) posY = y;

                GUILayout.Label("Z:", GUILayout.Width(15));
                GUI.SetNextControlName("posePosZ");
                string z = GUILayout.TextField(posZ, GUILayout.Width(60));
                if (z != posZ) posZ = z;

                if (GUILayout.Button("应用", GUILayout.Width(50)))
                {
                    ApplyPosition(bone);
                }
                if (GUILayout.Button("重置", GUILayout.Width(50)))
                {
                    posX = "0"; posY = "0"; posZ = "0";
                    ApplyPosition(bone);
                }
            }
            else if (editMode == 1) // 旋转
            {
                GUILayout.Label("X:", GUILayout.Width(15));
                GUI.SetNextControlName("poseRotX");
                string x = GUILayout.TextField(rotX, GUILayout.Width(50));
                if (x != rotX) rotX = x;

                GUILayout.Label("Y:", GUILayout.Width(15));
                GUI.SetNextControlName("poseRotY");
                string y = GUILayout.TextField(rotY, GUILayout.Width(50));
                if (y != rotY) rotY = y;

                GUILayout.Label("Z:", GUILayout.Width(15));
                GUI.SetNextControlName("poseRotZ");
                string z = GUILayout.TextField(rotZ, GUILayout.Width(50));
                if (z != rotZ) rotZ = z;

                if (GUILayout.Button("应用", GUILayout.Width(50)))
                {
                    ApplyRotation(bone);
                }
                if (GUILayout.Button("重置", GUILayout.Width(50)))
                {
                    rotX = "0"; rotY = "0"; rotZ = "0";
                    ApplyRotation(bone);
                }
            }
            else // 缩放
            {
                GUILayout.Label("X:", GUILayout.Width(15));
                GUI.SetNextControlName("poseScaleX");
                string x = GUILayout.TextField(scaleX, GUILayout.Width(60));
                if (x != scaleX) scaleX = x;

                GUILayout.Label("Y:", GUILayout.Width(15));
                GUI.SetNextControlName("poseScaleY");
                string y = GUILayout.TextField(scaleY, GUILayout.Width(60));
                if (y != scaleY) scaleY = y;

                GUILayout.Label("Z:", GUILayout.Width(15));
                GUI.SetNextControlName("poseScaleZ");
                string z = GUILayout.TextField(scaleZ, GUILayout.Width(60));
                if (z != scaleZ) scaleZ = z;

                if (GUILayout.Button("应用", GUILayout.Width(50)))
                {
                    ApplyScale(bone);
                }
                if (GUILayout.Button("重置", GUILayout.Width(50)))
                {
                    scaleX = "1"; scaleY = "1"; scaleZ = "1";
                    ApplyScale(bone);
                }
            }

            GUILayout.EndHorizontal();
        }

        // ===== 应用位置 =====
        private static void ApplyPosition(BonePoseData bone)
        {
            try
            {
                float x = float.Parse(posX);
                float y = float.Parse(posY);
                float z = float.Parse(posZ);
                bone.transform.localPosition = new Vector3(x, y, z);
                bone.localPosition = bone.transform.localPosition;
                Debug.Log($"[BonePoseEditor] 📍 设置 {bone.name} 位置: ({x}, {y}, {z})");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[BonePoseEditor] ❌ 位置格式错误: {ex.Message}");
            }
        }

        // ===== 应用旋转 =====
        private static void ApplyRotation(BonePoseData bone)
        {
            try
            {
                float x = float.Parse(rotX);
                float y = float.Parse(rotY);
                float z = float.Parse(rotZ);
                bone.transform.localRotation = Quaternion.Euler(x, y, z);
                bone.localRotation = bone.transform.localRotation;
                Debug.Log($"[BonePoseEditor] 🔄 设置 {bone.name} 旋转: ({x}, {y}, {z})");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[BonePoseEditor] ❌ 旋转格式错误: {ex.Message}");
            }
        }

        // ===== 应用缩放 =====
        private static void ApplyScale(BonePoseData bone)
        {
            try
            {
                float x = float.Parse(scaleX);
                float y = float.Parse(scaleY);
                float z = float.Parse(scaleZ);
                bone.transform.localScale = new Vector3(x, y, z);
                bone.localScale = bone.transform.localScale;
                Debug.Log($"[BonePoseEditor] 📐 设置 {bone.name} 缩放: ({x}, {y}, {z})");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[BonePoseEditor] ❌ 缩放格式错误: {ex.Message}");
            }
        }

        // ===== 重置骨骼 =====
        private static void ResetBone(BonePoseData bone)
        {
            bone.transform.localPosition = Vector3.zero;
            bone.transform.localRotation = Quaternion.identity;
            bone.transform.localScale = Vector3.one;
            bone.localPosition = Vector3.zero;
            bone.localRotation = Quaternion.identity;
            bone.localScale = Vector3.one;
            LoadBoneValues(bone);
            Debug.Log($"[BonePoseEditor] ↺ 重置骨骼: {bone.name}");
        }

        // ===== 高亮骨骼 =====
        private static void HighlightBone(BonePoseData bone)
        {
            if (bone == null || bone.transform == null) return;
            Debug.Log($"[BonePoseEditor] 🔦 高亮骨骼: {bone.name}");

            GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            marker.name = "BoneHighlight_" + bone.name;
            marker.transform.position = bone.transform.position;
            marker.transform.localScale = Vector3.one * 0.1f;
            Renderer renderer = marker.GetComponent<Renderer>();
            if (renderer != null) renderer.material.color = Color.yellow;
            UnityEngine.Object.Destroy(marker, 2f);
        }

        // ===== 批量操作面板 =====
        private static void DrawBatchPanel()
        {
            GUILayout.Label("📊 批量操作", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("轴:", GUILayout.Width(30));
            string[] axes = { "X", "Y", "Z", "全部" };
            int newAxis = GUILayout.SelectionGrid(batchAxis, axes, 4, GUILayout.ExpandWidth(true));
            if (newAxis != batchAxis) batchAxis = newAxis;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("值:", GUILayout.Width(35));
            GUI.SetNextControlName("batchValue");
            string newVal = GUILayout.TextField(batchValue, GUILayout.Width(80));
            if (newVal != batchValue) batchValue = newVal;

            if (GUILayout.Button("偏移位置", GUILayout.Width(70)))
            {
                BatchOffsetPosition();
            }
            if (GUILayout.Button("偏移旋转", GUILayout.Width(70)))
            {
                BatchOffsetRotation();
            }
            if (GUILayout.Button("统一缩放", GUILayout.Width(70)))
            {
                BatchSetScale();
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("重置所有骨骼", GUILayout.Width(100)))
            {
                ResetAllBones();
            }
            if (GUILayout.Button("对称镜像 (X轴)", GUILayout.Width(100)))
            {
                MirrorBonesX();
            }
            GUILayout.EndHorizontal();
        }

        // ===== 批量偏移位置 =====
        private static void BatchOffsetPosition()
        {
            if (!float.TryParse(batchValue, out float offset)) return;

            int axis = batchAxis;
            int count = 0;
            foreach (var bone in bones)
            {
                Vector3 pos = bone.transform.localPosition;
                if (axis == 0) pos.x += offset;
                else if (axis == 1) pos.y += offset;
                else if (axis == 2) pos.z += offset;
                else pos += Vector3.one * offset;
                bone.transform.localPosition = pos;
                bone.localPosition = pos;
                count++;
            }

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
                LoadBoneValues(bones[selectedBoneIndex]);

            Debug.Log($"[BonePoseEditor] 📊 偏移了 {count} 个骨骼");
        }

        // ===== 批量偏移旋转 =====
        private static void BatchOffsetRotation()
        {
            if (!float.TryParse(batchValue, out float offset)) return;

            int axis = batchAxis;
            int count = 0;
            foreach (var bone in bones)
            {
                Vector3 euler = bone.transform.localRotation.eulerAngles;
                if (axis == 0) euler.x += offset;
                else if (axis == 1) euler.y += offset;
                else if (axis == 2) euler.z += offset;
                else euler += Vector3.one * offset;
                bone.transform.localRotation = Quaternion.Euler(euler);
                bone.localRotation = bone.transform.localRotation;
                count++;
            }

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
                LoadBoneValues(bones[selectedBoneIndex]);

            Debug.Log($"[BonePoseEditor] 📊 偏移了 {count} 个骨骼的旋转");
        }

        // ===== 批量设置缩放 =====
        private static void BatchSetScale()
        {
            if (!float.TryParse(batchValue, out float scale)) return;

            int count = 0;
            foreach (var bone in bones)
            {
                bone.transform.localScale = Vector3.one * scale;
                bone.localScale = bone.transform.localScale;
                count++;
            }

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
                LoadBoneValues(bones[selectedBoneIndex]);

            Debug.Log($"[BonePoseEditor] 📊 设置了 {count} 个骨骼的缩放为 {scale}");
        }

        // ===== 重置所有骨骼 =====
        private static void ResetAllBones()
        {
            foreach (var bone in bones)
            {
                bone.transform.localPosition = Vector3.zero;
                bone.transform.localRotation = Quaternion.identity;
                bone.transform.localScale = Vector3.one;
                bone.localPosition = Vector3.zero;
                bone.localRotation = Quaternion.identity;
                bone.localScale = Vector3.one;
            }

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
                LoadBoneValues(bones[selectedBoneIndex]);

            Debug.Log($"[BonePoseEditor] ↺ 重置了所有骨骼");
        }

        // ===== X轴镜像 =====
        private static void MirrorBonesX()
        {
            int count = 0;
            var pairs = new Dictionary<string, string>();

            foreach (var bone in bones)
            {
                string name = bone.name;
                string pairName = name;

                if (name.Contains("Left") || name.Contains("L_") || name.StartsWith("L"))
                    pairName = name.Replace("Left", "Right").Replace("L_", "R_").Replace("L", "R");
                else if (name.Contains("Right") || name.Contains("R_") || name.StartsWith("R"))
                    pairName = name.Replace("Right", "Left").Replace("R_", "L_").Replace("R", "L");

                if (pairName != name && boneTransforms.ContainsKey(pairName))
                {
                    pairs[name] = pairName;
                }
            }

            foreach (var pair in pairs)
            {
                if (boneTransforms.ContainsKey(pair.Key) && boneTransforms.ContainsKey(pair.Value))
                {
                    var t1 = boneTransforms[pair.Key];
                    var t2 = boneTransforms[pair.Value];

                    Vector3 pos1 = t1.localPosition;
                    Vector3 pos2 = t2.localPosition;

                    t1.localPosition = new Vector3(-pos2.x, pos2.y, pos2.z);
                    t2.localPosition = new Vector3(-pos1.x, pos1.y, pos1.z);

                    count += 2;
                }
            }

            LoadBones();
            Debug.Log($"[BonePoseEditor] 📊 镜像了 {count} 个骨骼");
        }

        // ===== 姿势保存/加载面板 =====
        private static void DrawPosePanel()
        {
            GUILayout.Label("💾 姿势管理", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("名称:", GUILayout.Width(35));
            GUI.SetNextControlName("poseName");
            string newName = GUILayout.TextField(poseName, GUILayout.Width(120));
            if (newName != poseName) poseName = newName;

            if (GUILayout.Button("💾 保存姿势", GUILayout.Width(80)))
            {
                SavePose();
            }
            if (GUILayout.Button("📂 加载姿势", GUILayout.Width(80)))
            {
                LoadPose();
            }
            if (GUILayout.Button("🗑 删除", GUILayout.Width(60)))
            {
                DeletePose();
            }
            GUILayout.EndHorizontal();

            if (savedPoses.Count > 0)
            {
                GUILayout.BeginHorizontal();
                foreach (var kv in savedPoses)
                {
                    if (GUILayout.Button(kv.Key, GUILayout.Width(80)))
                    {
                        poseName = kv.Key;
                        LoadPose();
                    }
                }
                GUILayout.EndHorizontal();
            }
        }

        // ===== 保存姿势 =====
        private static void SavePose()
        {
            if (string.IsNullOrEmpty(poseName))
            {
                poseName = $"姿势_{DateTime.Now:HHmmss}";
            }

            var pose = new SavedPose
            {
                name = poseName,
                savedTime = DateTime.Now
            };

            foreach (var bone in bones)
            {
                pose.positions[bone.name] = bone.transform.localPosition;
                pose.rotations[bone.name] = bone.transform.localRotation;
                pose.scales[bone.name] = bone.transform.localScale;
            }

            savedPoses[poseName] = pose;
            Debug.Log($"[BonePoseEditor] 💾 保存姿势: {poseName} ({bones.Count} 个骨骼)");
        }

        // ===== 加载姿势 =====
        private static void LoadPose()
        {
            if (string.IsNullOrEmpty(poseName) || !savedPoses.ContainsKey(poseName))
            {
                Debug.LogWarning($"[BonePoseEditor] ⚠️ 找不到姿势: {poseName}");
                return;
            }

            var pose = savedPoses[poseName];

            foreach (var bone in bones)
            {
                if (pose.positions.ContainsKey(bone.name))
                {
                    bone.transform.localPosition = pose.positions[bone.name];
                    bone.localPosition = bone.transform.localPosition;
                }
                if (pose.rotations.ContainsKey(bone.name))
                {
                    bone.transform.localRotation = pose.rotations[bone.name];
                    bone.localRotation = bone.transform.localRotation;
                }
                if (pose.scales.ContainsKey(bone.name))
                {
                    bone.transform.localScale = pose.scales[bone.name];
                    bone.localScale = bone.transform.localScale;
                }
            }

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
                LoadBoneValues(bones[selectedBoneIndex]);

            Debug.Log($"[BonePoseEditor] 📂 加载姿势: {poseName}");
        }

        // ===== 删除姿势 =====
        private static void DeletePose()
        {
            if (string.IsNullOrEmpty(poseName) || !savedPoses.ContainsKey(poseName))
            {
                Debug.LogWarning($"[BonePoseEditor] ⚠️ 找不到姿势: {poseName}");
                return;
            }

            savedPoses.Remove(poseName);
            Debug.Log($"[BonePoseEditor] 🗑 删除姿势: {poseName}");
            poseName = "";
        }
    }
}
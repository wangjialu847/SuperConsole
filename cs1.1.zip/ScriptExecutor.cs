﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;

namespace SuperConsole
{
    public static class ScriptExecutor
    {
        private static string scriptPath = Path.Combine(Paths.PluginPath, "SuperConsole", "scripts");

        static ScriptExecutor()
        {
            if (!Directory.Exists(scriptPath))
            {
                Directory.CreateDirectory(scriptPath);
            }
        }

        public static void Execute(string fileName)
        {
            string fullPath = Path.Combine(scriptPath, fileName);
            if (!File.Exists(fullPath))
            {
                Debug.LogError($"[ScriptExecutor] 找不到脚本: {fullPath}");
                return;
            }

            try
            {
                string code = File.ReadAllText(fullPath);
                CompileAndRun(code, fileName);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[ScriptExecutor] 执行脚本失败: {ex.Message}");
            }
        }

        // ============================================================
        // ✅ CompileAndRun 方法必须在这里面！(在类的大括号里)
        // ============================================================
        private static void CompileAndRun(string code, string fileName)
        {
            try
            {
                var references = new List<MetadataReference>();

                foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (!assembly.IsDynamic && !string.IsNullOrEmpty(assembly.Location))
                    {
                        try { references.Add(MetadataReference.CreateFromFile(assembly.Location)); }
                        catch { }
                    }
                }

                string[] requiredDlls = new string[]
                {
                    "System.dll",
                    "System.Core.dll",
                    "UnityEngine.CoreModule.dll",
                    "UnityEngine.IMGUIModule.dll",
                    "Assembly-CSharp.dll",
                    "SuperConsole.dll",
                    "BepInEx.dll",
                    "0Harmony.dll"
                };

                foreach (var dll in requiredDlls)
                {
                    try
                    {
                        var found = AppDomain.CurrentDomain.GetAssemblies()
                            .FirstOrDefault(a => a.GetName().Name == dll.Replace(".dll", ""));
                        if (found != null && !string.IsNullOrEmpty(found.Location))
                        {
                            references.Add(MetadataReference.CreateFromFile(found.Location));
                        }
                    }
                    catch { }
                }

                var options = new CSharpCompilationOptions(
                    OutputKind.DynamicallyLinkedLibrary,
                    optimizationLevel: OptimizationLevel.Release,
                    allowUnsafe: true
                );

                string fullCode = @"
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using SuperConsole;

public class ScriptRunner
{
    public static void Run()
    {
        " + code + @"
    }
}";

                var syntaxTree = SyntaxFactory.ParseSyntaxTree(fullCode);
                var compilation = CSharpCompilation.Create(
                    "ScriptRunner",
                    new[] { syntaxTree },
                    references,
                    options
                );

                using (var ms = new MemoryStream())
                {
                    var result = compilation.Emit(ms);
                    if (!result.Success)
                    {
                        string errors = "";
                        foreach (var diagnostic in result.Diagnostics)
                        {
                            if (diagnostic.Severity == DiagnosticSeverity.Error)
                                errors += diagnostic.ToString() + "\n";
                        }
                        throw new Exception("编译错误:\n" + errors);
                    }

                    ms.Seek(0, SeekOrigin.Begin);
                    var assembly = Assembly.Load(ms.ToArray());
                    var type = assembly.GetType("ScriptRunner");
                    if (type != null)
                    {
                        var method = type.GetMethod("Run");
                        if (method != null)
                        {
                            method.Invoke(null, null);
                            Debug.Log($"[ScriptExecutor] 脚本执行成功: {fileName}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[ScriptExecutor] 执行脚本失败: {ex.Message}");
                if (ex.InnerException != null)
                    Debug.LogError($"  内部异常: {ex.InnerException.Message}");
            }
        }

        public static string[] ListScripts()
        {
            if (!Directory.Exists(scriptPath)) return new string[0];
            return Directory.GetFiles(scriptPath, "*.cs")
                .Select(Path.GetFileName)
                .ToArray();
        }
    }
}
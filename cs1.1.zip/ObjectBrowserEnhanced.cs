﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SuperConsole
{
    public static class ObjectBrowserEnhanced
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(0, 0, Screen.width, Screen.height);
        private static Vector2 browserScroll = Vector2.zero;
        private static Vector2 inspectorScroll = Vector2.zero;

        // ===== 搜索 =====
        private static string searchText = "";
        private static string componentSearchText = "";
        private static string addComponentInput = "";

        // ===== 自动补全 =====
        private static bool showComponentDropdown = false;
        private static int componentSelectedIndex = -1;
        private static List<string> componentSuggestions = new List<string>();
        private static Rect addComponentRect = Rect.zero;

        // ===== 对象数据 =====
        private static List<GameObject> searchResults = new List<GameObject>();
        private static GameObject selectedObject = null;
        private static Dictionary<Component, bool> componentExpanded = new Dictionary<Component, bool>();
        private static Dictionary<Transform, bool> hierarchyExpanded = new Dictionary<Transform, bool>();

        // ===== 窗口大小调节 =====
        private static bool isResizing = false;
        private static Vector2 resizeStartMouse;
        private static Vector2 resizeStartSize;
        private static float leftPanelWidth = 350f;
        private static bool isResizingPanel = false;

        // ===== 显示/隐藏 =====
        public static void Toggle()
        {
            visible = !visible;
            if (visible)
            {
                RefreshScene();
                LoadComponentTypes();
            }
        }

        public static bool IsVisible() => visible;

        private static void LoadComponentTypes()
        {
            componentSuggestions.Clear();
            try
            {
                var types = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(a => { try { return a.GetTypes(); } catch { return new Type[0]; } })
                    .Where(t => typeof(Component).IsAssignableFrom(t) && !t.IsAbstract && !t.IsInterface)
                    .Select(t => t.Name)
                    .Distinct()
                    .OrderBy(n => n)
                    .ToList();

                componentSuggestions.AddRange(types);
                Debug.Log($"[ObjectBrowserEnhanced] 加载了 {componentSuggestions.Count} 个组件类型");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[ObjectBrowserEnhanced] 加载组件类型失败: {ex.Message}");
            }
        }

        public static void RefreshComponentTypes()
        {
            LoadComponentTypes();
        }

        private static void RefreshScene()
        {
            searchResults.Clear();
            hierarchyExpanded.Clear();
            try
            {
                GameObject[] rootObjects = SceneManager.GetActiveScene().GetRootGameObjects();
                searchResults.AddRange(rootObjects);
            }
            catch { }
        }

        private static void SearchObjects(string text)
        {
            if (string.IsNullOrEmpty(text)) { RefreshScene(); return; }
            searchResults.Clear();
            hierarchyExpanded.Clear();
            try
            {
                GameObject[] allObjects = Resources.FindObjectsOfTypeAll<GameObject>();
                foreach (var obj in allObjects)
                {
                    if (obj != null && !string.IsNullOrEmpty(obj.name) &&
                        obj.name.ToLower().Contains(text.ToLower()) &&
                        !string.IsNullOrEmpty(obj.scene.name))
                    {
                        searchResults.Add(obj);
                        Transform t = obj.transform;
                        while (t != null && t.parent != null)
                        {
                            if (!hierarchyExpanded.ContainsKey(t.parent))
                                hierarchyExpanded[t.parent] = true;
                            t = t.parent;
                        }
                    }
                }
            }
            catch { }
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12348);
            windowRect = GUI.Window(12348, windowRect, DrawWindow, "对象浏览器增强版 [Esc关闭 | N重置]");
            HandleResize();
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.N)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
                leftPanelWidth = 350f;
                return;
            }

            if (Event.current.type == EventType.MouseDown)
            {
                GUI.FocusControl(null);
            }

            GUILayout.BeginHorizontal();

            // ===== 左侧：对象列表 =====
            GUILayout.BeginVertical(GUILayout.Width(leftPanelWidth));
            DrawLeftPanel();
            GUILayout.EndVertical();

            // ===== 拖动条 =====
            DrawPanelResizer();

            // ===== 右侧：检查器 =====
            GUILayout.BeginVertical(GUILayout.ExpandWidth(true));
            DrawInspector();
            GUILayout.EndVertical();

            GUILayout.EndHorizontal();

            GUI.DragWindow(new Rect(0, 0, windowRect.width, 20));
        }

        private static void DrawLeftPanel()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(45));
            GUI.SetNextControlName("objSearch");
            string newSearch = GUILayout.TextField(searchText, GUILayout.ExpandWidth(true));
            if (newSearch != searchText) { searchText = newSearch; SearchObjects(searchText); }
            if (GUILayout.Button("搜", GUILayout.Width(30))) SearchObjects(searchText);
            if (GUILayout.Button("刷新", GUILayout.Width(40))) { searchText = ""; RefreshScene(); }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("全部展开", GUILayout.Width(70))) ExpandAll();
            if (GUILayout.Button("全部折叠", GUILayout.Width(70))) CollapseAll();
            GUILayout.Label($"共 {searchResults.Count} 个对象", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            browserScroll = GUILayout.BeginScrollView(browserScroll, GUILayout.ExpandHeight(true));

            if (searchResults.Count == 0)
                GUILayout.Label("没有找到对象");
            else
            {
                foreach (var obj in searchResults)
                {
                    if (obj == null) continue;
                    if (obj.transform.parent == null)
                        DrawHierarchyNode(obj.transform, 0);
                }
            }

            GUILayout.EndScrollView();
        }

        private static void DrawHierarchyNode(Transform t, int depth)
        {
            if (t == null) return;

            if (!string.IsNullOrEmpty(searchText))
            {
                if (!t.name.ToLower().Contains(searchText.ToLower()))
                {
                    bool childMatches = false;
                    foreach (Transform child in t.GetComponentsInChildren<Transform>())
                    {
                        if (child != t && child.name.ToLower().Contains(searchText.ToLower()))
                        {
                            childMatches = true;
                            break;
                        }
                    }
                    if (!childMatches) return;
                }
            }

            GameObject obj = t.gameObject;

            string indent = "";
            for (int i = 0; i < depth; i++) indent += "  ";

            GUILayout.BeginHorizontal();

            if (depth > 0)
                GUILayout.Label(indent, GUILayout.Width(depth * 15));

            int childCount = t.childCount;
            if (childCount > 0)
            {
                if (!hierarchyExpanded.ContainsKey(t))
                    hierarchyExpanded[t] = false;

                string icon = hierarchyExpanded[t] ? "▼" : "▶";
                if (GUILayout.Button(icon, GUILayout.Width(20)))
                    hierarchyExpanded[t] = !hierarchyExpanded[t];
            }
            else
            {
                GUILayout.Label("  ", GUILayout.Width(20));
            }

            Color originalColor = GUI.backgroundColor;
            if (obj == selectedObject)
                GUI.backgroundColor = new Color(0.3f, 0.6f, 1f);

            if (GUILayout.Button(obj.name, GUILayout.ExpandWidth(true)))
            {
                selectedObject = obj;
                inspectorScroll = Vector2.zero;
                Debug.Log($"已选中: {obj.name}");
            }

            GUI.backgroundColor = originalColor;

            bool active = obj.activeSelf;
            bool newActive = GUILayout.Toggle(active, "", GUILayout.Width(20));
            if (newActive != active) obj.SetActive(newActive);

            GUILayout.EndHorizontal();

            if (childCount > 0 && hierarchyExpanded.ContainsKey(t) && hierarchyExpanded[t])
            {
                foreach (Transform child in t)
                    DrawHierarchyNode(child, depth + 1);
            }
        }

        private static void DrawInspector()
        {
            if (selectedObject == null)
            {
                GUILayout.Label("点击左侧对象查看详细信息");
                GUILayout.Label("或 Ctrl+左键 点击游戏中的物体");
                return;
            }

            // ===== 对象信息 =====
            GUILayout.BeginHorizontal();
            GUILayout.Label(selectedObject.name, GUILayout.ExpandWidth(true));
            GUILayout.Label("ID: " + selectedObject.GetInstanceID(), GUILayout.Width(100));
            if (GUILayout.Button("锁定", GUILayout.Width(50)))
            {
                ObjectLocker.LockSelectedAll(selectedObject);
                Debug.Log($"已锁定: {selectedObject.name}");
            }
            if (GUILayout.Button("解锁", GUILayout.Width(50)))
            {
                ObjectLocker.UnlockObject(selectedObject);
                Debug.Log($"已解锁: {selectedObject.name}");
            }
            if (GUILayout.Button("骨骼", GUILayout.Width(50)))
            {
                BoneVisualizer.Toggle(selectedObject);
            }
            if (GUILayout.Button("隐藏骨骼", GUILayout.Width(50)))
            {
                BoneVisualizer.Hide();
            }
            if (GUILayout.Button("碰撞箱", GUILayout.Width(50)))
            {
                if (selectedObject != null)
                {
                    LogicColliderVisualizer.Toggle(selectedObject);
                    Debug.Log($"碰撞箱可视化: {(LogicColliderVisualizer.IsVisible() ? "开启" : "关闭")}");
                }
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label($"位置: {selectedObject.transform.position}", GUILayout.Width(250));
            GUILayout.Label($"旋转: {selectedObject.transform.rotation.eulerAngles}", GUILayout.Width(200));
            if (GUILayout.Button("传送玩家", GUILayout.Width(80)))
            {
                GameObject player = GameObject.Find("PlayerCharacter(Clone)") ?? GameObject.FindGameObjectWithTag("Player");
                if (player != null)
                {
                    player.transform.position = selectedObject.transform.position;
                    Debug.Log($"已传送玩家到 {selectedObject.name}");
                }
            }
            if (GUILayout.Button("传送", GUILayout.Width(50)))
            {
                TeleportUI.Toggle(selectedObject);
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 组件搜索 =====
            GUILayout.BeginHorizontal();
            GUILayout.Label("组件搜索:", GUILayout.Width(50));
            GUI.SetNextControlName("compSearch");
            string newCompSearch = GUILayout.TextField(componentSearchText, GUILayout.ExpandWidth(true));
            if (newCompSearch != componentSearchText) componentSearchText = newCompSearch;
            if (GUILayout.Button("清除", GUILayout.Width(40))) componentSearchText = "";
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 组件列表 =====
            inspectorScroll = GUILayout.BeginScrollView(inspectorScroll, GUILayout.ExpandHeight(true));

            Component[] components = selectedObject.GetComponents<Component>();
            foreach (var comp in components)
            {
                if (comp == null) continue;
                if (!string.IsNullOrEmpty(componentSearchText) &&
                    !comp.GetType().Name.ToLower().Contains(componentSearchText.ToLower()))
                    continue;

                if (!componentExpanded.ContainsKey(comp))
                    componentExpanded[comp] = false;

                GUILayout.BeginVertical("box");

                GUILayout.BeginHorizontal();
                string toggleIcon = componentExpanded[comp] ? "▼" : "▶";
                if (GUILayout.Button(toggleIcon, GUILayout.Width(20)))
                    componentExpanded[comp] = !componentExpanded[comp];

                GUILayout.Label(comp.GetType().Name, GUILayout.ExpandWidth(true));

                if (comp is Behaviour behaviour)
                {
                    bool enabled = behaviour.enabled;
                    bool newEnabled = GUILayout.Toggle(enabled, "启用", GUILayout.Width(50));
                    if (newEnabled != enabled) behaviour.enabled = newEnabled;
                }

                if (GUILayout.Button("删除", GUILayout.Width(25)))
                {
                    string compName = comp.GetType().Name;
                    UnityEngine.Object.Destroy(comp);
                    if (componentExpanded.ContainsKey(comp))
                        componentExpanded.Remove(comp);
                    Debug.Log($"已删除组件: {compName}");
                    break;
                }
                GUILayout.EndHorizontal();

                if (componentExpanded[comp])
                {
                    var fields = comp.GetType().GetFields(
                        System.Reflection.BindingFlags.Public |
                        System.Reflection.BindingFlags.NonPublic |
                        System.Reflection.BindingFlags.Instance);

                    foreach (var field in fields)
                    {
                        if (field.Name.StartsWith("m_") || field.Name.StartsWith("<")) continue;
                        try
                        {
                            object value = field.GetValue(comp);
                            string valStr = value != null ? value.ToString() : "null";

                            if (value is MonoBehaviour && valStr.Length > 50) valStr = "MonoBehaviour";
                            if (value is GameObject go) valStr = go.name;
                            if (value is Transform t) valStr = t.position.ToString();
                            if (valStr.Length > 80) valStr = valStr.Substring(0, 80) + "...";

                            GUILayout.BeginHorizontal();
                            GUILayout.Label("  " + field.Name + ":", GUILayout.Width(140));
                            GUILayout.Label(valStr, GUILayout.ExpandWidth(true));

                            if (field.FieldType == typeof(float) || field.FieldType == typeof(int) || field.FieldType == typeof(bool))
                            {
                                string input = GUILayout.TextField(valStr, GUILayout.Width(80));
                                if (GUILayout.Button("设置", GUILayout.Width(35)))
                                {
                                    try
                                    {
                                        if (field.FieldType == typeof(float))
                                            field.SetValue(comp, float.Parse(input));
                                        else if (field.FieldType == typeof(int))
                                            field.SetValue(comp, int.Parse(input));
                                        else if (field.FieldType == typeof(bool))
                                            field.SetValue(comp, bool.Parse(input));
                                    }
                                    catch { }
                                }
                            }
                            GUILayout.EndHorizontal();
                        }
                        catch { }
                    }
                }

                GUILayout.EndVertical();
            }

            // ===== 碰撞箱列表 =====
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.Label("碰撞箱", GUILayout.ExpandWidth(true));

            Collider[] colliders = selectedObject.GetComponentsInChildren<Collider>(true);
            if (colliders.Length == 0)
            {
                GUILayout.Label("  没有碰撞箱");
            }
            else
            {
                foreach (var collider in colliders)
                {
                    if (collider == null) continue;
                    GUILayout.BeginHorizontal("box");
                    GUILayout.Label(collider.GetType().Name, GUILayout.Width(100));
                    GUILayout.Label(collider.enabled ? "启用" : "禁用", GUILayout.Width(60));
                    if (GUILayout.Button("高亮", GUILayout.Width(40)))
                    {
                        LogicColliderVisualizer.Highlight(collider);
                    }
                    if (GUILayout.Button("删除", GUILayout.Width(25)))
                    {
                        UnityEngine.Object.Destroy(collider);
                    }
                    GUILayout.EndHorizontal();
                }
            }

            GUILayout.EndScrollView();

            // ===== 添加组件（带自动补全） =====
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("添加组件:", GUILayout.Width(45));

            string newComponent = AutoCompleteInput.Draw(
                "",
                addComponentInput,
                componentSuggestions,
                ref showComponentDropdown,
                ref componentSelectedIndex,
                ref addComponentRect,
                GUILayout.ExpandWidth(true)
            );

            if (newComponent != addComponentInput)
            {
                addComponentInput = newComponent;
            }

            if (GUILayout.Button("添加", GUILayout.Width(50)))
            {
                if (!string.IsNullOrEmpty(addComponentInput))
                {
                    ObjectEditor.AddComponent(selectedObject, addComponentInput);
                    addComponentInput = "";
                    showComponentDropdown = false;
                    GUI.FocusControl(null);
                }
            }
            GUILayout.EndHorizontal();
        }

        private static void DrawPanelResizer()
        {
            GUILayout.Box("", GUILayout.Width(4), GUILayout.ExpandHeight(true));

            Rect resizeRect = GUILayoutUtility.GetLastRect();
            resizeRect.width = 6;
            resizeRect.x -= 2;

            if (Event.current.type == EventType.MouseDown && resizeRect.Contains(Event.current.mousePosition))
            {
                isResizingPanel = true;
                resizeStartMouse = Event.current.mousePosition;
                resizeStartSize = new Vector2(leftPanelWidth, 0);
                Event.current.Use();
            }

            if (isResizingPanel && Event.current.type == EventType.MouseDrag)
            {
                float delta = Event.current.mousePosition.x - resizeStartMouse.x;
                leftPanelWidth = Mathf.Clamp(resizeStartSize.x + delta, 150, 600);
                Event.current.Use();
            }

            if (isResizingPanel && Event.current.type == EventType.MouseUp)
            {
                isResizingPanel = false;
                Event.current.Use();
            }

            GUI.Box(resizeRect, "");
            Texture2D tex = new Texture2D(1, 1);
            tex.SetPixel(0, 0, new Color(0.5f, 0.5f, 0.5f, 0.5f));
            tex.Apply();
            GUI.DrawTexture(resizeRect, tex);
        }

        private static void HandleResize()
        {
            Rect resizeRect = new Rect(windowRect.width - 16, windowRect.height - 16, 16, 16);
            GUI.Box(resizeRect, "▽", GUIStyle.none);

            if (Event.current.type == EventType.MouseDown && resizeRect.Contains(Event.current.mousePosition))
            {
                isResizing = true;
                resizeStartMouse = Event.current.mousePosition;
                resizeStartSize = new Vector2(windowRect.width, windowRect.height);
                Event.current.Use();
            }

            if (isResizing && Event.current.type == EventType.MouseDrag)
            {
                Vector2 delta = Event.current.mousePosition - resizeStartMouse;
                windowRect.width = Mathf.Max(600, resizeStartSize.x + delta.x);
                windowRect.height = Mathf.Max(400, resizeStartSize.y + delta.y);
                Event.current.Use();
            }

            if (isResizing && Event.current.type == EventType.MouseUp)
            {
                isResizing = false;
                Event.current.Use();
            }
        }

        private static void ExpandAll()
        {
            foreach (var obj in searchResults)
                ExpandAllChildren(obj.transform);
        }

        private static void ExpandAllChildren(Transform t)
        {
            if (t == null) return;
            if (t.childCount > 0)
            {
                hierarchyExpanded[t] = true;
                foreach (Transform child in t)
                    ExpandAllChildren(child);
            }
        }

        private static void CollapseAll()
        {
            hierarchyExpanded.Clear();
        }
    }
}
using System;
using System.Collections.Generic;
using UnityEngine;
using SuperConsole;

namespace BoneAnimationExtension
{
    // ============================================================
    // 1. 扩展入口 - 实现 IExtensionInit
    // ============================================================
    public class BoneAnimationExtension : IExtensionInit
    {
        private static Dictionary<string, BoneAnimator> animators = new Dictionary<string, BoneAnimator>();

        public void OnLoad()
        {
            Debug.Log("[BoneAnimation] 🦴 骨骼动画扩展已加载！");

            // 注册逻辑体动作
            LogicAssetIntegration.RegisterAction("PlayBoneAnim", PlayBoneAnimAction);
            LogicAssetIntegration.RegisterAction("StopBoneAnim", StopBoneAnimAction);

            Debug.Log("[BoneAnimation] ✅ 已注册逻辑体动作: PlayBoneAnim, StopBoneAnim");
        }

        public void OnUnload()
        {
            // 停止所有动画
            foreach (var kv in animators)
            {
                kv.Value.Stop();
            }
            animators.Clear();
            Debug.Log("[BoneAnimation] 👋 骨骼动画扩展已卸载");
        }

        // ============================================================
        // 2. 逻辑体动作 - 播放骨骼动画
        // ============================================================
        private static void PlayBoneAnimAction(LogicAction action)
        {
            if (string.IsNullOrEmpty(action.Target))
            {
                Debug.LogWarning("[BoneAnimation] ⚠️ 没有指定目标对象");
                return;
            }

            // Target: 对象名.动画名
            // 例: "Player.idle"
            string[] parts = action.Target.Split('.');
            string objectName = parts[0];
            string animName = parts.Length > 1 ? parts[1] : "idle";

            PlayAnimation(objectName, animName);
        }

        // ============================================================
        // 3. 逻辑体动作 - 停止骨骼动画
        // ============================================================
        private static void StopBoneAnimAction(LogicAction action)
        {
            if (string.IsNullOrEmpty(action.Target))
            {
                Debug.LogWarning("[BoneAnimation] ⚠️ 没有指定目标对象");
                return;
            }

            StopAnimation(action.Target);
        }

        // ============================================================
        // 4. 播放动画
        // ============================================================
        public static void PlayAnimation(string objectName, string animName)
        {
            GameObject obj = GameObject.Find(objectName);
            if (obj == null)
            {
                Debug.LogWarning($"[BoneAnimation] ⚠️ 找不到对象: {objectName}");
                return;
            }

            // 获取或创建动画控制器
            if (!animators.ContainsKey(objectName))
            {
                animators[objectName] = new BoneAnimator(obj);
            }

            var animator = animators[objectName];
            animator.Play(animName);
            Debug.Log($"[BoneAnimation] 🎬 播放动画: {objectName} -> {animName}");
        }

        public static void StopAnimation(string objectName)
        {
            if (animators.ContainsKey(objectName))
            {
                animators[objectName].Stop();
                animators.Remove(objectName);
                Debug.Log($"[BoneAnimation] ⏹️ 停止动画: {objectName}");
            }
        }
    }

    // ============================================================
    // 5. 骨骼动画控制器
    // ============================================================
    public class BoneAnimator
    {
        private GameObject target;
        private Dictionary<string, Transform> bones = new Dictionary<string, Transform>();
        private Dictionary<string, Vector3> restPositions = new Dictionary<string, Vector3>();
        private Dictionary<string, Quaternion> restRotations = new Dictionary<string, Quaternion>();

        private string currentAnim = "";
        private float timer = 0f;
        private float duration = 2f;
        private bool isPlaying = false;

        public BoneAnimator(GameObject obj)
        {
            target = obj;
            CollectBones();
            SaveRestPose();

            // 自动更新 (每帧)
            // 注意: 需要注册到主 Update，通过 SuperConsole 的 LogicManager 或自行启动协程
            // 这里用简单方式：在扩展里启动一个 Update 循环
        }

        private void CollectBones()
        {
            bones.Clear();
            foreach (var t in target.GetComponentsInChildren<Transform>())
            {
                if (t != target.transform)
                {
                    bones[t.name] = t;
                }
            }
            Debug.Log($"[BoneAnimator] 🦴 找到 {bones.Count} 个骨骼");
        }

        private void SaveRestPose()
        {
            restPositions.Clear();
            restRotations.Clear();
            foreach (var kv in bones)
            {
                restPositions[kv.Key] = kv.Value.localPosition;
                restRotations[kv.Key] = kv.Value.localRotation;
            }
        }

        public void Play(string animName)
        {
            currentAnim = animName;
            timer = 0f;
            duration = 2f;
            isPlaying = true;
            Debug.Log($"[BoneAnimator] ▶️ 播放: {animName}");
        }

        public void Stop()
        {
            isPlaying = false;
            ResetPose();
            Debug.Log($"[BoneAnimator] ⏹️ 停止");
        }

        public void Update(float deltaTime)
        {
            if (!isPlaying) return;

            timer += deltaTime;
            float t = Mathf.Clamp01(timer / duration);

            // 根据动画名称执行不同逻辑
            switch (currentAnim)
            {
                case "idle":
                    UpdateIdle(t);
                    break;
                case "walk":
                    UpdateWalk(t);
                    break;
                case "jump":
                    UpdateJump(t);
                    break;
                case "wave":
                    UpdateWave(t);
                    break;
                case "dance":
                    UpdateDance(t);
                    break;
                case "float":
                    UpdateFloat(t);
                    break;
                case "spin":
                    UpdateSpin(t);
                    break;
                case "bounce":
                    UpdateBounce(t);
                    break;
                default:
                    // 自定义
                    break;
            }

            // 循环播放
            if (timer >= duration)
            {
                timer = 0f;
                // 重置到初始姿态再播下一轮
                ResetPose();
            }
        }

        private void ResetPose()
        {
            foreach (var kv in bones)
            {
                if (restPositions.ContainsKey(kv.Key))
                    kv.Value.localPosition = restPositions[kv.Key];
                if (restRotations.ContainsKey(kv.Key))
                    kv.Value.localRotation = restRotations[kv.Key];
            }
        }

        // ============================================================
        // 6. 动画函数 (用户可以自定义)
        // ============================================================

        private void UpdateIdle(float t)
        {
            // 轻微呼吸效果 - 上浮动
            float breathe = Mathf.Sin(t * 2f * Mathf.PI) * 0.02f;
            if (bones.ContainsKey("Head"))
                bones["Head"].localPosition += Vector3.up * breathe;

            if (bones.ContainsKey("Spine"))
                bones["Spine"].localPosition += Vector3.up * breathe * 0.5f;
        }

        private void UpdateWalk(float t)
        {
            // 腿部交替摆动
            float swing = Mathf.Sin(t * 4f * Mathf.PI) * 30f;

            if (bones.ContainsKey("LeftLeg"))
                bones["LeftLeg"].localRotation *= Quaternion.Euler(swing, 0, 0);
            if (bones.ContainsKey("RightLeg"))
                bones["RightLeg"].localRotation *= Quaternion.Euler(-swing, 0, 0);

            // 身体轻微起伏
            float bob = Mathf.Abs(Mathf.Sin(t * 4f * Mathf.PI)) * 0.05f;
            if (bones.ContainsKey("Spine"))
                bones["Spine"].localPosition += Vector3.up * bob;
        }

        private void UpdateJump(float t)
        {
            // 跳跃弧线
            float height = Mathf.Sin(t * Mathf.PI) * 0.5f;

            if (bones.ContainsKey("Spine"))
                bones["Spine"].localPosition += Vector3.up * height;

            // 手臂上摆
            float armSwing = Mathf.Sin(t * Mathf.PI) * 45f;
            if (bones.ContainsKey("LeftArm"))
                bones["LeftArm"].localRotation *= Quaternion.Euler(-armSwing, 0, 0);
            if (bones.ContainsKey("RightArm"))
                bones["RightArm"].localRotation *= Quaternion.Euler(-armSwing, 0, 0);
        }

        private void UpdateWave(float t)
        {
            // 挥手
            float wave = Mathf.Sin(t * 6f * Mathf.PI) * 45f;

            if (bones.ContainsKey("RightArm"))
                bones["RightArm"].localRotation *= Quaternion.Euler(0, 0, wave);
            if (bones.ContainsKey("RightHand"))
                bones["RightHand"].localRotation *= Quaternion.Euler(0, wave * 0.5f, 0);
        }

        private void UpdateDance(float t)
        {
            // 扭动
            float hipSway = Mathf.Sin(t * 3f * Mathf.PI) * 15f;
            float upperTwist = Mathf.Sin(t * 2f * Mathf.PI + 1) * 20f;

            if (bones.ContainsKey("Hips"))
                bones["Hips"].localRotation *= Quaternion.Euler(0, 0, hipSway);
            if (bones.ContainsKey("Spine"))
                bones["Spine"].localRotation *= Quaternion.Euler(0, upperTwist, 0);
            if (bones.ContainsKey("Head"))
                bones["Head"].localRotation *= Quaternion.Euler(Mathf.Sin(t * 4f * Mathf.PI) * 10f, 0, 0);
        }

        private void UpdateFloat(float t)
        {
            // 漂浮上下
            float floatY = Mathf.Sin(t * 2f * Mathf.PI) * 0.2f;
            float floatRot = Mathf.Sin(t * 1.5f * Mathf.PI) * 5f;

            if (bones.ContainsKey("Spine"))
                bones["Spine"].localPosition += Vector3.up * floatY;
            if (bones.ContainsKey("Head"))
                bones["Head"].localRotation *= Quaternion.Euler(0, floatRot, 0);
        }

        private void UpdateSpin(float t)
        {
            // 旋转
            float spin = t * 360f;

            if (bones.ContainsKey("Spine"))
                bones["Spine"].localRotation *= Quaternion.Euler(0, spin, 0);
        }

        private void UpdateBounce(float t)
        {
            // 弹跳
            float bounce = Mathf.Abs(Mathf.Sin(t * 3f * Mathf.PI)) * 0.3f;

            if (bones.ContainsKey("Spine"))
                bones["Spine"].localPosition += Vector3.up * bounce;
        }
    }

    // ============================================================
    // 7. 控制台命令（可选）
    // ============================================================
    public class BoneAnimCommand : ICommand
    {
        public string Name => "boneanim";
        public string Code => "boneanim <对象名> <动画名>";
        public string Description => "播放骨骼动画 (idle/walk/jump/wave/dance/float/spin/bounce)";
    }
}
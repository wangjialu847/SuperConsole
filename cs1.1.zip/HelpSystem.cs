﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using BepInEx;

namespace SuperConsole
{
    /// <summary>
    /// 帮助系统 - 完整的教程和介绍文档
    /// 按 PageUp 打开
    /// </summary>
    public static class HelpSystem
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(50, 50, 850, 700);
        private static Vector2 scrollPos = Vector2.zero;
        private static int selectedTab = 0;

        // ===== 文档内容 =====
        private static string[] tabs = {
            "快速入门",
            "功能教程",
            "骨骼系统",
            "逻辑体V2",
            "扩展开发",
            "常见问题"
        };
        private static string[] content = new string[6];

        // ===== 初始化 =====
        static HelpSystem()
        {
            GenerateContent();
        }

        // ===== 显示/隐藏 =====
        public static void Toggle()
        {
            visible = !visible;
            if (visible)
            {
                selectedTab = 0;
                scrollPos = Vector2.zero;
            }
        }

        public static bool IsVisible() => visible;

        // ===== 绘制入口 =====
        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12355);
            windowRect = GUI.Window(12355, windowRect, DrawWindow, "帮助中心 [PageUp/Esc关闭]");
        }

        // ===== 窗口绘制 =====
        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown &&
                (Event.current.keyCode == KeyCode.Escape || Event.current.keyCode == KeyCode.PageUp))
            {
                visible = false;
                return;
            }

            if (Event.current.type == EventType.MouseDown)
            {
                GUI.FocusControl(null);
            }

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            int newTab = GUILayout.SelectionGrid(selectedTab, tabs, tabs.Length, GUILayout.ExpandWidth(true));
            if (newTab != selectedTab)
            {
                selectedTab = newTab;
                scrollPos = Vector2.zero;
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            GUIStyle textStyle = new GUIStyle(GUI.skin.label);
            textStyle.wordWrap = true;
            textStyle.richText = true;
            textStyle.fontSize = 13;
            textStyle.padding = new RectOffset(10, 10, 5, 5);

            GUILayout.Label(content[selectedTab], textStyle, GUILayout.ExpandWidth(true));

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("按 PageUp 或 Esc 关闭", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("导出到文件", GUILayout.Width(100)))
            {
                ExportToFile();
            }
            if (GUILayout.Button("关闭", GUILayout.Width(60)))
            {
                visible = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        // ============================================================
        // 自动导出
        // ============================================================
        public static void AutoExport()
        {
            try
            {
                string path = Path.Combine(Paths.PluginPath, "SuperConsole", "SuperConsole_Help.txt");
                string fullContent = "";

                GenerateContent();

                for (int i = 0; i < tabs.Length; i++)
                {
                    fullContent += "========================================\n";
                    fullContent += "  " + tabs[i] + "\n";
                    fullContent += "========================================\n\n";

                    string clean = content[i]
                        .Replace("<b>", "").Replace("</b>", "")
                        .Replace("<size=18>", "").Replace("</size>", "")
                        .Replace("<size=15>", "").Replace("</size>", "")
                        .Replace("<color=#FFD700>", "").Replace("</color>", "")
                        .Replace("<color=#00FF88>", "").Replace("</color>", "")
                        .Replace("<color=#888888>", "").Replace("</color>", "")
                        .Replace("<color=#FF6B6B>", "").Replace("</color>", "")
                        .Replace("<color=#4ECDC4>", "").Replace("</color>", "");

                    fullContent += clean + "\n\n";
                }

                string dir = Path.GetDirectoryName(path);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                File.WriteAllText(path, fullContent);
                Debug.Log("[HelpSystem] 帮助文档已自动生成: " + path);
            }
            catch (Exception ex)
            {
                Debug.LogError("[HelpSystem] 自动生成失败: " + ex.Message);
            }
        }

        // ============================================================
        // 生成文档内容
        // ============================================================
        private static void GenerateContent()
        {
            content[0] = GetQuickStart();
            content[1] = GetFunctionTutorial();
            content[2] = GetBoneSystem();
            content[3] = GetLogicV2();
            content[4] = GetExtensionDev();
            content[5] = GetFAQ();
        }

        // ============================================================
        // 1. 快速入门
        // ============================================================
        private static string GetQuickStart()
        {
            return @"
<b><size=18>SuperConsole 快速入门</size></b>

========================================

<b><size=15>这是什么？</size></b>

SuperConsole 是一个运行在 Unity Mono 游戏内部的高权限运行时修改工具。
按 Insert 键召唤，然后想干什么就干什么。

<b>一句话总结：</b>
Cheat Engine + UnityExplorer + 模组框架 + 资源提取器 + 骨骼编辑器，2天写完。

========================================

<b><size=15>安装方法</size></b>

步骤 1： 安装 BepInEx 到游戏目录
步骤 2： 把 SuperConsole.dll 放到 BepInEx/plugins/
步骤 3： 启动游戏
步骤 4： 按 Insert 键召唤控制台

========================================

<b><size=15>快捷键速查</size></b>

Insert          打开/关闭主控制台
Home            打开 Hook 管理器
End             打开方法管理器
F (控制台关闭时) 切换自由视角
Esc             关闭当前窗口 / 退出自由视角
Ctrl+左键       在游戏中点击选中物体
回车            执行输入框中的 C# 代码
PageUp          打开这个帮助
N               重置所有窗口位置

========================================

<b><size=15>第一个操作</size></b>

1. 按 Insert 打开控制台
2. 点击对象浏览器
3. 在左侧找一个对象（比如 Player）
4. 点击选中，右侧会显示它的组件
5. 展开组件，找到 health 字段
6. 修改数值，点击设置
7. 游戏里的血量就变了！

就这么简单。你已经是 SuperConsole 用户了。

========================================

<b><size=15>继续学习</size></b>

切换到下一个选项卡了解更多功能！
";
        }

        // ============================================================
        // 2. 功能教程
        // ============================================================
        private static string GetFunctionTutorial()
        {
            return @"
<b><size=18>功能教程</size></b>

========================================

<b><size=15>1. 内存搜索（Cheat Engine 级别）</size></b>

支持 11 种搜索模式：
精确、大于、小于、大于等于、小于等于、范围、变化、不变、增加、减少、模糊

支持 9 种数据类型：
自动、float、int、double、long、short、byte、bool、string

怎么用：
1. 打开控制台 -> 点击内存搜索
2. 选择模式（默认精确）
3. 选择数据类型（默认自动）
4. 输入搜索值
5. 点击搜索
6. 结果会显示在列表中
7. 点击选择 -> 在下方输入新值 -> 点击修改选中

技巧：先用精确搜索找到值，再用变化/不变过滤！

========================================

<b><size=15>2. 对象浏览器增强版</size></b>

能干什么：
- 查看场景所有对象（树形层级）
- 查看/修改任何组件（包括私有字段）
- 启用/禁用组件
- 添加/删除组件（带自动补全！）
- 传送玩家到选中对象位置
- Ctrl+左键 在游戏场景中点击选中
- 查看/高亮碰撞箱

技巧：添加组件时输入框会自动补全组件名！

========================================

<b><size=15>3. 游戏资源提取器</size></b>

能提取什么：
- 纹理 (Texture2D) -> .png
- 模型 (Mesh) -> .obj
- 音频 (AudioClip) -> .wav (记录)
- 材质 (Material) -> .mat
- 动画 (AnimationClip) -> .anim

怎么用：
打开控制台 -> 点击资源提取 -> 点击刷新扫描 -> 点击提取

这是 2.0 的雏形！从改游戏到搬游戏！

========================================

<b><size=15>4. 本地资源管理器</size></b>

支持格式：
- 模型：.obj, .fbx, .dae, .gltf, .stl
- 纹理：.png, .jpg, .tga, .dds
- 音频：.wav, .mp3, .ogg, .flac
- 预制体：.prefab
- 动画：.anim
- 材质：.mat
- 资源包：.unity3d, .assetbundle

怎么用：
把文件放到 SuperConsole/Assets/对应文件夹 -> 资源管理器里加载 -> 生成

========================================

<b><size=15>5. Hook 管理器</size></b>

6 个预设 Hook：
- 禁用晕倒（RagdollController.Knockout）
- 禁用伤害（PlayerCharacter.TakeDamage）
- 禁用死亡（PlayerCharacter.Die）
- 禁用扣血（PlayerCharacter.ApplyDamage）
- 禁用重力（Rigidbody.UpdateGravity）
- 禁用物理（Physics.Simulate）

按 Home 键打开 -> 点击安装 -> 立即生效！

========================================

<b><size=15>6. 对象锁定系统</size></b>

锁定数值，每帧自动恢复，重生/读档/重启都有效。

怎么用：
1. 在对象浏览器中选中一个对象
2. 点击锁定此对象 -> 锁定所有数值字段
3. 点击解锁此对象解除锁定

========================================

<b><size=15>7. 传送系统</size></b>

两种模式：
- 坐标模式：输入 X/Y/Z 坐标传送
- 物体模式：点击选择物体，传送到该物体位置

支持：传送玩家、传送任何选中对象

========================================

<b><size=15>8. C# 代码执行</size></b>

直接执行任意 C# 代码！

示例：
// 改血量
GameObject.Find(""Player(Clone)"").GetComponent<PlayerCharacter>().health = 9999;

// 找对象
GameObject.Find(""Player(Clone)"");

命令字典里有 18 个模板，一键填入！
";
        }

        // ============================================================
        // 3. 骨骼系统
        // ============================================================
        private static string GetBoneSystem()
        {
            return @"
<b><size=18>骨骼系统完整教程</size></b>

========================================

SuperConsole 包含 3 个骨骼相关工具，从查看、编辑到动画，全套搞定！

========================================

<b><size=15>骨骼浏览器 (BoneVisualizer)</size></b>

用途： 查看角色骨架结构

怎么用：
1. 在对象浏览器中选中一个对象
2. 点击骨骼按钮
3. 树形显示所有骨骼
4. 点击骨骼名称 -> 高亮显示
5. 5 种颜色可切换：蓝 红 绿 黄 紫

显示选项：
- Skeleton - 显示骨骼连线
- Outline - 显示包围盒
- Names - 显示骨骼名称

适用于：查看角色骨架、找到特定骨骼名称、为模组制作做准备

========================================

<b><size=15>骨骼姿势编辑器 (BonePoseEditor)</size></b>

用途： 实时调整骨骼位置/旋转/缩放

怎么用：
1. 在对象浏览器中选中一个对象
2. 点击姿势编辑按钮（或从骨骼浏览器进入）
3. 在骨骼列表中选择要编辑的骨骼
4. 切换编辑模式：
   - 位置 - 修改 localPosition
   - 旋转 - 修改 localRotation
   - 缩放 - 修改 localScale
5. 输入数值 -> 点击应用

批量操作：
- 批量偏移位置/旋转（所有骨骼）
- 统一缩放
- 重置所有骨骼
- X轴镜像 - 自动镜像左右对称骨骼！

姿势管理：
- 保存姿势 - 保存当前所有骨骼姿态
- 加载姿势 - 恢复之前保存的姿态
- 命名姿势以便管理

高级功能：批量偏移 + 镜像 = 快速调整整个骨架！

========================================

<b><size=15>骨骼动画扩展 (BoneAnimationExtension)</size></b>

用途： 让角色播放骨骼动画

内置动画：
- idle - 呼吸浮动
- walk - 腿部交替摆动 + 身体起伏
- jump - 跳跃弧线 + 手臂上摆
- wave - 挥手
- dance - 扭动
- float - 漂浮
- spin - 旋转
- bounce - 弹跳

怎么用：

方法 1：逻辑体动作
在逻辑体编辑器中添加动作：
- 动作类型: PlayBoneAnim
- 目标: 对象名.动画名
- 例: Player.idle

方法 2：控制台命令
输入: boneanim Player idle

方法 3：代码
BoneAnimationExtension.PlayAnimation(""Player"", ""dance"");

这是扩展系统的示例！你可以自己添加更多动画函数。

========================================

<b><size=15>骨骼系统快捷键</size></b>

点击骨骼名称     高亮显示（黄色）
高亮按钮         临时高亮（2秒）
重置按钮         重置单骨骼到零点
颜色按钮         切换所有骨骼颜色
N 键             重置窗口位置
Esc 键           关闭窗口

========================================

<b><size=15>实战示例：给角色摆 Pose</size></b>

步骤：
1. 选中角色 -> 对象浏览器 -> 点击姿势编辑
2. 找到 Head 骨骼 -> 调整旋转 -> 让角色抬头
3. 找到 LeftArm -> 调整位置和旋转 -> 摆出举手姿势
4. 找到 RightLeg -> 调整位置 -> 摆出迈步姿势
5. 点击保存姿势 -> 命名招手
6. 以后随时加载姿势恢复

完美！你可以给角色摆任何姿势了！
";
        }

        // ============================================================
        // 4. 逻辑体 V2
        // ============================================================
        private static string GetLogicV2()
        {
            return @"
<b><size=18>逻辑体系统 V2（核弹级功能）</size></b>

========================================

逻辑体 V2 是 SuperConsole 的模组系统。把一个游戏对象变成可导出、可分享、可复用的模组。

========================================

<b><size=15>文件结构</size></b>

Logics/我的角色/
├── mod.json          识别文件 + 元数据
├── prefabs/
│   └── main.prefab    预制体（二进制+文本双格式）
├── models/
│   └── character.obj  模型
├── textures/
│   └── diffuse.png    纹理
├── materials/
│   └── character.mat  材质
├── animations/
│   └── idle.anim      动画
└── logic.dll          对象专属 DLL（可选）

========================================

<b><size=15>支持的类型</size></b>

Prefab     单个预制体
Scene      完整场景
Map        地图/关卡
Character  角色
Weapon     武器
Vehicle    载具
Prop       道具/装饰
Mod        完整模组（包含多种资源）

========================================

<b><size=15>提取流程</size></b>

从游戏对象提取：
1. 在对象浏览器中选中一个对象
2. 打开逻辑体 -> 点击提取当前对象
3. 自动提取：Mesh -> .obj, Texture -> .png, Material -> .mat, Animation -> .anim
4. 保存到 Logics/ 目录

从场景提取：
1. 打开逻辑体 -> 点击提取场景
2. 扫描场景所有对象
3. 提取所有资源

========================================

<b><size=15>召唤流程</size></b>

三种召唤方式：
- 召唤到玩家 - 在玩家位置生成
- 召唤到鼠标 - 在鼠标点击位置生成
- 批量召唤 - 生成多个

自动加载资源：
1. 读取 mod.json -> 获取资源列表
2. 加载预制体（.prefab）
3. 加载模型（.obj -> Mesh）
4. 加载纹理（.png -> Texture2D）
5. 加载材质（.mat -> Material）
6. 加载动画（.anim -> AnimationClip）
7. 加载 DLL（logic.dll -> 附加组件 + 初始化）

========================================

<b><size=15>分享模组</size></b>

导出：
选中逻辑体 -> 点击导出 .mod -> 生成 .mod 文件

导入：
把 .mod 文件放到 Logics/ 目录 -> 点击导入 .mod -> 自动解压

.mod 就是压缩包，可以分享给任何人！

========================================

<b><size=15>3D 预览</size></b>

选中逻辑体 -> 点击 3D 预览

支持：
- 拖拽旋转视角
- 滚轮缩放
- 显示/隐藏 模型/骨骼/碰撞箱/网格/轴
- 选择骨骼 -> 实时编辑位置/旋转/缩放
- 碰撞箱列表 -> 查看/编辑/删除
- 保存修改 -> 应用到对象

这几乎就是一个迷你 Unity Editor！

========================================

<b><size=15>逻辑体 DLL 扩展</size></b>

接口：
public interface ILogicObject
{
    void OnSpawn(GameObject gameObject, LogicEntityV2 logic);
    void OnDestroy(GameObject gameObject);
    void OnUpdate();
    void OnMessage(string message, object data);
}

使用：
1. 编译 DLL，引用 SuperConsole.dll
2. 实现 ILogicObject
3. 放到逻辑体文件夹 -> 命名为 logic.dll
4. 召唤逻辑体时自动加载 + 初始化
";
        }

        // ============================================================
        // 5. 扩展开发
        // ============================================================
        private static string GetExtensionDev()
        {
            return @"
<b><size=18>DLL 扩展开发</size></b>

========================================

SuperConsole 支持 7 种扩展接口，你可以无限扩展功能！

========================================

<b><size=15>7 种接口</size></b>

IExtensionInit  加载/卸载回调（必须实现）
ICommand        注册控制台命令
IWindow         创建自定义窗口
IScript         脚本执行器
IHookPreset     注册 Hook 预设
ILogicEntity    注册逻辑体
IPrefabProvider 提供预制体

========================================

<b><size=15>最小扩展（5 行代码）</size></b>

using SuperConsole;
using UnityEngine;

public class MyExtension : IExtensionInit
{
    public void OnLoad() { Debug.Log(""扩展加载了！""); }
    public void OnUnload() { Debug.Log(""扩展卸载了！""); }
}

========================================

<b><size=15>完整扩展示例</size></b>

using SuperConsole;
using UnityEngine;

public class Main : IExtensionInit, ICommand
{
    // 初始化
    public void OnLoad()
    {
        Debug.Log(""[MyExt] 加载成功！"");
        ExtensionCommands.RegisterCommand(""mycmd"", (args) => {
            Debug.Log(""[MyExt] 执行 mycmd"");
        });
    }
    
    public void OnUnload() { Debug.Log(""[MyExt] 卸载了""); }
    
    // 注册命令
    public string Name => ""mycmd"";
    public string Code => ""mycmd <参数>"";
    public string Description => ""我的自定义命令"";
}

========================================

<b><size=15>骨骼动画扩展示例</size></b>

public class BoneAnimationExtension : IExtensionInit
{
    public void OnLoad()
    {
        // 注册逻辑体动作
        LogicAssetIntegration.RegisterAction(""PlayBoneAnim"", PlayBoneAnimAction);
        LogicAssetIntegration.RegisterAction(""StopBoneAnim"", StopBoneAnimAction);
    }
    
    public void OnUnload() { }
    
    private static void PlayBoneAnimAction(LogicAction action)
    {
        string[] parts = action.Target.Split('.'); // Player.idle
        BoneAnimationExtension.PlayAnimation(parts[0], parts[1]);
    }
}

========================================

<b><size=15>编译与部署</size></b>

编译：
csc /target:library /r:SuperConsole.dll /r:UnityEngine.CoreModule.dll MyExtension.cs

部署：
把 MyExtension.dll 放到
BepInEx/plugins/SuperConsole/extensions/

管理扩展：
- 控制台输入 ext list -> 列出所有扩展
- ext reload -> 重新加载所有扩展
- ext disable MyExtension.dll -> 禁用扩展
- ext enable MyExtension.dll -> 启用扩展

========================================

<b><size=15>你可以做什么？</size></b>

用扩展可以：
- 添加新命令（cmd:xxx）
- 创建自定义窗口（UI）
- 注册新 Hook
- 添加新逻辑体类型
- 集成外部 API
- 导入/导出数据
- 任何你能想到的！
";
        }

        // ============================================================
        // 6. 常见问题
        // ============================================================
        private static string GetFAQ()
        {
            return @"
<b><size=18>常见问题</size></b>

========================================

Q：SuperConsole 是什么？

A：一个运行在 Unity Mono 游戏内部的高权限运行时修改工具。
按 Insert 键召唤，然后想干什么就干什么。

---

Q：骨骼浏览器、姿势编辑器、动画扩展有什么区别？

A：
骨骼浏览器      查看     显示骨架树形结构
姿势编辑器      编辑     修改位置/旋转/缩放
动画扩展        播放     播放预设动画

---

Q：逻辑体 V1 和 V2 有什么区别？

A：
条件-动作编辑   V1 有    V2 无（用代码代替）
预制体提取      V1 无    V2 有
资源导出        V1 无    V2 有 .obj/.png/.mat/.anim
模组分享        V1 无    V2 有 .mod 打包
3D 预览        V1 无    V2 有
DLL 支持       V1 无    V2 有
场景提取        V1 无    V2 有

---

Q：这玩意儿权限高吗？

A：高到离谱。运行在游戏进程内部，可以：
- 读取/修改任何内存
- 拦截/修改任何方法
- 执行任意 C# 代码
- 加载任意 DLL
- 创建/删除任何对象
- 提取任何资源

唯一限制：必须装 BepInEx。

---

Q：会封号吗？

A：如果有反作弊（EAC/BattlEye），可能会被检测。
建议只在单机游戏或私人服务器使用。

你用来干什么，我不负责。MIT 协议，出了事别找我。

---

Q：为什么代码看起来像史山？

A：因为就是史山。2 天写了 200KB 代码，没时间重构。

但史山能用，而且功能碾压同类。

---

Q：能支持 Il2Cpp 吗？

A：目前只支持 Mono。Il2Cpp 需要重写，等未来吧（可能不会）。

---

Q：我能做什么？

A：你可以：
- 改游戏参数（血量/速度/金钱）
- 提取游戏资源（模型/纹理/音频）
- 编辑骨骼姿势（给角色摆 Pose）
- 播放骨骼动画（让角色动起来）
- 写 DLL 扩展（新功能）
- 写逻辑体模组（导出/分享）
- 拦截游戏方法（Hook）

一切取决于你的想象力。

========================================

<b><size=15>遇到问题？</size></b>

1. 检查 BepInEx 是否正确安装
2. 检查 SuperConsole.dll 是否在 plugins/
3. 检查游戏是否为 Unity Mono（不是 Il2Cpp）
4. 看看日志（BepInEx/LogOutput.log）
5. 我不管了，你自己修（MIT）
";
        }

        // ============================================================
        // 导出到文件
        // ============================================================
        private static void ExportToFile()
        {
            try
            {
                string path = Path.Combine(Paths.PluginPath, "SuperConsole", "SuperConsole_Help.txt");
                string fullContent = "";

                for (int i = 0; i < tabs.Length; i++)
                {
                    fullContent += "========================================\n";
                    fullContent += "  " + tabs[i] + "\n";
                    fullContent += "========================================\n\n";

                    string clean = content[i]
                        .Replace("<b>", "").Replace("</b>", "")
                        .Replace("<size=18>", "").Replace("</size>", "")
                        .Replace("<size=15>", "").Replace("</size>", "")
                        .Replace("<color=#FFD700>", "").Replace("</color>", "")
                        .Replace("<color=#00FF88>", "").Replace("</color>", "")
                        .Replace("<color=#888888>", "").Replace("</color>", "")
                        .Replace("<color=#FF6B6B>", "").Replace("</color>", "")
                        .Replace("<color=#4ECDC4>", "").Replace("</color>", "");

                    fullContent += clean + "\n\n";
                }

                File.WriteAllText(path, fullContent);
                Debug.Log("[HelpSystem] 帮助文档已导出到: " + path);
            }
            catch (Exception ex)
            {
                Debug.LogError("[HelpSystem] 导出失败: " + ex.Message);
            }
        }
    }
}
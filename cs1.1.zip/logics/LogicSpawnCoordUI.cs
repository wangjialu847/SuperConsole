﻿using System;
using UnityEngine;

namespace SuperConsole
{
    /// <summary>
    /// 召唤到坐标 — 输入 X/Y/Z 坐标
    /// </summary>
    public static class LogicSpawnCoordUI
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(200, 200, 400, 250);
        private static LogicEntityV2 targetLogic = null;
        private static string posX = "0";
        private static string posY = "0";
        private static string posZ = "0";
        private static string statusMessage = "请输入坐标";

        public static void Toggle(LogicEntityV2 logic)
        {
            if (logic == null) return;
            targetLogic = logic;
            visible = !visible;

            if (visible)
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player == null) player = GameObject.Find("PlayerCharacter(Clone)");
                if (player != null)
                {
                    Vector3 pos = player.transform.position;
                    posX = pos.x.ToString("F2");
                    posY = pos.y.ToString("F2");
                    posZ = pos.z.ToString("F2");
                }
                statusMessage = "请输入坐标 (默认: 玩家位置)";
                windowRect = new Rect(200, 200, 400, 250);
            }
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12366);
            windowRect = GUI.Window(12366, windowRect, DrawWindow, "📍 召唤到坐标");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            GUILayout.BeginVertical();

            GUILayout.Label($"🎯 召唤: {targetLogic?.GetDisplayName() ?? "未知"}");

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("📝 输入目标坐标:");

            GUILayout.BeginHorizontal();
            GUILayout.Label("X:", GUILayout.Width(20));
            posX = GUILayout.TextField(posX, GUILayout.Width(80));
            GUILayout.Label("Y:", GUILayout.Width(20));
            posY = GUILayout.TextField(posY, GUILayout.Width(80));
            GUILayout.Label("Z:", GUILayout.Width(20));
            posZ = GUILayout.TextField(posZ, GUILayout.Width(80));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("📌 使用玩家位置", GUILayout.Width(100)))
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player == null) player = GameObject.Find("PlayerCharacter(Clone)");
                if (player != null)
                {
                    Vector3 pos = player.transform.position;
                    posX = pos.x.ToString("F2");
                    posY = pos.y.ToString("F2");
                    posZ = pos.z.ToString("F2");
                    statusMessage = "已填入玩家位置";
                }
            }
            if (GUILayout.Button("📌 使用摄像机位置", GUILayout.Width(100)))
            {
                Camera cam = Camera.main;
                if (cam != null)
                {
                    Vector3 pos = cam.transform.position;
                    posX = pos.x.ToString("F2");
                    posY = pos.y.ToString("F2");
                    posZ = pos.z.ToString("F2");
                    statusMessage = "已填入摄像机位置";
                }
            }
            if (GUILayout.Button("📌 使用选中对象", GUILayout.Width(100)))
            {
                GameObject obj = SuperConsole.selectedObject;
                if (obj != null)
                {
                    Vector3 pos = obj.transform.position;
                    posX = pos.x.ToString("F2");
                    posY = pos.y.ToString("F2");
                    posZ = pos.z.ToString("F2");
                    statusMessage = "已填入选中对象位置: " + obj.name;
                }
                else
                {
                    statusMessage = "❌ 没有选中的对象";
                }
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label($"📊 状态: {statusMessage}");

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("🚀 召唤", GUILayout.Height(30)))
            {
                if (targetLogic == null)
                {
                    statusMessage = "❌ 没有目标逻辑体";
                }
                else
                {
                    try
                    {
                        float x = float.Parse(posX);
                        float y = float.Parse(posY);
                        float z = float.Parse(posZ);
                        LogicSpawnerV2.SpawnAtCoordinates(targetLogic.id, new Vector3(x, y, z));
                        statusMessage = $"✅ 已召唤到 ({x:F2}, {y:F2}, {z:F2})";
                        visible = false;
                    }
                    catch (Exception ex)
                    {
                        statusMessage = $"❌ 坐标格式错误: {ex.Message}";
                    }
                }
            }
            if (GUILayout.Button("取消", GUILayout.Height(30)))
            {
                visible = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SuperConsole
{
    /// <summary>
    /// 提取选项窗口 — 让玩家选择提取哪些内容
    /// </summary>
    public static class LogicExtractorUI
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 480, 520);
        private static Vector2 scrollPos = Vector2.zero;
        private static GameObject targetObject = null;
        private static string targetName = "";
        private static string targetType = "";

        // ===== 提取选项 =====
        private static bool extractMesh = true;
        private static bool extractTextures = true;
        private static bool extractMaterials = true;
        private static bool extractAnimations = true;
        private static bool extractAudio = true;
        private static bool extractColliders = true;
        private static bool extractBones = true;
        private static bool extractChildren = true;
        private static bool extractComponents = false;
        private static bool extractScripts = false;

        public static Rect GetWindowRect() => windowRect;
        public static void ResetPosition() => windowRect = new Rect(100, 100, 480, 520);
        public static bool IsVisible() => visible;

        public static void Toggle(GameObject obj)
        {
            if (obj == null)
            {
                Debug.LogWarning("[LogicExtractorUI] 目标对象为空");
                return;
            }

            visible = !visible;
            if (visible)
            {
                targetObject = obj;
                targetName = obj.name;
                targetType = obj.GetType().Name;
                windowRect = new Rect(100, 100, 480, 520);
                scrollPos = Vector2.zero;
                extractChildren = obj.transform.childCount > 0;
            }
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12365);
            windowRect = GUI.Window(12365, windowRect, DrawWindow, "提取选项 — " + targetName);
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            if (windowRect.x + windowRect.width > Screen.width)
                windowRect.x = Screen.width - windowRect.width - 10;
            if (windowRect.y + windowRect.height > Screen.height)
                windowRect.y = Screen.height - windowRect.height - 10;

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.Label("正在提取: " + targetName, GUILayout.ExpandWidth(true));
            GUILayout.Label("类型: " + targetType, GUILayout.Width(150));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("选择要提取的内容:", GUILayout.ExpandWidth(true));
            GUILayout.Label("(取消勾选的内容将不会被提取)", GUILayout.ExpandWidth(true));

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(280));

            GUILayout.Label("资源", GUILayout.ExpandWidth(true));
            extractMesh = GUILayout.Toggle(extractMesh, " 模型 (Mesh) → .obj");
            extractTextures = GUILayout.Toggle(extractTextures, " 纹理 (Texture) → .png");
            extractMaterials = GUILayout.Toggle(extractMaterials, " 材质 (Material) → .mat");
            extractAnimations = GUILayout.Toggle(extractAnimations, " 动画 (Animation) → .anim");
            extractAudio = GUILayout.Toggle(extractAudio, " 音频 (Audio) → .wav");

            GUILayout.Space(5);
            GUILayout.Label("结构", GUILayout.ExpandWidth(true));
            extractColliders = GUILayout.Toggle(extractColliders, " 碰撞箱 (Collider)");
            extractBones = GUILayout.Toggle(extractBones, " 骨骼 (Bone)");
            extractChildren = GUILayout.Toggle(extractChildren, " 子对象 (Children)");

            GUILayout.Space(5);
            GUILayout.Label("组件/脚本 (可能不兼容)", GUILayout.ExpandWidth(true));
            extractComponents = GUILayout.Toggle(extractComponents, " 组件 (Component)");
            extractScripts = GUILayout.Toggle(extractScripts, " 脚本 (MonoBehaviour) — 可能报错");

            if (extractScripts)
            {
                GUILayout.Label("  脚本提取后可能无法在其他游戏使用");
                GUILayout.Label("  建议仅提取简单脚本或自己做兼容处理");
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            int count = 0;
            if (extractMesh) count++;
            if (extractTextures) count++;
            if (extractMaterials) count++;
            if (extractAnimations) count++;
            if (extractAudio) count++;
            if (extractColliders) count++;
            if (extractBones) count++;
            if (extractChildren) count++;
            if (extractComponents) count++;
            if (extractScripts) count++;
            GUILayout.Label("将提取 " + count + " 类内容");

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("提取", GUILayout.Height(30)))
            {
                DoExtract();
                visible = false;
            }
            if (GUILayout.Button("取消", GUILayout.Height(30)))
            {
                visible = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private static void DoExtract()
        {
            if (targetObject == null)
            {
                Debug.LogError("[LogicExtractorUI] 目标对象为空");
                return;
            }

            Debug.Log("[LogicExtractorUI] 开始提取: " + targetName);
            Debug.Log("  模型: " + extractMesh + ", 纹理: " + extractTextures + ", 材质: " + extractMaterials);
            Debug.Log("  动画: " + extractAnimations + ", 音频: " + extractAudio + ", 碰撞箱: " + extractColliders);
            Debug.Log("  骨骼: " + extractBones + ", 子对象: " + extractChildren + ", 组件: " + extractComponents + ", 脚本: " + extractScripts);

            // 创建提取选项对象（使用 LogicPrefabExtractor 中定义的 ExtractOptions）
            var options = new ExtractOptions
            {
                ExtractMesh = extractMesh,
                ExtractTextures = extractTextures,
                ExtractMaterials = extractMaterials,
                ExtractAnimations = extractAnimations,
                ExtractAudio = extractAudio,
                ExtractColliders = extractColliders,
                ExtractBones = extractBones,
                ExtractChildren = extractChildren,
                ExtractComponents = extractComponents,
                ExtractScripts = extractScripts
            };

            // 调用带选项的提取
            LogicPrefabExtractor.ExtractWithOptions(targetObject, targetObject.name, LogicType.Prefab, options);

            Debug.Log("[LogicExtractorUI] 提取完成: " + targetName);
        }
    }
}
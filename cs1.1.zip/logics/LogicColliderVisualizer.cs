﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SuperConsole
{
    // ============================================================
    // 碰撞箱可视化系统
    // 在场景中用线框显示碰撞箱，选中时高亮
    // ============================================================
    public static class LogicColliderVisualizer
    {
        // ===== 数据 =====
        private static Dictionary<Collider, GameObject> visualizers = new Dictionary<Collider, GameObject>();
        private static Collider selectedCollider = null;
        private static bool isVisible = false;
        private static Color defaultColor = new Color(0, 1, 0, 0.6f);  // 绿色半透明
        private static Color highlightColor = new Color(1, 1, 0, 0.8f); // 黄色半透明
        private static float lineWidth = 0.02f;

        // ============================================================
        // 为对象显示碰撞箱
        // ============================================================
        public static void ShowForObject(GameObject obj)
        {
            if (obj == null) return;

            HideAll();

            Collider[] colliders = obj.GetComponentsInChildren<Collider>(true);
            foreach (var collider in colliders)
            {
                if (collider == null) continue;
                CreateVisualizer(collider);
            }

            isVisible = true;
            Debug.Log($"[ColliderVisualizer] 🎯 显示 {colliders.Length} 个碰撞箱");
        }

        // ============================================================
        // 隐藏所有碰撞箱
        // ============================================================
        public static void HideAll()
        {
            foreach (var kv in visualizers)
            {
                if (kv.Value != null)
                    UnityEngine.Object.Destroy(kv.Value);
            }
            visualizers.Clear();
            selectedCollider = null;
            isVisible = false;
        }

        // ============================================================
        // 切换显示
        // ============================================================
        public static void Toggle(GameObject obj)
        {
            if (obj == null) return;

            // 如果已经在显示且是同一个对象，隐藏
            if (isVisible && visualizers.Count > 0)
            {
                // 检查是否还是同一个对象
                Collider first = null;
                foreach (var kv in visualizers)
                {
                    first = kv.Key;
                    break;
                }
                if (first != null && first.gameObject == obj)
                {
                    HideAll();
                    return;
                }
            }

            ShowForObject(obj);
        }

        // ============================================================
        // 高亮碰撞箱
        // ============================================================
        public static void Highlight(Collider collider)
        {
            if (collider == null) return;

            selectedCollider = collider;
            UpdateColors();
        }

        // ============================================================
        // 清除高亮
        // ============================================================
        public static void ClearHighlight()
        {
            selectedCollider = null;
            UpdateColors();
        }

        // ============================================================
        // 创建碰撞箱可视化
        // ============================================================
        private static void CreateVisualizer(Collider collider)
        {
            if (collider == null || visualizers.ContainsKey(collider)) return;

            GameObject visual = new GameObject("ColliderVisual_" + collider.name);
            visual.transform.SetParent(collider.transform, false);

            // 根据碰撞箱类型创建对应的线框
            LineRenderer lr = visual.AddComponent<LineRenderer>();
            lr.material = new Material(Shader.Find("Sprites/Default"));
            lr.startWidth = lineWidth;
            lr.endWidth = lineWidth;
            lr.useWorldSpace = true;
            lr.loop = true;

            Vector3[] points = GetColliderPoints(collider);
            if (points != null && points.Length > 0)
            {
                lr.positionCount = points.Length;
                lr.SetPositions(points);
                lr.startColor = defaultColor;
                lr.endColor = defaultColor;
            }

            visualizers[collider] = visual;
        }

        // ============================================================
        // 获取碰撞箱的顶点
        // ============================================================
        private static Vector3[] GetColliderPoints(Collider collider)
        {
            if (collider is BoxCollider box)
                return GetBoxPoints(box);
            else if (collider is SphereCollider sphere)
                return GetSpherePoints(sphere);
            else if (collider is CapsuleCollider capsule)
                return GetCapsulePoints(capsule);
            else if (collider is MeshCollider mesh)
                return GetMeshPoints(mesh);
            else if (collider is CharacterController cc)
                return GetCharacterControllerPoints(cc);
            else
                return GetDefaultPoints(collider);
        }

        // ============================================================
        // 盒子碰撞箱顶点
        // ============================================================
        private static Vector3[] GetBoxPoints(BoxCollider box)
        {
            Vector3 center = box.center;
            Vector3 size = box.size / 2;
            Vector3 pos = box.transform.position;
            Quaternion rot = box.transform.rotation;

            Vector3[] corners = new Vector3[]
            {
                new Vector3(-size.x, -size.y, -size.z),
                new Vector3( size.x, -size.y, -size.z),
                new Vector3( size.x,  size.y, -size.z),
                new Vector3(-size.x,  size.y, -size.z),
                new Vector3(-size.x, -size.y,  size.z),
                new Vector3( size.x, -size.y,  size.z),
                new Vector3( size.x,  size.y,  size.z),
                new Vector3(-size.x,  size.y,  size.z)
            };

            // 应用位置 + 旋转
            for (int i = 0; i < corners.Length; i++)
            {
                corners[i] = pos + rot * (center + corners[i]);
            }

            // 返回线框路径（12条边）
            return new Vector3[]
            {
                corners[0], corners[1], corners[2], corners[3], corners[0],
                corners[4], corners[5], corners[6], corners[7], corners[4],
                corners[0], corners[4],
                corners[1], corners[5],
                corners[2], corners[6],
                corners[3], corners[7]
            };
        }

        // ============================================================
        // 球体碰撞箱顶点
        // ============================================================
        private static Vector3[] GetSpherePoints(SphereCollider sphere)
        {
            Vector3 center = sphere.center;
            float radius = sphere.radius;
            Vector3 pos = sphere.transform.position;
            Quaternion rot = sphere.transform.rotation;

            int segments = 24;
            System.Collections.Generic.List<Vector3> points = new System.Collections.Generic.List<Vector3>();

            // 水平圆环
            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * 2 * Mathf.PI;
                float x = Mathf.Cos(angle) * radius;
                float z = Mathf.Sin(angle) * radius;
                points.Add(pos + rot * (center + new Vector3(x, 0, z)));
            }

            // 垂直圆环
            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * 2 * Mathf.PI;
                float x = Mathf.Cos(angle) * radius;
                float y = Mathf.Sin(angle) * radius;
                points.Add(pos + rot * (center + new Vector3(x, y, 0)));
            }

            // 另一个垂直圆环
            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * 2 * Mathf.PI;
                float y = Mathf.Cos(angle) * radius;
                float z = Mathf.Sin(angle) * radius;
                points.Add(pos + rot * (center + new Vector3(0, y, z)));
            }

            return points.ToArray();
        }

        // ============================================================
        // 胶囊体碰撞箱顶点
        // ============================================================
        private static Vector3[] GetCapsulePoints(CapsuleCollider capsule)
        {
            Vector3 center = capsule.center;
            float radius = capsule.radius;
            float height = capsule.height;
            int direction = capsule.direction; // 0=X, 1=Y, 2=Z
            Vector3 pos = capsule.transform.position;
            Quaternion rot = capsule.transform.rotation;

            System.Collections.Generic.List<Vector3> points = new System.Collections.Generic.List<Vector3>();
            int segments = 20;

            // 简化：用球体 + 圆柱组合
            float halfHeight = Mathf.Max(0, height / 2 - radius);

            Vector3 axis = Vector3.up;
            if (direction == 0) axis = Vector3.right;
            else if (direction == 2) axis = Vector3.forward;

            // 上下两个半球
            Vector3 topCenter = center + axis * halfHeight;
            Vector3 bottomCenter = center - axis * halfHeight;

            // 顶部半球
            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * 2 * Mathf.PI;
                float x = Mathf.Cos(angle) * radius;
                float z = Mathf.Sin(angle) * radius;
                // 顶部
                points.Add(pos + rot * (topCenter + new Vector3(x, 0, z)));
                // 底部
                points.Add(pos + rot * (bottomCenter + new Vector3(x, 0, z)));
                // 中间圆柱
                points.Add(pos + rot * (topCenter + new Vector3(x, 0, z)));
                points.Add(pos + rot * (bottomCenter + new Vector3(x, 0, z)));
            }

            return points.ToArray();
        }

        // ============================================================
        // Mesh 碰撞箱顶点
        // ============================================================
        private static Vector3[] GetMeshPoints(MeshCollider meshCollider)
        {
            Mesh mesh = meshCollider.sharedMesh;
            if (mesh == null) return GetDefaultPoints(meshCollider);

            Vector3 pos = meshCollider.transform.position;
            Quaternion rot = meshCollider.transform.rotation;

            Vector3[] verts = mesh.vertices;
            if (verts.Length == 0) return GetDefaultPoints(meshCollider);

            // 取顶点 + 中心
            Vector3 center = Vector3.zero;
            foreach (var v in verts) center += v;
            center /= verts.Length;

            System.Collections.Generic.List<Vector3> points = new System.Collections.Generic.List<Vector3>();

            // 添加所有顶点（简化：画一个包围盒）
            Vector3 min = verts[0];
            Vector3 max = verts[0];
            foreach (var v in verts)
            {
                min = Vector3.Min(min, v);
                max = Vector3.Max(max, v);
            }

            Vector3 size = (max - min) / 2;
            center = (max + min) / 2;

            Vector3[] corners = new Vector3[]
            {
                new Vector3(-size.x, -size.y, -size.z),
                new Vector3( size.x, -size.y, -size.z),
                new Vector3( size.x,  size.y, -size.z),
                new Vector3(-size.x,  size.y, -size.z),
                new Vector3(-size.x, -size.y,  size.z),
                new Vector3( size.x, -size.y,  size.z),
                new Vector3( size.x,  size.y,  size.z),
                new Vector3(-size.x,  size.y,  size.z)
            };

            for (int i = 0; i < corners.Length; i++)
            {
                corners[i] = pos + rot * (center + corners[i]);
            }

            return new Vector3[]
            {
                corners[0], corners[1], corners[2], corners[3], corners[0],
                corners[4], corners[5], corners[6], corners[7], corners[4],
                corners[0], corners[4],
                corners[1], corners[5],
                corners[2], corners[6],
                corners[3], corners[7]
            };
        }

        // ============================================================
        // CharacterController 顶点
        // ============================================================
        private static Vector3[] GetCharacterControllerPoints(CharacterController cc)
        {
            Vector3 center = cc.center;
            float radius = cc.radius;
            float height = cc.height;
            Vector3 pos = cc.transform.position;
            Quaternion rot = cc.transform.rotation;

            // 用胶囊体近似
            float halfHeight = Mathf.Max(0, height / 2 - radius);
            Vector3 topCenter = center + Vector3.up * halfHeight;
            Vector3 bottomCenter = center - Vector3.up * halfHeight;

            System.Collections.Generic.List<Vector3> points = new System.Collections.Generic.List<Vector3>();
            int segments = 20;

            for (int i = 0; i <= segments; i++)
            {
                float angle = (float)i / segments * 2 * Mathf.PI;
                float x = Mathf.Cos(angle) * radius;
                float z = Mathf.Sin(angle) * radius;
                points.Add(pos + rot * (topCenter + new Vector3(x, 0, z)));
                points.Add(pos + rot * (bottomCenter + new Vector3(x, 0, z)));
            }

            return points.ToArray();
        }

        // ============================================================
        // 默认碰撞箱顶点
        // ============================================================
        private static Vector3[] GetDefaultPoints(Collider collider)
        {
            Vector3 pos = collider.transform.position;
            Vector3 center = Vector3.zero;
            Vector3 size = Vector3.one * 0.5f;

            if (collider is Collider c)
            {
                center = Vector3.zero;
                // 估算大小
                Bounds bounds = c.bounds;
                size = bounds.extents;
                if (size.magnitude < 0.01f) size = Vector3.one * 0.5f;
            }

            Vector3[] corners = new Vector3[]
            {
                new Vector3(-size.x, -size.y, -size.z) + center + pos,
                new Vector3( size.x, -size.y, -size.z) + center + pos,
                new Vector3( size.x,  size.y, -size.z) + center + pos,
                new Vector3(-size.x,  size.y, -size.z) + center + pos,
                new Vector3(-size.x, -size.y,  size.z) + center + pos,
                new Vector3( size.x, -size.y,  size.z) + center + pos,
                new Vector3( size.x,  size.y,  size.z) + center + pos,
                new Vector3(-size.x,  size.y,  size.z) + center + pos
            };

            return new Vector3[]
            {
                corners[0], corners[1], corners[2], corners[3], corners[0],
                corners[4], corners[5], corners[6], corners[7], corners[4],
                corners[0], corners[4],
                corners[1], corners[5],
                corners[2], corners[6],
                corners[3], corners[7]
            };
        }

        // ============================================================
        // 更新颜色
        // ============================================================
        private static void UpdateColors()
        {
            foreach (var kv in visualizers)
            {
                if (kv.Value == null) continue;
                LineRenderer lr = kv.Value.GetComponent<LineRenderer>();
                if (lr == null) continue;

                bool isSelected = (kv.Key == selectedCollider);
                Color color = isSelected ? highlightColor : defaultColor;
                lr.startColor = color;
                lr.endColor = color;
            }
        }

        // ============================================================
        // 更新所有碰撞箱（当对象移动时）
        // ============================================================
        public static void UpdateAll()
        {
            foreach (var kv in visualizers)
            {
                if (kv.Key == null || kv.Value == null) continue;

                LineRenderer lr = kv.Value.GetComponent<LineRenderer>();
                if (lr == null) continue;

                Vector3[] points = GetColliderPoints(kv.Key);
                if (points != null && points.Length > 0)
                {
                    lr.positionCount = points.Length;
                    lr.SetPositions(points);
                }
            }
        }

        // ============================================================
        // 获取状态
        // ============================================================
        public static bool IsVisible() => isVisible;
        public static int GetCount() => visualizers.Count;
        public static Collider GetSelected() => selectedCollider;
    }
}
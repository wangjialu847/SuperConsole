﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using UnityEngine;
using BepInEx;
using System.IO.Compression;

namespace SuperConsole
{
    public static class LogicManagerV2
    {
        private static string logicsPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Logics");
        private static Dictionary<string, LogicEntityV2> logics = new Dictionary<string, LogicEntityV2>();
        private static bool isInitialized = false;

        public static void Initialize()
        {
            if (isInitialized) return;
            EnsureDirectory();
            ScanAll();
            isInitialized = true;
            Debug.Log($"[LogicManagerV2] ✅ 初始化完成，找到 {logics.Count} 个逻辑体");
        }

        private static void EnsureDirectory()
        {
            if (!Directory.Exists(logicsPath))
            {
                Directory.CreateDirectory(logicsPath);
                Debug.Log($"[LogicManagerV2] 📁 创建目录: {logicsPath}");
            }
        }

        public static void ScanAll()
        {
            if (!Directory.Exists(logicsPath)) return;
            logics.Clear();

            // ---- 1. 先处理 .mod 文件（解压） ----
            string[] modFiles = Directory.GetFiles(logicsPath, "*.mod", SearchOption.TopDirectoryOnly);
            foreach (string modFile in modFiles)
            {
                try
                {
                    string folderName = Path.GetFileNameWithoutExtension(modFile);
                    string extractPath = Path.Combine(logicsPath, folderName);

                    // 如果已经存在同名文件夹，跳过（避免覆盖用户修改）
                    if (Directory.Exists(extractPath))
                    {
                        Debug.Log($"[LogicManagerV2] ⏭️ 跳过已存在的逻辑体: {folderName}");
                        continue;
                    }

                    Debug.Log($"[LogicManagerV2] 📦 解压 .mod 文件: {Path.GetFileName(modFile)}");
                    ZipFile.ExtractToDirectory(modFile, extractPath);
                    Debug.Log($"[LogicManagerV2] ✅ 解压完成: {extractPath}");
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[LogicManagerV2] ❌ 解压 .mod 失败: {modFile} - {ex.Message}");
                }
            }

            // ---- 2. 扫描所有逻辑体文件夹 ----
            string[] directories = Directory.GetDirectories(logicsPath);
            foreach (string dir in directories)
            {
                string modJsonPath = Path.Combine(dir, "mod.json");
                if (File.Exists(modJsonPath))
                {
                    try
                    {
                        LogicEntityV2 logic = LoadFromFile(modJsonPath);
                        if (logic != null)
                        {
                            logic.FolderPath = dir;
                            logics[logic.id] = logic;
                            Debug.Log($"[LogicManagerV2] ✅ 加载逻辑体: {logic.GetDisplayName()} ({logic.id})");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError($"[LogicManagerV2] ❌ 加载失败: {modJsonPath} - {ex.Message}");
                    }
                }
            }
            Debug.Log($"[LogicManagerV2] 📊 扫描完成，共 {logics.Count} 个逻辑体");
        }

        // ============================================================
        // 导出逻辑体为 .mod 文件
        // ============================================================
        public static void ExportToMod(string id, string outputPath = null)
        {
            if (!logics.ContainsKey(id))
            {
                Debug.LogError($"[LogicManagerV2] ❌ 找不到逻辑体: {id}");
                return;
            }

            var logic = logics[id];
            if (string.IsNullOrEmpty(logic.FolderPath) || !Directory.Exists(logic.FolderPath))
            {
                Debug.LogError($"[LogicManagerV2] ❌ 逻辑体文件夹不存在: {logic.FolderPath}");
                return;
            }

            if (string.IsNullOrEmpty(outputPath))
            {
                outputPath = Path.Combine(logicsPath, logic.name + ".mod");
            }

            try
            {
                // 确保输出目录存在
                string outputDir = Path.GetDirectoryName(outputPath);
                if (!Directory.Exists(outputDir))
                    Directory.CreateDirectory(outputDir);

                // 如果文件已存在，先删除
                if (File.Exists(outputPath))
                    File.Delete(outputPath);

                // 压缩文件夹
                ZipFile.CreateFromDirectory(logic.FolderPath, outputPath);
                Debug.Log($"[LogicManagerV2] 📦 导出 .mod 成功: {outputPath}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicManagerV2] ❌ 导出 .mod 失败: {ex.Message}");
            }
        }

        // ============================================================
        // 导入 .mod 文件
        // ============================================================
        public static void ImportMod(string modFilePath)
        {
            if (!File.Exists(modFilePath))
            {
                Debug.LogError($"[LogicManagerV2] ❌ .mod 文件不存在: {modFilePath}");
                return;
            }

            try
            {
                string folderName = Path.GetFileNameWithoutExtension(modFilePath);
                string extractPath = Path.Combine(logicsPath, folderName);

                // 如果已存在，询问是否覆盖
                if (Directory.Exists(extractPath))
                {
                    Debug.LogWarning($"[LogicManagerV2] ⚠️ 逻辑体已存在: {folderName}，跳过导入");
                    return;
                }

                ZipFile.ExtractToDirectory(modFilePath, extractPath);
                Debug.Log($"[LogicManagerV2] ✅ 导入 .mod 成功: {modFilePath} -> {extractPath}");

                // 刷新
                ScanAll();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicManagerV2] ❌ 导入 .mod 失败: {ex.Message}");
            }
        }

        // ============================================================
        // 原有方法保持不变
        // ============================================================

        public static LogicEntityV2 LoadFromFile(string path)
        {
            if (!File.Exists(path)) return null;
            string json = File.ReadAllText(path);
            var logic = new LogicEntityV2();

            try
            {
                logic.id = ExtractJsonString(json, "id");
                logic.name = ExtractJsonString(json, "name");
                logic.version = ExtractJsonString(json, "version");
                logic.author = ExtractJsonString(json, "author");
                logic.description = ExtractJsonString(json, "description");
                logic.created = ExtractJsonString(json, "created");
                logic.modified = ExtractJsonString(json, "modified");
                logic.enabled = ExtractJsonBool(json, "enabled");

                string typeStr = ExtractJsonString(json, "type");
                if (!string.IsNullOrEmpty(typeStr))
                {
                    try { logic.type = (LogicType)Enum.Parse(typeof(LogicType), typeStr); }
                    catch { logic.type = LogicType.Prefab; }
                }

                logic.resources = new LogicResources();
                string resJson = ExtractJsonObject(json, "resources");
                if (!string.IsNullOrEmpty(resJson))
                {
                    logic.resources.Prefab = ExtractJsonString(resJson, "Prefab");
                    logic.resources.Model = ExtractJsonString(resJson, "Model");
                    logic.resources.Textures = ExtractJsonArray(resJson, "Textures");
                    logic.resources.Audio = ExtractJsonArray(resJson, "Audio");
                    logic.resources.Materials = ExtractJsonArray(resJson, "Materials");
                    logic.resources.Animations = ExtractJsonArray(resJson, "Animations");
                    logic.resources.Scripts = ExtractJsonArray(resJson, "Scripts");
                    logic.resources.Colliders = ExtractJsonString(resJson, "Colliders");
                    logic.resources.Scene = ExtractJsonString(resJson, "Scene");
                    logic.resources.Map = ExtractJsonString(resJson, "Map");
                    logic.resources.Rules = ExtractJsonString(resJson, "Rules");
                    logic.resources.GameMode = ExtractJsonString(resJson, "GameMode");
                    logic.resources.DLL = ExtractJsonString(resJson, "DLL");
                }

                logic.dependencies = ExtractJsonArray(json, "dependencies");
                logic.tags = ExtractJsonArray(json, "tags");

                if (string.IsNullOrEmpty(logic.id))
                {
                    Debug.LogWarning($"[LogicManagerV2] ⚠️ mod.json 无效 (缺少 id): {path}");
                    return null;
                }
                return logic;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicManagerV2] ❌ 解析失败: {path} - {ex.Message}");
                return null;
            }
        }

        public static void SaveToFile(LogicEntityV2 logic)
        {
            if (logic == null || string.IsNullOrEmpty(logic.id)) return;

            string safeName = GetSafeFileName(logic.name);
            string folderPath = Path.Combine(logicsPath, safeName);
            if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);

            logic.Touch();

            string json = "{\n";
            json += $"  \"id\": \"{EscapeJson(logic.id)}\",\n";
            json += $"  \"name\": \"{EscapeJson(logic.name)}\",\n";
            json += $"  \"version\": \"{EscapeJson(logic.version)}\",\n";
            json += $"  \"author\": \"{EscapeJson(logic.author)}\",\n";
            json += $"  \"description\": \"{EscapeJson(logic.description)}\",\n";
            json += $"  \"created\": \"{logic.created}\",\n";
            json += $"  \"modified\": \"{logic.modified}\",\n";
            json += $"  \"type\": \"{logic.type}\",\n";
            json += $"  \"enabled\": {logic.enabled.ToString().ToLower()},\n";

            json += "  \"resources\": {\n";
            json += $"    \"Prefab\": \"{EscapeJson(logic.resources.Prefab)}\",\n";
            json += $"    \"Model\": \"{EscapeJson(logic.resources.Model)}\",\n";
            json += $"    \"Textures\": {ArrayToJson(logic.resources.Textures)},\n";
            json += $"    \"Audio\": {ArrayToJson(logic.resources.Audio)},\n";
            json += $"    \"Materials\": {ArrayToJson(logic.resources.Materials)},\n";
            json += $"    \"Animations\": {ArrayToJson(logic.resources.Animations)},\n";
            json += $"    \"Scripts\": {ArrayToJson(logic.resources.Scripts)},\n";
            json += $"    \"Colliders\": \"{EscapeJson(logic.resources.Colliders)}\",\n";
            json += $"    \"Scene\": \"{EscapeJson(logic.resources.Scene)}\",\n";
            json += $"    \"Map\": \"{EscapeJson(logic.resources.Map)}\",\n";
            json += $"    \"Rules\": \"{EscapeJson(logic.resources.Rules)}\",\n";
            json += $"    \"GameMode\": \"{EscapeJson(logic.resources.GameMode)}\",\n";
            json += $"    \"DLL\": \"{EscapeJson(logic.resources.DLL)}\"\n";
            json += "  },\n";

            json += $"  \"dependencies\": {ArrayToJson(logic.dependencies)},\n";
            json += $"  \"tags\": {ArrayToJson(logic.tags)}\n";
            json += "}";

            string filePath = Path.Combine(folderPath, "mod.json");
            File.WriteAllText(filePath, json);

            if (logics.ContainsKey(logic.id)) logics[logic.id] = logic;
            else logics[logic.id] = logic;

            logic.FolderPath = folderPath;
            Debug.Log($"[LogicManagerV2] 💾 保存逻辑体: {logic.GetDisplayName()} -> {folderPath}");
        }

        public static LogicEntityV2 Create(string name, LogicType type = LogicType.Prefab)
        {
            var logic = new LogicEntityV2
            {
                name = name,
                type = type,
                author = Environment.UserName,
                created = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss"),
                modified = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss")
            };
            SaveToFile(logic);
            return logic;
        }

        public static void Delete(string id)
        {
            if (!logics.ContainsKey(id)) return;
            var logic = logics[id];
            if (!string.IsNullOrEmpty(logic.FolderPath) && Directory.Exists(logic.FolderPath))
            {
                Directory.Delete(logic.FolderPath, true);
                Debug.Log($"[LogicManagerV2] 🗑️ 删除逻辑体: {logic.GetDisplayName()}");
            }
            logics.Remove(id);
        }

        public static LogicEntityV2 Get(string id) => logics.ContainsKey(id) ? logics[id] : null;
        public static LogicEntityV2 GetByName(string name) => logics.Values.FirstOrDefault(l => l.name == name);
        public static List<LogicEntityV2> GetAll() => new List<LogicEntityV2>(logics.Values);
        public static List<LogicEntityV2> GetByType(LogicType type) => logics.Values.Where(l => l.type == type).ToList();

        public static void Refresh() => ScanAll();
        public static string GetStatus() => $"[LogicManagerV2] 📊 共 {logics.Count} 个逻辑体";

        private static string GetSafeFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "unnamed";
            foreach (char c in Path.GetInvalidFileNameChars()) name = name.Replace(c, '_');
            return name;
        }

        // ===== JSON 辅助（保持不变） =====
        private static string EscapeJson(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\\", "\\\\").Replace("\"", "\\\"")
                       .Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");
        }

        private static string ArrayToJson(List<string> list)
        {
            if (list == null || list.Count == 0) return "[]";
            string result = "[";
            for (int i = 0; i < list.Count; i++)
            {
                result += "\"" + EscapeJson(list[i]) + "\"";
                if (i < list.Count - 1) result += ", ";
            }
            result += "]";
            return result;
        }

        private static string ExtractJsonString(string json, string key)
        {
            string search = $"\"{key}\":";
            int start = json.IndexOf(search);
            if (start < 0) return "";
            int pos = start + search.Length;
            while (pos < json.Length && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n' || json[pos] == '\r')) pos++;
            if (pos >= json.Length) return "";
            if (json[pos] == 'n' && json.Substring(pos, 4) == "null") return "";
            if (json[pos] != '"')
            {
                int end = pos;
                while (end < json.Length && json[end] != ',' && json[end] != '}' && json[end] != ']' && json[end] != '\n') end++;
                return json.Substring(pos, end - pos).Trim();
            }
            int strStart = pos + 1;
            int strEnd = json.IndexOf('"', strStart);
            if (strEnd < 0) return "";
            return json.Substring(strStart, strEnd - strStart);
        }

        private static bool ExtractJsonBool(string json, string key) => ExtractJsonString(json, key).ToLower() == "true";

        private static string ExtractJsonObject(string json, string key)
        {
            string search = $"\"{key}\":";
            int start = json.IndexOf(search);
            if (start < 0) return "";
            int pos = start + search.Length;
            while (pos < json.Length && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n' || json[pos] == '\r')) pos++;
            if (pos >= json.Length || json[pos] != '{') return "";
            int braceCount = 0;
            for (int i = pos; i < json.Length; i++)
            {
                if (json[i] == '{') braceCount++;
                else if (json[i] == '}') braceCount--;
                if (braceCount == 0) return json.Substring(pos, i - pos + 1);
            }
            return "";
        }

        private static List<string> ExtractJsonArray(string json, string key)
        {
            var result = new List<string>();
            string search = $"\"{key}\":";
            int start = json.IndexOf(search);
            if (start < 0) return result;
            int pos = start + search.Length;
            while (pos < json.Length && (json[pos] == ' ' || json[pos] == '\t' || json[pos] == '\n' || json[pos] == '\r')) pos++;
            if (pos >= json.Length || json[pos] != '[') return result;

            int bracketCount = 0;
            int arrayStart = pos;
            int arrayEnd = -1;
            for (int i = pos; i < json.Length; i++)
            {
                if (json[i] == '[') bracketCount++;
                else if (json[i] == ']') bracketCount--;
                if (bracketCount == 0) { arrayEnd = i; break; }
            }
            if (arrayEnd < 0) return result;

            string content = json.Substring(arrayStart + 1, arrayEnd - arrayStart - 1);
            int idx = 0;
            while (idx < content.Length)
            {
                while (idx < content.Length && (content[idx] == ' ' || content[idx] == '\t' || content[idx] == '\n' || content[idx] == '\r' || content[idx] == ',')) idx++;
                if (idx >= content.Length) break;
                if (content[idx] == '"')
                {
                    int strEnd = content.IndexOf('"', idx + 1);
                    if (strEnd < 0) break;
                    result.Add(content.Substring(idx + 1, strEnd - idx - 1));
                    idx = strEnd + 1;
                }
                else
                {
                    int valEnd = idx;
                    while (valEnd < content.Length && content[valEnd] != ',' && content[valEnd] != ']' && content[valEnd] != ' ' && content[valEnd] != '\t') valEnd++;
                    string val = content.Substring(idx, valEnd - idx).Trim();
                    if (!string.IsNullOrEmpty(val) && val != "null") result.Add(val);
                    idx = valEnd;
                }
            }
            return result;
        }
    }
}
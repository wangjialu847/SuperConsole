﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using BepInEx;

namespace SuperConsole
{
    /// <summary>
    /// 逻辑体资源浏览器 - 玩家可浏览并导入资源
    /// </summary>
    public static class LogicResourceBrowser
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(0, 0, Screen.width, Screen.height);
        private static Vector2 scrollPos = Vector2.zero;
        private static Vector2 fileScrollPos = Vector2.zero;

        // ===== 当前状态 =====
        private static string currentPath = "";
        private static string selectedPath = "";
        private static List<FileEntry> currentFiles = new List<FileEntry>();
        private static List<string> currentDirectories = new List<string>();
        private static LogicEntityV2 targetLogic = null;
        private static string targetResourceType = ""; // model, texture, audio, etc.

        // ===== 文件条目 =====
        public class FileEntry
        {
            public string Name;
            public string FullPath;
            public string Extension;
            public bool IsDirectory;
            public long Size;
            public DateTime ModifiedTime;
        }

        // ===== 支持的文件类型 =====
        private static Dictionary<string, string> fileTypeMap = new Dictionary<string, string>
        {
            { ".obj", "模型" },
            { ".fbx", "模型" },
            { ".dae", "模型" },
            { ".gltf", "模型" },
            { ".glb", "模型" },
            { ".stl", "模型" },
            { ".ply", "模型" },
            { ".png", "纹理" },
            { ".jpg", "纹理" },
            { ".jpeg", "纹理" },
            { ".tga", "纹理" },
            { ".dds", "纹理" },
            { ".bmp", "纹理" },
            { ".wav", "音频" },
            { ".mp3", "音频" },
            { ".ogg", "音频" },
            { ".flac", "音频" },
            { ".mat", "材质" },
            { ".anim", "动画" },
            { ".prefab", "预制体" },
            { ".dll", "DLL" },
            { ".cs", "脚本" },
        };

        public static bool IsVisible() => visible;
        public static Rect GetWindowRect() => windowRect;
        public static void ResetPosition() => windowRect = new Rect(0, 0, Screen.width, Screen.height);

        public static void Toggle(LogicEntityV2 logic = null, string resourceType = "")
        {
            visible = !visible;
            if (visible)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
                targetLogic = logic;
                targetResourceType = resourceType;

                // 从默认路径开始
                string basePath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
                if (!Directory.Exists(basePath))
                    Directory.CreateDirectory(basePath);
                currentPath = basePath;
                RefreshCurrentDirectory();
            }
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12364);
            windowRect = GUI.Window(12364, windowRect, DrawWindow, "📂 资源浏览器 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            // 全屏
            if (windowRect.width < Screen.width * 0.8f || windowRect.height < Screen.height * 0.8f)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
            }

            GUILayout.BeginVertical();

            // ===== 标题栏 =====
            DrawTitleBar();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 路径导航 =====
            DrawPathNavigation();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 文件列表 =====
            DrawFileList();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 底部操作栏 =====
            DrawBottomBar();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        // ============================================================
        // 标题栏
        // ============================================================
        private static void DrawTitleBar()
        {
            GUILayout.BeginHorizontal();

            string title = "📂 资源浏览器";
            if (!string.IsNullOrEmpty(targetResourceType))
                title += $" - 选择 {targetResourceType}";
            if (targetLogic != null)
                title += $" → {targetLogic.GetDisplayName()}";

            GUILayout.Label(title, GUILayout.ExpandWidth(true));

            if (GUILayout.Button("📂 打开资源目录", GUILayout.Width(120)))
            {
                string basePath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
                if (!Directory.Exists(basePath))
                    Directory.CreateDirectory(basePath);
                System.Diagnostics.Process.Start("explorer.exe", basePath);
            }

            if (GUILayout.Button("✖", GUILayout.Width(25))) visible = false;
            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 路径导航
        // ============================================================
        private static void DrawPathNavigation()
        {
            GUILayout.BeginHorizontal();

            // 后退
            if (GUILayout.Button("◀", GUILayout.Width(30)))
            {
                GoUpDirectory();
            }

            // 根目录按钮
            string basePath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
            if (GUILayout.Button("📁 Assets", GUILayout.Width(80)))
            {
                currentPath = basePath;
                RefreshCurrentDirectory();
            }

            // 快捷分类
            if (GUILayout.Button("📦 模型", GUILayout.Width(60)))
            {
                currentPath = Path.Combine(basePath, "Models");
                if (!Directory.Exists(currentPath)) Directory.CreateDirectory(currentPath);
                RefreshCurrentDirectory();
            }
            if (GUILayout.Button("🖼️ 纹理", GUILayout.Width(60)))
            {
                currentPath = Path.Combine(basePath, "Textures");
                if (!Directory.Exists(currentPath)) Directory.CreateDirectory(currentPath);
                RefreshCurrentDirectory();
            }
            if (GUILayout.Button("🔊 音频", GUILayout.Width(60)))
            {
                currentPath = Path.Combine(basePath, "Audio");
                if (!Directory.Exists(currentPath)) Directory.CreateDirectory(currentPath);
                RefreshCurrentDirectory();
            }
            if (GUILayout.Button("🧪 材质", GUILayout.Width(60)))
            {
                currentPath = Path.Combine(basePath, "Materials");
                if (!Directory.Exists(currentPath)) Directory.CreateDirectory(currentPath);
                RefreshCurrentDirectory();
            }
            if (GUILayout.Button("🎬 动画", GUILayout.Width(60)))
            {
                currentPath = Path.Combine(basePath, "Animations");
                if (!Directory.Exists(currentPath)) Directory.CreateDirectory(currentPath);
                RefreshCurrentDirectory();
            }
            if (GUILayout.Button("📦 预制体", GUILayout.Width(60)))
            {
                currentPath = Path.Combine(basePath, "Prefabs");
                if (!Directory.Exists(currentPath)) Directory.CreateDirectory(currentPath);
                RefreshCurrentDirectory();
            }

            GUILayout.FlexibleSpace();

            // 当前路径显示
            string displayPath = currentPath;
            if (displayPath.Length > 50) displayPath = "..." + displayPath.Substring(displayPath.Length - 47);
            GUILayout.Label($"📍 {displayPath}", GUILayout.Width(300));

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 文件列表
        // ============================================================
        private static void DrawFileList()
        {
            fileScrollPos = GUILayout.BeginScrollView(fileScrollPos, GUILayout.ExpandHeight(true));

            if (currentFiles.Count == 0 && currentDirectories.Count == 0)
            {
                GUILayout.Label("📂 此目录为空");
                GUILayout.Label("💡 将文件放到 SuperConsole/Assets/ 相应文件夹");
                GUILayout.Label("   或点击上方分类按钮快速跳转");
                GUILayout.EndScrollView();
                return;
            }

            // 列头
            GUILayout.BeginHorizontal("box");
            GUILayout.Label("名称", GUILayout.Width(200));
            GUILayout.Label("类型", GUILayout.Width(80));
            GUILayout.Label("大小", GUILayout.Width(80));
            GUILayout.Label("修改时间", GUILayout.Width(150));
            GUILayout.Label("操作", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            // 目录列表
            foreach (string dir in currentDirectories)
            {
                string dirName = Path.GetFileName(dir);
                GUILayout.BeginHorizontal("box");

                GUILayout.Label("📁 " + dirName, GUILayout.Width(200));
                GUILayout.Label("目录", GUILayout.Width(80));
                GUILayout.Label("", GUILayout.Width(80));
                GUILayout.Label("", GUILayout.Width(150));

                if (GUILayout.Button("📂 进入", GUILayout.Width(60)))
                {
                    currentPath = dir;
                    RefreshCurrentDirectory();
                }
                GUILayout.EndHorizontal();
            }

            // 文件列表
            foreach (var file in currentFiles)
            {
                GUILayout.BeginHorizontal("box");

                // 文件名 + 图标
                string icon = GetFileIcon(file.Extension);
                GUILayout.Label($"{icon} {file.Name}", GUILayout.Width(200));

                // 文件类型
                string fileType = GetFileType(file.Extension);
                GUILayout.Label(fileType, GUILayout.Width(80));

                // 文件大小
                string sizeStr = FormatFileSize(file.Size);
                GUILayout.Label(sizeStr, GUILayout.Width(80));

                // 修改时间
                GUILayout.Label(file.ModifiedTime.ToString("yyyy-MM-dd HH:mm"), GUILayout.Width(150));

                // 操作按钮
                bool isSupported = fileTypeMap.ContainsKey(file.Extension.ToLower());
                if (isSupported)
                {
                    // 导入按钮
                    if (GUILayout.Button($"📥 导入 {fileType}", GUILayout.Width(100)))
                    {
                        ImportFile(file);
                    }

                    // 预览按钮（如果是图片或音频）
                    if (IsPreviewable(file.Extension))
                    {
                        if (GUILayout.Button("👁️ 预览", GUILayout.Width(50)))
                        {
                            PreviewFile(file);
                        }
                    }
                }
                else
                {
                    GUILayout.Label("❌ 不支持的格式", GUILayout.Width(160));
                }

                GUILayout.EndHorizontal();
            }

            GUILayout.EndScrollView();
        }

        // ============================================================
        // 底部操作栏
        // ============================================================
        private static void DrawBottomBar()
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label($"共 {currentFiles.Count} 个文件，{currentDirectories.Count} 个目录", GUILayout.ExpandWidth(true));

            // 选择的逻辑体
            if (targetLogic != null)
            {
                GUILayout.Label($"目标: {targetLogic.GetDisplayName()}", GUILayout.Width(200));
            }

            // 选中的资源类型
            if (!string.IsNullOrEmpty(targetResourceType))
            {
                GUILayout.Label($"筛选: {targetResourceType}", GUILayout.Width(120));
            }

            // 刷新按钮
            if (GUILayout.Button("🔄 刷新", GUILayout.Width(60)))
            {
                RefreshCurrentDirectory();
            }

            // 关闭按钮
            if (GUILayout.Button("关闭", GUILayout.Width(60))) visible = false;

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 核心功能
        // ============================================================

        private static void RefreshCurrentDirectory()
        {
            currentFiles.Clear();
            currentDirectories.Clear();

            try
            {
                if (!Directory.Exists(currentPath))
                {
                    Directory.CreateDirectory(currentPath);
                    return;
                }

                // 获取子目录
                currentDirectories = Directory.GetDirectories(currentPath).ToList();

                // 获取文件
                foreach (string file in Directory.GetFiles(currentPath))
                {
                    try
                    {
                        var info = new FileInfo(file);
                        currentFiles.Add(new FileEntry
                        {
                            Name = Path.GetFileName(file),
                            FullPath = file,
                            Extension = Path.GetExtension(file).ToLower(),
                            IsDirectory = false,
                            Size = info.Length,
                            ModifiedTime = info.LastWriteTime
                        });
                    }
                    catch { }
                }

                // 排序：目录在前，文件在后
                currentDirectories = currentDirectories.OrderBy(d => Path.GetFileName(d)).ToList();
                currentFiles = currentFiles.OrderBy(f => f.Name).ToList();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[资源浏览器] 刷新失败: {ex.Message}");
            }
        }

        private static void GoUpDirectory()
        {
            string parent = Path.GetDirectoryName(currentPath);
            if (!string.IsNullOrEmpty(parent) && parent != currentPath)
            {
                currentPath = parent;
                RefreshCurrentDirectory();
            }
        }

        private static void ImportFile(FileEntry file)
        {
            try
            {
                string fileType = GetFileType(file.Extension);
                string relativePath = GetRelativePath(file.FullPath);

                Debug.Log($"[资源浏览器] 📥 导入 {fileType}: {file.Name}");

                // 如果有目标逻辑体，自动应用
                if (targetLogic != null)
                {
                    ApplyToLogic(targetLogic, file, relativePath, fileType);
                }
                else
                {
                    // 提示用户选择逻辑体
                    Debug.Log($"[资源浏览器] 💡 请先打开一个逻辑体，或从逻辑体编辑器打开此窗口");
                }

                // 弹窗提示
                Debug.Log($"[资源浏览器] ✅ 已导入: {relativePath}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[资源浏览器] 导入失败: {ex.Message}");
            }
        }

        private static void ApplyToLogic(LogicEntityV2 logic, FileEntry file, string relativePath, string fileType)
        {
            switch (fileType)
            {
                case "模型":
                    logic.resources.Model = relativePath;
                    break;
                case "纹理":
                    if (logic.resources.Textures == null)
                        logic.resources.Textures = new List<string>();
                    if (!logic.resources.Textures.Contains(relativePath))
                        logic.resources.Textures.Add(relativePath);
                    break;
                case "音频":
                    if (logic.resources.Audio == null)
                        logic.resources.Audio = new List<string>();
                    if (!logic.resources.Audio.Contains(relativePath))
                        logic.resources.Audio.Add(relativePath);
                    break;
                case "材质":
                    if (logic.resources.Materials == null)
                        logic.resources.Materials = new List<string>();
                    if (!logic.resources.Materials.Contains(relativePath))
                        logic.resources.Materials.Add(relativePath);
                    break;
                case "动画":
                    if (logic.resources.Animations == null)
                        logic.resources.Animations = new List<string>();
                    if (!logic.resources.Animations.Contains(relativePath))
                        logic.resources.Animations.Add(relativePath);
                    break;
                case "预制体":
                    logic.resources.Prefab = relativePath;
                    break;
                case "DLL":
                    // DLL 需要复制到逻辑体文件夹
                    string destPath = Path.Combine(logic.FolderPath, "logic.dll");
                    File.Copy(file.FullPath, destPath, true);
                    logic.resources.DLL = "logic.dll";
                    Debug.Log($"[资源浏览器] 🔌 DLL 已复制到: {destPath}");
                    break;
                case "脚本":
                    // 脚本复制到逻辑体文件夹
                    string scriptDest = Path.Combine(logic.FolderPath, Path.GetFileName(file.FullPath));
                    File.Copy(file.FullPath, scriptDest, true);
                    if (logic.resources.Scripts == null)
                        logic.resources.Scripts = new List<string>();
                    if (!logic.resources.Scripts.Contains(Path.GetFileName(file.FullPath)))
                        logic.resources.Scripts.Add(Path.GetFileName(file.FullPath));
                    Debug.Log($"[资源浏览器] 📝 脚本已复制到: {scriptDest}");
                    break;
                default:
                    Debug.LogWarning($"[资源浏览器] 未知类型: {fileType}");
                    return;
            }

            LogicManagerV2.SaveToFile(logic);
            Debug.Log($"[资源浏览器] ✅ 已应用 {fileType} 到 {logic.name}: {relativePath}");
        }

        // ============================================================
        // 文件预览
        // ============================================================
        private static void PreviewFile(FileEntry file)
        {
            string ext = file.Extension.ToLower();

            if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga")
            {
                Debug.Log($"[资源浏览器] 🖼️ 预览纹理: {file.Name}");
                // 可以加载并显示纹理
                try
                {
                    byte[] data = File.ReadAllBytes(file.FullPath);
                    Texture2D tex = new Texture2D(2, 2);
                    if (ImageConversion.LoadImage(tex, data))
                    {
                        Debug.Log($"[资源浏览器] 纹理尺寸: {tex.width}x{tex.height}");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[资源浏览器] 预览失败: {ex.Message}");
                }
            }
            else if (ext == ".wav" || ext == ".mp3" || ext == ".ogg")
            {
                Debug.Log($"[资源浏览器] 🔊 预览音频: {file.Name}");
            }
            else
            {
                Debug.Log($"[资源浏览器] 📄 预览文件: {file.Name}");
                // 显示文件内容（如果是文本文件）
                try
                {
                    if (ext == ".txt" || ext == ".cs" || ext == ".json" || ext == ".xml" || ext == ".mat" || ext == ".anim")
                    {
                        string content = File.ReadAllText(file.FullPath);
                        if (content.Length > 2000)
                            content = content.Substring(0, 2000) + "\n... (截断)";
                        Debug.Log($"[资源浏览器] 内容:\n{content}");
                    }
                }
                catch { }
            }
        }

        private static bool IsPreviewable(string extension)
        {
            string ext = extension.ToLower();
            return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga" ||
                   ext == ".wav" || ext == ".mp3" || ext == ".ogg" ||
                   ext == ".txt" || ext == ".cs" || ext == ".json";
        }

        // ============================================================
        // 辅助方法
        // ============================================================

        private static string GetFileIcon(string extension)
        {
            string ext = extension.ToLower();
            if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tga") return "🖼️";
            if (ext == ".obj" || ext == ".fbx" || ext == ".dae" || ext == ".gltf") return "🎨";
            if (ext == ".wav" || ext == ".mp3" || ext == ".ogg") return "🔊";
            if (ext == ".mat") return "🧪";
            if (ext == ".anim") return "🎬";
            if (ext == ".prefab") return "📦";
            if (ext == ".dll") return "🔌";
            if (ext == ".cs") return "📝";
            if (ext == ".txt" || ext == ".json" || ext == ".xml") return "📄";
            return "📁";
        }

        private static string GetFileType(string extension)
        {
            string ext = extension.ToLower();
            if (fileTypeMap.ContainsKey(ext)) return fileTypeMap[ext];
            return "未知";
        }

        private static string FormatFileSize(long bytes)
        {
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1024 * 1024) return (bytes / 1024.0).ToString("F1") + " KB";
            if (bytes < 1024 * 1024 * 1024) return (bytes / (1024.0 * 1024.0)).ToString("F1") + " MB";
            return (bytes / (1024.0 * 1024.0 * 1024.0)).ToString("F1") + " GB";
        }

        private static string GetRelativePath(string fullPath)
        {
            string basePath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets").Replace("\\", "/");
            string path = fullPath.Replace("\\", "/");
            if (path.StartsWith(basePath))
            {
                return path.Substring(basePath.Length + 1);
            }
            return path;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using UnityEngine;
using BepInEx;

namespace SuperConsole
{
    /// <summary>
    /// 可视化逻辑体编辑器 - 浏览资源、管理脚本、配置逻辑体
    /// </summary>
    public static class LogicEditorWindow
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(0, 0, Screen.width, Screen.height);
        private static Vector2 scrollPos = Vector2.zero;
        private static Vector2 resourceScrollPos = Vector2.zero;
        private static Vector2 scriptScrollPos = Vector2.zero;
        private static int selectedTab = 0; // 0=资源, 1=脚本, 2=DLL, 3=组件

        // ===== 当前编辑 =====
        private static LogicEntityV2 editingLogic = null;

        // ===== 资源浏览器 =====
        private static string[] modelFiles = new string[0];
        private static string[] textureFiles = new string[0];
        private static string[] audioFiles = new string[0];
        private static string[] materialFiles = new string[0];
        private static string[] animationFiles = new string[0];
        private static string[] prefabFiles = new string[0];
        private static string selectedResource = "";
        private static string resourceSearch = "";

        // ===== 脚本编辑器 =====
        private static string scriptCode = "";
        private static string scriptName = "";
        private static string scriptOutput = "";
        private static bool isCompiling = false;

        // ===== 组件管理 =====
        private static string addComponentInput = "";
        private static bool showComponentDropdown = false;
        private static int componentSelectedIndex = -1;
        private static Rect addComponentRect = Rect.zero;
        private static List<string> componentSuggestions = new List<string>();

        // ===== 路径 =====
        private static string assetsPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
        private static string logicsPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Logics");

        public static Rect GetWindowRect() => windowRect;
        public static void ResetPosition() => windowRect = new Rect(0, 0, Screen.width, Screen.height);
        public static bool IsVisible() => visible;

        public static void Toggle()
        {
            visible = !visible;
            if (visible)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
                RefreshResourceList();
                LoadComponentTypes();

                var all = LogicManagerV2.GetAll();
                if (all.Count > 0) editingLogic = all[0];

                if (editingLogic != null)
                {
                    LoadScriptFromLogic(editingLogic);
                }
            }
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12363);
            windowRect = GUI.Window(12363, windowRect, DrawWindow, "逻辑体编辑器 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            if (windowRect.width < Screen.width * 0.8f || windowRect.height < Screen.height * 0.8f)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
            }

            GUILayout.BeginVertical();

            DrawLogicSelector();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (editingLogic == null)
            {
                GUILayout.Label("请选择一个逻辑体或新建一个");
                GUILayout.EndVertical();
                GUI.DragWindow();
                return;
            }

            GUILayout.BeginHorizontal();
            string[] tabs = { "资源管理", "脚本编辑", "DLL 配置", "组件管理" };
            int newTab = GUILayout.SelectionGrid(selectedTab, tabs, 4, GUILayout.ExpandWidth(true));
            if (newTab != selectedTab) { selectedTab = newTab; scrollPos = Vector2.zero; }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            switch (selectedTab)
            {
                case 0: DrawResourceTab(); break;
                case 1: DrawScriptTab(); break;
                case 2: DrawDLLTab(); break;
                case 3: DrawComponentTab(); break;
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label($"编辑: {editingLogic.GetDisplayName()}", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("保存全部", GUILayout.Width(100)))
            {
                SaveAll();
            }
            if (GUILayout.Button("关闭", GUILayout.Width(60))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        // ============================================================
        // 1. 逻辑体选择器
        // ============================================================
        private static void DrawLogicSelector()
        {
            GUILayout.BeginHorizontal();

            var all = LogicManagerV2.GetAll();
            string[] names = all.Select(l => l.GetDisplayName()).ToArray();
            int idx = editingLogic != null ? Array.IndexOf(names, editingLogic.GetDisplayName()) : -1;
            if (idx < 0 && names.Length > 0) idx = 0;

            GUILayout.Label("逻辑体:", GUILayout.Width(50));

            int newIdx = GUILayout.SelectionGrid(
                idx >= 0 ? idx : 0,
                names.Length > 0 ? names : new string[] { "(无)" },
                6,
                GUILayout.ExpandWidth(true)
            );

            if (newIdx >= 0 && newIdx < names.Length && (editingLogic == null || editingLogic.GetDisplayName() != names[newIdx]))
            {
                editingLogic = LogicManagerV2.GetAll()[newIdx];
                LoadScriptFromLogic(editingLogic);
                RefreshResourceList();
                LoadComponentTypes();
            }

            if (GUILayout.Button("新建", GUILayout.Width(50)))
            {
                var logic = LogicManagerV2.Create("新逻辑体_" + (all.Count + 1));
                editingLogic = logic;
                scriptCode = "";
                scriptName = "";
                RefreshResourceList();
                LoadComponentTypes();
            }

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 2. 资源管理 Tab
        // ============================================================
        private static void DrawResourceTab()
        {
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("打开资源浏览器", GUILayout.Height(30)))
            {
                LogicResourceBrowser.Toggle(editingLogic, "");
            }
            GUILayout.EndHorizontal();

            GUILayout.Label("资源管理 - 浏览并选择资源文件", GUILayout.ExpandWidth(true));
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("搜索:", GUILayout.Width(45));
            resourceSearch = GUILayout.TextField(resourceSearch, GUILayout.ExpandWidth(true));
            if (GUILayout.Button("刷新", GUILayout.Width(50))) RefreshResourceList();
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            resourceScrollPos = GUILayout.BeginScrollView(resourceScrollPos, GUILayout.Height(300));

            var allResources = GetAllResources();
            var filtered = string.IsNullOrEmpty(resourceSearch)
                ? allResources
                : allResources.Where(r => r.name.ToLower().Contains(resourceSearch.ToLower())).ToList();

            if (filtered.Count == 0)
            {
                GUILayout.Label("没有找到资源文件");
                GUILayout.Label($"请将资源放到: {assetsPath}");
                GUILayout.Label("模型: Assets/Models/ 纹理: Assets/Textures/ 音频: Assets/Audio/");
            }
            else
            {
                GUILayout.BeginHorizontal();
                GUILayout.Label("文件", GUILayout.Width(200));
                GUILayout.Label("类型", GUILayout.Width(80));
                GUILayout.Label("操作", GUILayout.Width(200));
                GUILayout.EndHorizontal();

                foreach (var res in filtered)
                {
                    GUILayout.BeginHorizontal("box");

                    GUILayout.Label(res.name, GUILayout.Width(200));
                    GUILayout.Label(res.type, GUILayout.Width(80));

                    string path = res.path.Replace("\\", "/");
                    string relativePath = GetRelativePath(path);

                    if (GUILayout.Button($"应用为{res.type}", GUILayout.Width(100)))
                    {
                        ApplyResourceToLogic(res, relativePath);
                    }

                    if (GUILayout.Button("预览", GUILayout.Width(50)))
                    {
                        Debug.Log($"[逻辑编辑器] 预览: {res.name}");
                    }

                    GUILayout.EndHorizontal();
                }
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("当前逻辑体资源:", GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label($"预制体: {(string.IsNullOrEmpty(editingLogic.resources.Prefab) ? "(无)" : editingLogic.resources.Prefab)}", GUILayout.Width(200));
            GUILayout.Label($"模型: {(string.IsNullOrEmpty(editingLogic.resources.Model) ? "(无)" : editingLogic.resources.Model)}", GUILayout.Width(200));
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            GUILayout.Label($"纹理: {editingLogic.resources.Textures?.Count ?? 0}", GUILayout.Width(100));
            GUILayout.Label($"音频: {editingLogic.resources.Audio?.Count ?? 0}", GUILayout.Width(100));
            GUILayout.Label($"材质: {editingLogic.resources.Materials?.Count ?? 0}", GUILayout.Width(100));
            GUILayout.Label($"动画: {editingLogic.resources.Animations?.Count ?? 0}", GUILayout.Width(100));
            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 3. 脚本编辑 Tab
        // ============================================================
        private static void DrawScriptTab()
        {
            GUILayout.Label("脚本编辑 - 编写 C# 脚本控制逻辑体行为", GUILayout.ExpandWidth(true));
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("脚本名称:", GUILayout.Width(70));
            scriptName = GUILayout.TextField(scriptName, GUILayout.Width(200));
            if (GUILayout.Button("加载脚本", GUILayout.Width(80)))
            {
                LoadScriptFromLogic(editingLogic);
            }
            if (GUILayout.Button("保存脚本", GUILayout.Width(80)))
            {
                SaveScriptToLogic(editingLogic);
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("脚本代码 (C#):", GUILayout.ExpandWidth(true));
            scriptScrollPos = GUILayout.BeginScrollView(scriptScrollPos, GUILayout.Height(200));

            scriptCode = GUILayout.TextArea(scriptCode, GUILayout.ExpandHeight(true));

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("编译并生成 DLL", GUILayout.Height(30)))
            {
                CompileScript();
            }
            if (GUILayout.Button("测试脚本", GUILayout.Height(30)))
            {
                TestScript();
            }
            if (GUILayout.Button("模板: ILogicObject", GUILayout.Height(30)))
            {
                scriptCode = GetILogicObjectTemplate();
            }
            if (GUILayout.Button("模板: MonoBehaviour", GUILayout.Height(30)))
            {
                scriptCode = GetMonoBehaviourTemplate();
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("编译输出:", GUILayout.ExpandWidth(true));
            GUILayout.TextArea(scriptOutput, GUILayout.Height(80));
        }

        // ============================================================
        // 4. DLL 配置 Tab
        // ============================================================
        private static void DrawDLLTab()
        {
            GUILayout.Label("DLL 配置 - 管理逻辑体专属 DLL", GUILayout.ExpandWidth(true));
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("当前 DLL:", GUILayout.Width(80));
            string dllPath = Path.Combine(editingLogic.FolderPath, "logic.dll");
            bool dllExists = File.Exists(dllPath);
            GUILayout.Label(dllExists ? $"{dllPath}" : "未找到 logic.dll", GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("DLL 操作:", GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("选择 DLL 文件", GUILayout.Height(25)))
            {
                Debug.Log("[逻辑编辑器] 请将 DLL 放到: " + editingLogic.FolderPath + "/logic.dll");
            }
            if (GUILayout.Button("删除 DLL", GUILayout.Height(25)))
            {
                if (File.Exists(dllPath))
                {
                    File.Delete(dllPath);
                    Debug.Log("[逻辑编辑器] DLL 已删除");
                }
            }
            if (GUILayout.Button("重新加载 DLL", GUILayout.Height(25)))
            {
                LogicDLLLoader.UnloadDLL(editingLogic.id);
                LogicDLLLoader.LoadDLL(editingLogic);
                Debug.Log("[逻辑编辑器] DLL 已重新加载");
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("从脚本编译 DLL:", GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("编译当前脚本为 DLL", GUILayout.Height(25)))
            {
                CompileScriptToDLL(editingLogic);
            }
            if (GUILayout.Button("查看 DLL 信息", GUILayout.Height(25)))
            {
                if (dllExists)
                {
                    var assembly = Assembly.LoadFrom(dllPath);
                    Debug.Log($"[逻辑编辑器] DLL 信息: {assembly.GetName()}");
                    foreach (var type in assembly.GetTypes())
                    {
                        Debug.Log($"  - {type.Name}");
                    }
                }
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.Label("DLL 配置选项:", GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label("在 mod.json 中设置 DLL:", GUILayout.Width(200));
            string dllSetting = editingLogic.resources.DLL ?? "";
            string newDllSetting = GUILayout.TextField(dllSetting, GUILayout.Width(200));
            if (newDllSetting != dllSetting)
            {
                editingLogic.resources.DLL = newDllSetting;
            }
            GUILayout.EndHorizontal();

            GUILayout.Label("提示: DLL 文件命名为 logic.dll 并放在逻辑体文件夹中");
            GUILayout.Label("提示: 重启游戏后 DLL 才会生效 (或使用 ext reload)");
        }

        // ============================================================
        // 5. 组件管理 Tab (新增)
        // ============================================================
        // ============================================================
        // 5. 组件管理 Tab (修复版)
        // ============================================================
        private static void DrawComponentTab()
        {
            GUILayout.Label("组件管理 - 给逻辑体对象添加/管理组件", GUILayout.ExpandWidth(true));
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // 检查逻辑体是否已召唤
            bool isSpawned = editingLogic != null && editingLogic.GameObject != null;

            if (!isSpawned)
            {
                GUILayout.Label("逻辑体尚未召唤到场景，无法管理组件");
                GUILayout.Label("请先点击「召唤到玩家」或「召唤到鼠标」将逻辑体召出");
                GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
                return;  // ✅ 这里直接 return，不继续绘制
            }

            // 显示当前组件列表
            GUILayout.Label($"当前对象: {editingLogic.GameObject.name} 的组件", GUILayout.ExpandWidth(true));

            var comps = editingLogic.GameObject.GetComponents<Component>();
            if (comps.Length == 0)
            {
                GUILayout.Label("  没有组件");
            }
            else
            {
                foreach (var comp in comps)
                {
                    if (comp == null) continue;
                    GUILayout.BeginHorizontal("box");
                    GUILayout.Label($"  - {comp.GetType().Name}", GUILayout.Width(250));

                    if (comp is Behaviour behaviour)
                    {
                        bool enabled = GUILayout.Toggle(behaviour.enabled, "启用", GUILayout.Width(50));
                        if (enabled != behaviour.enabled) behaviour.enabled = enabled;
                    }

                    if (GUILayout.Button("删除", GUILayout.Width(50)))
                    {
                        UnityEngine.Object.Destroy(comp);
                        Debug.Log($"[逻辑编辑器] 已删除组件: {comp.GetType().Name}");
                        // 刷新 UI 需要重新加载组件列表
                        break;
                    }
                    GUILayout.EndHorizontal();
                }
            }

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // 添加组件（带自动补全）
            GUILayout.Label("添加组件:", GUILayout.ExpandWidth(true));
            GUILayout.BeginHorizontal();
            GUILayout.Label("组件名:", GUILayout.Width(50));

            string newComponent = AutoCompleteInput.Draw(
                "",
                addComponentInput,
                componentSuggestions,
                ref showComponentDropdown,
                ref componentSelectedIndex,
                ref addComponentRect,
                GUILayout.Width(200)
            );

            if (newComponent != addComponentInput)
            {
                addComponentInput = newComponent;
            }

            if (GUILayout.Button("添加", GUILayout.Width(50)))
            {
                if (!string.IsNullOrEmpty(addComponentInput) && editingLogic != null && editingLogic.GameObject != null)
                {
                    Type compType = FindType(addComponentInput);
                    if (compType != null && typeof(Component).IsAssignableFrom(compType))
                    {
                        editingLogic.GameObject.AddComponent(compType);
                        Debug.Log($"[逻辑编辑器] 已添加组件: {addComponentInput} 到 {editingLogic.GameObject.name}");
                        addComponentInput = "";
                        showComponentDropdown = false;
                        LoadComponentTypes();
                    }
                    else
                    {
                        Debug.LogWarning($"[逻辑编辑器] 找不到组件类型: {addComponentInput}");
                    }
                }
                else if (editingLogic == null || editingLogic.GameObject == null)
                {
                    Debug.LogWarning("[逻辑编辑器] 请先召唤逻辑体到场景");
                }
            }
            GUILayout.EndHorizontal();

            GUILayout.Label("提示: 组件名会自动补全，输入几个字母即可选择", GUILayout.ExpandWidth(true));
            GUILayout.Label("提示: 添加后组件会立即生效，无需重启", GUILayout.ExpandWidth(true));
        }

        // ============================================================
        // 辅助方法
        // ============================================================

        private class ResourceInfo
        {
            public string name;
            public string path;
            public string type;
            public string extension;
        }

        private static void LoadComponentTypes()
        {
            componentSuggestions.Clear();
            try
            {
                var types = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(a => { try { return a.GetTypes(); } catch { return new Type[0]; } })
                    .Where(t => typeof(Component).IsAssignableFrom(t) && !t.IsAbstract && !t.IsInterface)
                    .Select(t => t.Name)
                    .Distinct()
                    .OrderBy(n => n)
                    .ToList();

                componentSuggestions.AddRange(types);
                Debug.Log($"[逻辑编辑器] 加载了 {componentSuggestions.Count} 个组件类型");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[逻辑编辑器] 加载组件类型失败: {ex.Message}");
            }
        }

        private static Type FindType(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;

            Type targetType = Type.GetType(typeName);
            if (targetType != null) return targetType;

            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    targetType = asm.GetType(typeName);
                    if (targetType != null) return targetType;

                    foreach (var t in asm.GetTypes())
                    {
                        if (t.Name == typeName || t.FullName == typeName)
                            return t;
                    }
                }
                catch { }
            }
            return null;
        }

        private static void RefreshResourceList()
        {
            modelFiles = GetFiles(Path.Combine(assetsPath, "Models"), new[] { ".obj", ".fbx", ".dae", ".gltf", ".stl" });
            textureFiles = GetFiles(Path.Combine(assetsPath, "Textures"), new[] { ".png", ".jpg", ".jpeg", ".tga", ".dds" });
            audioFiles = GetFiles(Path.Combine(assetsPath, "Audio"), new[] { ".wav", ".mp3", ".ogg", ".flac" });
            materialFiles = GetFiles(Path.Combine(assetsPath, "Materials"), new[] { ".mat" });
            animationFiles = GetFiles(Path.Combine(assetsPath, "Animations"), new[] { ".anim" });
            prefabFiles = GetFiles(Path.Combine(assetsPath, "Prefabs"), new[] { ".prefab" });
        }

        private static string[] GetFiles(string dir, string[] extensions)
        {
            if (!Directory.Exists(dir)) return new string[0];
            return Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories)
                .Where(f => extensions.Contains(Path.GetExtension(f).ToLower()))
                .ToArray();
        }

        private static List<ResourceInfo> GetAllResources()
        {
            var result = new List<ResourceInfo>();
            AddResources(result, modelFiles, "模型");
            AddResources(result, textureFiles, "纹理");
            AddResources(result, audioFiles, "音频");
            AddResources(result, materialFiles, "材质");
            AddResources(result, animationFiles, "动画");
            AddResources(result, prefabFiles, "预制体");
            return result;
        }

        private static void AddResources(List<ResourceInfo> list, string[] files, string type)
        {
            foreach (var f in files)
            {
                list.Add(new ResourceInfo
                {
                    name = Path.GetFileNameWithoutExtension(f),
                    path = f,
                    type = type,
                    extension = Path.GetExtension(f)
                });
            }
        }

        private static string GetRelativePath(string fullPath)
        {
            string basePath = assetsPath.Replace("\\", "/");
            string path = fullPath.Replace("\\", "/");
            if (path.StartsWith(basePath))
            {
                return path.Substring(basePath.Length + 1);
            }
            return path;
        }

        private static void ApplyResourceToLogic(ResourceInfo res, string relativePath)
        {
            if (editingLogic == null) return;

            switch (res.type)
            {
                case "模型":
                    editingLogic.resources.Model = relativePath;
                    break;
                case "纹理":
                    if (editingLogic.resources.Textures == null)
                        editingLogic.resources.Textures = new List<string>();
                    if (!editingLogic.resources.Textures.Contains(relativePath))
                        editingLogic.resources.Textures.Add(relativePath);
                    break;
                case "音频":
                    if (editingLogic.resources.Audio == null)
                        editingLogic.resources.Audio = new List<string>();
                    if (!editingLogic.resources.Audio.Contains(relativePath))
                        editingLogic.resources.Audio.Add(relativePath);
                    break;
                case "材质":
                    if (editingLogic.resources.Materials == null)
                        editingLogic.resources.Materials = new List<string>();
                    if (!editingLogic.resources.Materials.Contains(relativePath))
                        editingLogic.resources.Materials.Add(relativePath);
                    break;
                case "动画":
                    if (editingLogic.resources.Animations == null)
                        editingLogic.resources.Animations = new List<string>();
                    if (!editingLogic.resources.Animations.Contains(relativePath))
                        editingLogic.resources.Animations.Add(relativePath);
                    break;
                case "预制体":
                    editingLogic.resources.Prefab = relativePath;
                    break;
            }

            LogicManagerV2.SaveToFile(editingLogic);
            Debug.Log($"[逻辑编辑器] 已应用 {res.type}: {relativePath}");
        }

        // ============================================================
        // 脚本加载/保存
        // ============================================================
        private static void LoadScriptFromLogic(LogicEntityV2 logic)
        {
            if (logic == null) return;
            string scriptPath = Path.Combine(logic.FolderPath, "logic.cs");
            if (File.Exists(scriptPath))
            {
                scriptCode = File.ReadAllText(scriptPath);
                scriptName = Path.GetFileNameWithoutExtension(scriptPath);
                Debug.Log($"[逻辑编辑器] 加载脚本: {scriptPath}");
            }
            else
            {
                scriptCode = GetILogicObjectTemplate();
                scriptName = "logic";
            }
        }

        private static void SaveScriptToLogic(LogicEntityV2 logic)
        {
            if (logic == null || string.IsNullOrEmpty(scriptCode)) return;
            string scriptPath = Path.Combine(logic.FolderPath, scriptName + ".cs");
            File.WriteAllText(scriptPath, scriptCode);
            Debug.Log($"[逻辑编辑器] 脚本已保存: {scriptPath}");
        }

        // ============================================================
        // 脚本编译
        // ============================================================
        private static void CompileScript()
        {
            if (string.IsNullOrEmpty(scriptCode))
            {
                scriptOutput = "没有代码可编译";
                return;
            }

            isCompiling = true;
            scriptOutput = "编译中...";

            try
            {
                var references = new List<MetadataReference>();

                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (!asm.IsDynamic && !string.IsNullOrEmpty(asm.Location))
                    {
                        try { references.Add(MetadataReference.CreateFromFile(asm.Location)); }
                        catch { }
                    }
                }

                var options = new CSharpCompilationOptions(
                    OutputKind.DynamicallyLinkedLibrary,
                    optimizationLevel: OptimizationLevel.Release,
                    allowUnsafe: true
                );

                string fullCode = @"
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SuperConsole;

" + scriptCode;

                var syntaxTree = SyntaxFactory.ParseSyntaxTree(fullCode);
                var compilation = CSharpCompilation.Create(
                    "LogicScript",
                    new[] { syntaxTree },
                    references,
                    options
                );

                using (var ms = new MemoryStream())
                {
                    var result = compilation.Emit(ms);
                    if (!result.Success)
                    {
                        string errors = "";
                        foreach (var diagnostic in result.Diagnostics)
                        {
                            if (diagnostic.Severity == DiagnosticSeverity.Error)
                                errors += diagnostic.ToString() + "\n";
                        }
                        scriptOutput = "编译错误:\n" + errors;
                    }
                    else
                    {
                        scriptOutput = "编译成功！DLL 大小: " + ms.Length + " bytes";
                        string dllPath = Path.Combine(editingLogic.FolderPath, "logic.dll");
                        File.WriteAllBytes(dllPath, ms.ToArray());
                        scriptOutput += $"\nDLL 已保存到: {dllPath}";

                        editingLogic.resources.DLL = "logic.dll";
                        LogicManagerV2.SaveToFile(editingLogic);
                    }
                }
            }
            catch (Exception ex)
            {
                scriptOutput = "编译异常: " + ex.Message;
            }

            isCompiling = false;
        }

        private static void CompileScriptToDLL(LogicEntityV2 logic)
        {
            SaveScriptToLogic(logic);
            CompileScript();
        }

        // ============================================================
        // 测试脚本
        // ============================================================
        private static void TestScript()
        {
            scriptOutput = "测试脚本...";
            try
            {
                var references = new List<MetadataReference>();
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    if (!asm.IsDynamic && !string.IsNullOrEmpty(asm.Location))
                    {
                        try { references.Add(MetadataReference.CreateFromFile(asm.Location)); }
                        catch { }
                    }
                }

                var options = new CSharpCompilationOptions(
                    OutputKind.DynamicallyLinkedLibrary,
                    optimizationLevel: OptimizationLevel.Release,
                    allowUnsafe: true
                );

                string fullCode = @"
using System;
using UnityEngine;
using SuperConsole;

public class ScriptTester
{
    public static void Run()
    {
" + scriptCode + @"
    }
}";

                var syntaxTree = SyntaxFactory.ParseSyntaxTree(fullCode);
                var compilation = CSharpCompilation.Create(
                    "ScriptTester",
                    new[] { syntaxTree },
                    references,
                    options
                );

                using (var ms = new MemoryStream())
                {
                    var result = compilation.Emit(ms);
                    if (!result.Success)
                    {
                        string errors = "";
                        foreach (var diagnostic in result.Diagnostics)
                        {
                            if (diagnostic.Severity == DiagnosticSeverity.Error)
                                errors += diagnostic.ToString() + "\n";
                        }
                        scriptOutput = "测试失败:\n" + errors;
                    }
                    else
                    {
                        ms.Seek(0, SeekOrigin.Begin);
                        var assembly = Assembly.Load(ms.ToArray());
                        var type = assembly.GetType("ScriptTester");
                        if (type != null)
                        {
                            var method = type.GetMethod("Run");
                            if (method != null)
                            {
                                method.Invoke(null, null);
                                scriptOutput = "测试执行成功！";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                scriptOutput = "测试异常: " + ex.Message;
            }
        }

        // ============================================================
        // 保存全部
        // ============================================================
        private static void SaveAll()
        {
            if (editingLogic == null) return;

            SaveScriptToLogic(editingLogic);
            LogicManagerV2.SaveToFile(editingLogic);

            Debug.Log($"[逻辑编辑器] 全部已保存: {editingLogic.GetDisplayName()}");
            scriptOutput = "全部已保存！";
        }

        // ============================================================
        // 代码模板
        // ============================================================
        private static string GetILogicObjectTemplate()
        {
            return @"
public class MyLogic : ILogicObject
{
    private GameObject self;
    private LogicEntityV2 logic;
    private float health = 100f;

    public void OnSpawn(GameObject gameObject, LogicEntityV2 logicData)
    {
        self = gameObject;
        logic = logicData;
        Debug.Log(""逻辑体已召唤: "" + logic.name);
    }

    public void OnUpdate()
    {
        // 每帧更新
    }

    public void OnDestroy(GameObject gameObject)
    {
        Debug.Log(""逻辑体被销毁: "" + logic.name);
    }

    public void OnMessage(string message, object data)
    {
        if (message == ""TakeDamage"")
        {
            health -= (float)data;
        }
    }
}";
        }

        private static string GetMonoBehaviourTemplate()
        {
            return @"
public class MyBehavior : MonoBehaviour
{
    void Start()
    {
        Debug.Log(""组件已挂载！"");
    }

    void Update()
    {
        transform.Rotate(0, 30f * Time.deltaTime, 0);
    }

    void OnCollisionEnter(Collision collision)
    {
        Debug.Log(""撞到了: "" + collision.gameObject.name);
    }
}";
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using System.Reflection;

namespace SuperConsole
{
    /// <summary>
    /// 逻辑体资源集成 - 让逻辑体能使用游戏中的所有资源！
    /// </summary>
    public static class LogicAssetIntegration
    {
        // ============================================================
        // 扩展 ActionType（动态注册）
        // ============================================================
        private static Dictionary<string, Action<LogicAction>> customActions = new Dictionary<string, Action<LogicAction>>();
        private static Dictionary<string, Func<LogicAction, bool>> customConditions = new Dictionary<string, Func<LogicAction, bool>>();

        static LogicAssetIntegration()
        {
            RegisterDefaultActions();
            RegisterDefaultConditions();
            Debug.Log("[LogicAssetIntegration] ✅ 已加载，逻辑体现可访问游戏资源！");
        }

        // ============================================================
        // 注册系统
        // ============================================================
        public static void RegisterAction(string name, Action<LogicAction> action)
        {
            if (!customActions.ContainsKey(name))
                customActions[name] = action;
            else
                Debug.LogWarning($"[LogicAssetIntegration] 动作已存在: {name}");
        }

        public static void RegisterCondition(string name, Func<LogicAction, bool> condition)
        {
            if (!customConditions.ContainsKey(name))
                customConditions[name] = condition;
            else
                Debug.LogWarning($"[LogicAssetIntegration] 条件已存在: {name}");
        }

        public static void ExecuteCustomAction(LogicAction action)
        {
            if (string.IsNullOrEmpty(action.CustomCode)) return;
            string[] parts = action.CustomCode.Split(':');
            string actionName = parts[0];

            if (customActions.ContainsKey(actionName))
            {
                try { customActions[actionName](action); }
                catch (Exception ex) { Debug.LogError($"[LogicAssetIntegration] 执行动作失败: {ex.Message}"); }
            }
            else
            {
                Debug.LogWarning($"[LogicAssetIntegration] 未知动作: {actionName}");
            }
        }

        public static bool CheckCustomCondition(LogicCondition condition)
        {
            if (string.IsNullOrEmpty(condition.CustomCode)) return true;
            string[] parts = condition.CustomCode.Split(':');
            string conditionName = parts[0];

            if (customConditions.ContainsKey(conditionName))
            {
                try { return customConditions[conditionName](null); }
                catch { return false; }
            }
            return false;
        }

        // ============================================================
        // 默认资源动作（让逻辑体能使用游戏资源）
        // ============================================================
        private static void RegisterDefaultActions()
        {
            // ===== 1. 生成预制体 =====
            RegisterAction("SpawnPrefab", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                GameObject prefab = FindGameObject(action.Target);
                if (prefab != null)
                {
                    GameObject instance = UnityEngine.Object.Instantiate(prefab);
                    if (!string.IsNullOrEmpty(action.Value))
                    {
                        try
                        {
                            string[] pos = action.Value.Split(',');
                            if (pos.Length >= 3)
                            {
                                float x = float.Parse(pos[0]);
                                float y = float.Parse(pos[1]);
                                float z = float.Parse(pos[2]);
                                instance.transform.position = new Vector3(x, y, z);
                            }
                        }
                        catch { }
                    }
                    Debug.Log($"[LogicAssetIntegration] ✅ 生成预制体: {action.Target}");
                }
                else
                {
                    Debug.LogWarning($"[LogicAssetIntegration] ⚠️ 找不到预制体: {action.Target}");
                }
            });

            // ===== 2. 播放音频 =====
            RegisterAction("PlaySound", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                AudioClip clip = FindAudioClip(action.Target);
                if (clip != null)
                {
                    GameObject temp = new GameObject("TempAudio");
                    AudioSource source = temp.AddComponent<AudioSource>();
                    source.clip = clip;
                    source.Play();
                    UnityEngine.Object.Destroy(temp, clip.length);
                    Debug.Log($"[LogicAssetIntegration] 🔊 播放音频: {action.Target}");
                }
                else
                {
                    Debug.LogWarning($"[LogicAssetIntegration] ⚠️ 找不到音频: {action.Target}");
                }
            });

            // ===== 3. 显示特效 =====
            RegisterAction("ShowEffect", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                GameObject effect = FindGameObject(action.Target);
                if (effect != null)
                {
                    Vector3 pos = Vector3.zero;
                    if (!string.IsNullOrEmpty(action.Value))
                    {
                        try
                        {
                            string[] posStr = action.Value.Split(',');
                            if (posStr.Length >= 3)
                            {
                                pos = new Vector3(
                                    float.Parse(posStr[0]),
                                    float.Parse(posStr[1]),
                                    float.Parse(posStr[2])
                                );
                            }
                        }
                        catch { }
                    }
                    GameObject instance = UnityEngine.Object.Instantiate(effect, pos, Quaternion.identity);
                    ParticleSystem ps = instance.GetComponent<ParticleSystem>();
                    if (ps != null)
                    {
                        float duration = ps.main.duration + 1f;
                        UnityEngine.Object.Destroy(instance, duration);
                    }
                    else
                    {
                        UnityEngine.Object.Destroy(instance, 3f);
                    }
                    Debug.Log($"[LogicAssetIntegration] ✨ 显示特效: {action.Target}");
                }
                else
                {
                    Debug.LogWarning($"[LogicAssetIntegration] ⚠️ 找不到特效: {action.Target}");
                }
            });

            // ===== 4. 替换材质 =====
            RegisterAction("SetMaterial", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target) || string.IsNullOrEmpty(action.Value)) return;
                GameObject obj = GameObject.Find(action.Target);
                if (obj == null) return;
                Material mat = FindMaterial(action.Value);
                if (mat == null) return;
                Renderer renderer = obj.GetComponent<Renderer>();
                if (renderer != null)
                {
                    renderer.material = mat;
                    Debug.Log($"[LogicAssetIntegration] 🧪 替换材质: {action.Target} -> {action.Value}");
                }
            });

            // ===== 5. 替换纹理 =====
            RegisterAction("SetTexture", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target) || string.IsNullOrEmpty(action.Value)) return;
                GameObject obj = GameObject.Find(action.Target);
                if (obj == null) return;
                Texture2D tex = FindTexture(action.Value);
                if (tex == null) return;
                Renderer renderer = obj.GetComponent<Renderer>();
                if (renderer != null && renderer.material != null)
                {
                    renderer.material.mainTexture = tex;
                    Debug.Log($"[LogicAssetIntegration] 🖼️ 替换纹理: {action.Target} -> {action.Value}");
                }
            });

            // ===== 6. 播放动画 =====
            RegisterAction("PlayAnimation", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target) || string.IsNullOrEmpty(action.Value)) return;
                GameObject obj = GameObject.Find(action.Target);
                if (obj == null) return;
                AnimationClip clip = FindAnimationClip(action.Value);
                if (clip == null) return;
                Animation anim = obj.GetComponent<Animation>();
                if (anim == null) anim = obj.AddComponent<Animation>();
                anim.AddClip(clip, clip.name);
                anim.Play(clip.name);
                Debug.Log($"[LogicAssetIntegration] 🎬 播放动画: {action.Target} -> {action.Value}");
            });

            // ===== 7. 加载资源包 =====
            RegisterAction("LoadAssetBundle", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                var bundle = AssetBundle.LoadFromFile(action.Target);
                if (bundle != null)
                {
                    Debug.Log($"[LogicAssetIntegration] 📦 加载资源包: {action.Target}");
                    foreach (var name in bundle.GetAllAssetNames())
                    {
                        Debug.Log($"  - {name}");
                    }
                }
                else
                {
                    Debug.LogWarning($"[LogicAssetIntegration] ⚠️ 加载资源包失败: {action.Target}");
                }
            });

            // ===== 8. 从 Resources 加载 =====
            RegisterAction("LoadFromResources", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                UnityEngine.Object obj = Resources.Load(action.Target);
                if (obj != null)
                {
                    Debug.Log($"[LogicAssetIntegration] 📁 从 Resources 加载: {action.Target} ({obj.GetType().Name})");
                    if (obj is GameObject go)
                    {
                        UnityEngine.Object.Instantiate(go);
                    }
                }
                else
                {
                    Debug.LogWarning($"[LogicAssetIntegration] ⚠️ Resources 中找不到: {action.Target}");
                }
            });

            // ===== 9. 在玩家位置生成 =====
            RegisterAction("SpawnAtPlayer", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                GameObject prefab = FindGameObject(action.Target);
                if (prefab == null) return;
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player == null) return;
                GameObject instance = UnityEngine.Object.Instantiate(prefab, player.transform.position, Quaternion.identity);
                Debug.Log($"[LogicAssetIntegration] 📍 在玩家位置生成: {action.Target}");
            });

            // ===== 10. 在摄像机前生成 =====
            RegisterAction("SpawnInFrontOfCamera", (action) =>
            {
                if (string.IsNullOrEmpty(action.Target)) return;
                GameObject prefab = FindGameObject(action.Target);
                if (prefab == null) return;
                Camera cam = Camera.main;
                if (cam == null) return;
                Vector3 pos = cam.transform.position + cam.transform.forward * 2f;
                GameObject instance = UnityEngine.Object.Instantiate(prefab, pos, Quaternion.identity);
                Debug.Log($"[LogicAssetIntegration] 📷 在摄像机前生成: {action.Target}");
            });
        }

        // ============================================================
        // 默认资源条件
        // ============================================================
        private static void RegisterDefaultConditions()
        {
            // ===== 1. 资源是否存在 =====
            RegisterCondition("AssetExists", (action) =>
            {
                return FindGameObject(action?.Target) != null;
            });

            // ===== 2. 玩家是否在区域 =====
            RegisterCondition("PlayerInArea", (action) =>
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player == null) return false;
                if (action == null || string.IsNullOrEmpty(action.Value)) return false;
                try
                {
                    string[] parts = action.Value.Split(',');
                    if (parts.Length < 4) return false;
                    Vector3 center = new Vector3(
                        float.Parse(parts[0]),
                        float.Parse(parts[1]),
                        float.Parse(parts[2])
                    );
                    float radius = float.Parse(parts[3]);
                    return Vector3.Distance(player.transform.position, center) < radius;
                }
                catch { return false; }
            });

            // ===== 3. 玩家是否看向对象 =====
            RegisterCondition("PlayerLookingAt", (action) =>
            {
                GameObject player = GameObject.FindGameObjectWithTag("Player");
                if (player == null) return false;
                GameObject target = FindGameObject(action?.Target);
                if (target == null) return false;
                Vector3 direction = target.transform.position - player.transform.position;
                return Vector3.Angle(player.transform.forward, direction) < 30f;
            });

            // ===== 4. 对象是否在视线内 =====
            RegisterCondition("IsVisible", (action) =>
            {
                GameObject target = FindGameObject(action?.Target);
                if (target == null) return false;
                Camera cam = Camera.main;
                if (cam == null) return false;
                Vector3 viewport = cam.WorldToViewportPoint(target.transform.position);
                return viewport.x > 0 && viewport.x < 1 &&
                       viewport.y > 0 && viewport.y < 1 &&
                       viewport.z > 0;
            });

            // ===== 5. 区域内有对象 =====
            RegisterCondition("ObjectInRadius", (action) =>
            {
                GameObject target = FindGameObject(action?.Target);
                if (target == null) return false;
                if (action == null || string.IsNullOrEmpty(action.Value)) return false;
                try
                {
                    float radius = float.Parse(action.Value);
                    Collider[] colliders = Physics.OverlapSphere(target.transform.position, radius);
                    return colliders.Length > 0;
                }
                catch { return false; }
            });
        }

        // ============================================================
        // 资源查找辅助方法
        // ============================================================
        public static GameObject FindGameObject(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            GameObject obj = GameObject.Find(name);
            if (obj != null) return obj;
            GameObject[] all = Resources.FindObjectsOfTypeAll<GameObject>();
            foreach (var go in all)
            {
                if (go != null && go.name.ToLower().Contains(name.ToLower()) && !string.IsNullOrEmpty(go.scene.name))
                    return go;
            }
            return null;
        }

        public static AudioClip FindAudioClip(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            AudioClip[] clips = Resources.FindObjectsOfTypeAll<AudioClip>();
            foreach (var clip in clips)
            {
                if (clip != null && clip.name.ToLower().Contains(name.ToLower()))
                    return clip;
            }
            return null;
        }

        public static Texture2D FindTexture(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            Texture2D[] textures = Resources.FindObjectsOfTypeAll<Texture2D>();
            foreach (var tex in textures)
            {
                if (tex != null && tex.name.ToLower().Contains(name.ToLower()))
                    return tex;
            }
            return null;
        }

        public static Material FindMaterial(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            Material[] materials = Resources.FindObjectsOfTypeAll<Material>();
            foreach (var mat in materials)
            {
                if (mat != null && mat.name.ToLower().Contains(name.ToLower()))
                    return mat;
            }
            return null;
        }

        public static AnimationClip FindAnimationClip(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            AnimationClip[] clips = Resources.FindObjectsOfTypeAll<AnimationClip>();
            foreach (var clip in clips)
            {
                if (clip != null && clip.name.ToLower().Contains(name.ToLower()))
                    return clip;
            }
            return null;
        }

        // ============================================================
        // 扩展 LogicCondition 和 LogicAction 的执行
        // ============================================================
        public static bool CheckExtendedCondition(this LogicCondition condition)
        {
            if (condition.Type == ConditionType.Custom)
                return CheckCustomCondition(condition);
            return condition.Check();
        }

        public static void ExecuteExtendedAction(this LogicAction action)
        {
            if (action.Type == ActionType.Custom)
                ExecuteCustomAction(action);
            else
                action.Execute();
        }
    }
}
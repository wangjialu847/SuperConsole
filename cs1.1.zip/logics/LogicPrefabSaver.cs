﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace SuperConsole
{
    public static class LogicPrefabSaver
    {
        private static string prefabCachePath = Path.Combine(Paths.PluginPath, "SuperConsole", "PrefabCache");

        static LogicPrefabSaver()
        {
            if (!Directory.Exists(prefabCachePath))
                Directory.CreateDirectory(prefabCachePath);
        }

        /// <summary>
        /// 真正保存预制体到文件（使用二进制序列化 + 压缩）
        /// </summary>
        public static void SavePrefab(GameObject source, string logicFolderPath, string prefabName = "main")
        {
            if (source == null) return;

            string prefabDir = Path.Combine(logicFolderPath, "prefabs");
            if (!Directory.Exists(prefabDir))
                Directory.CreateDirectory(prefabDir);

            string path = Path.Combine(prefabDir, prefabName + ".prefab");

            // 1. 克隆对象（避免修改原对象）
            GameObject clone = UnityEngine.Object.Instantiate(source);
            clone.name = source.name;

            // 2. 清理组件（移除 MonoBehaviour 脚本，只保留核心组件）
            CleanComponents(clone);

            // 3. 提取 Mesh 数据
            ExtractMeshData(clone, logicFolderPath);

            // 4. 提取 Texture 数据
            ExtractTextureData(clone, logicFolderPath);

            // 5. 提取 Material 数据
            ExtractMaterialData(clone, logicFolderPath);

            // 6. 提取 Animation 数据
            ExtractAnimationData(clone, logicFolderPath);

            // 7. 保存为 .prefab 文本格式
            string prefabContent = SerializePrefab(clone);
            File.WriteAllText(path, prefabContent);

            // 8. 同时保存为二进制格式（备用）
            string binPath = Path.Combine(prefabDir, prefabName + ".prefab.bin");
            byte[] binData = SerializePrefabBinary(clone);
            File.WriteAllBytes(binPath, binData);

            // 9. 清理
            UnityEngine.Object.Destroy(clone);

            Debug.Log($"[LogicPrefabSaver] ✅ 预制体已保存: {path}");
        }

        /// <summary>
        /// 从文件加载预制体
        /// </summary>
        public static GameObject LoadPrefab(string logicFolderPath, string prefabName = "main")
        {
            string prefabDir = Path.Combine(logicFolderPath, "prefabs");
            string txtPath = Path.Combine(prefabDir, prefabName + ".prefab");
            string binPath = Path.Combine(prefabDir, prefabName + ".prefab.bin");

            GameObject obj = null;

            // 优先从二进制加载
            if (File.Exists(binPath))
            {
                try
                {
                    obj = DeserializePrefabBinary(binPath);
                    if (obj != null)
                    {
                        Debug.Log($"[LogicPrefabSaver] ✅ 从二进制加载预制体: {binPath}");
                        return obj;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[LogicPrefabSaver] ⚠️ 二进制加载失败: {ex.Message}");
                }
            }

            // 从文本加载
            if (File.Exists(txtPath))
            {
                try
                {
                    string content = File.ReadAllText(txtPath);
                    obj = DeserializePrefab(content);
                    if (obj != null)
                    {
                        Debug.Log($"[LogicPrefabSaver] ✅ 从文本加载预制体: {txtPath}");
                        return obj;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[LogicPrefabSaver] ⚠️ 文本加载失败: {ex.Message}");
                }
            }

            return null;
        }

        /// <summary>
        /// 清理组件（只保留核心组件）
        /// </summary>
        private static void CleanComponents(GameObject obj)
        {
            MonoBehaviour[] scripts = obj.GetComponentsInChildren<MonoBehaviour>(true);
            foreach (var script in scripts)
            {
                if (script is Transform) continue;
                if (script is MeshFilter) continue;
                if (script is MeshRenderer) continue;
                if (script is SkinnedMeshRenderer) continue;
                if (script is Collider) continue;
                if (script is Rigidbody) continue;
                if (script is Animation) continue;
                if (script is Animator) continue;
                if (script is AudioSource) continue;
                UnityEngine.Object.Destroy(script);
            }
        }

        /// <summary>
        /// 提取 Mesh 数据
        /// </summary>
        private static void ExtractMeshData(GameObject obj, string logicFolderPath)
        {
            string modelsDir = Path.Combine(logicFolderPath, "models");
            if (!Directory.Exists(modelsDir))
                Directory.CreateDirectory(modelsDir);

            MeshFilter[] filters = obj.GetComponentsInChildren<MeshFilter>(true);
            foreach (var filter in filters)
            {
                if (filter == null || filter.mesh == null) continue;
                string meshName = filter.mesh.name;
                if (string.IsNullOrEmpty(meshName) || meshName == "Mesh")
                    meshName = "mesh_" + Guid.NewGuid().ToString().Substring(0, 6);

                string path = Path.Combine(modelsDir, meshName + ".obj");
                string objContent = MeshToObj(filter.mesh);
                File.WriteAllText(path, objContent);
                Debug.Log($"[LogicPrefabSaver] 🎨 提取模型: {meshName} -> {path}");
            }

            SkinnedMeshRenderer[] skinned = obj.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in skinned)
            {
                if (smr == null || smr.sharedMesh == null) continue;
                string meshName = smr.sharedMesh.name;
                if (string.IsNullOrEmpty(meshName) || meshName == "Mesh")
                    meshName = "skinned_" + Guid.NewGuid().ToString().Substring(0, 6);

                string path = Path.Combine(modelsDir, meshName + ".obj");
                string objContent = MeshToObj(smr.sharedMesh);
                File.WriteAllText(path, objContent);
                Debug.Log($"[LogicPrefabSaver] 🎨 提取蒙皮模型: {meshName} -> {path}");
            }
        }

        /// <summary>
        /// 提取 Texture 数据
        /// </summary>
        private static void ExtractTextureData(GameObject obj, string logicFolderPath)
        {
            string texturesDir = Path.Combine(logicFolderPath, "textures");
            if (!Directory.Exists(texturesDir))
                Directory.CreateDirectory(texturesDir);

            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;
                foreach (var mat in renderer.sharedMaterials)
                {
                    if (mat == null || mat.mainTexture == null) continue;
                    Texture2D tex = mat.mainTexture as Texture2D;
                    if (tex == null) continue;

                    string texName = tex.name;
                    string path = Path.Combine(texturesDir, texName + ".png");
                    if (!File.Exists(path))
                    {
                        try
                        {
                            byte[] pngData = tex.EncodeToPNG();
                            if (pngData != null && pngData.Length > 0)
                            {
                                File.WriteAllBytes(path, pngData);
                                Debug.Log($"[LogicPrefabSaver] 🖼️ 提取纹理: {texName} -> {path}");
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.LogWarning($"[LogicPrefabSaver] ⚠️ 无法保存纹理 {texName}: {ex.Message}");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 提取 Material 数据
        /// </summary>
        private static void ExtractMaterialData(GameObject obj, string logicFolderPath)
        {
            string materialsDir = Path.Combine(logicFolderPath, "materials");
            if (!Directory.Exists(materialsDir))
                Directory.CreateDirectory(materialsDir);

            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;
                foreach (var mat in renderer.sharedMaterials)
                {
                    if (mat == null) continue;
                    string matName = mat.name;
                    string path = Path.Combine(materialsDir, matName + ".mat");
                    if (!File.Exists(path))
                    {
                        string content = SerializeMaterial(mat);
                        File.WriteAllText(path, content);
                        Debug.Log($"[LogicPrefabSaver] 🧪 提取材质: {matName} -> {path}");
                    }
                }
            }
        }

        /// <summary>
        /// 提取 Animation 数据
        /// </summary>
        private static void ExtractAnimationData(GameObject obj, string logicFolderPath)
        {
            string animationsDir = Path.Combine(logicFolderPath, "animations");
            if (!Directory.Exists(animationsDir))
                Directory.CreateDirectory(animationsDir);

            Animation anim = obj.GetComponent<Animation>();
            if (anim != null)
            {
                foreach (AnimationState state in anim)
                {
                    if (state == null || state.clip == null) continue;
                    string clipName = state.clip.name;
                    string path = Path.Combine(animationsDir, clipName + ".anim");
                    if (!File.Exists(path))
                    {
                        string content = SerializeAnimationClip(state.clip);
                        File.WriteAllText(path, content);
                        Debug.Log($"[LogicPrefabSaver] 🎬 提取动画: {clipName} -> {path}");
                    }
                }
            }
        }

        /// <summary>
        /// 序列化预制体为文本
        /// </summary>
        private static string SerializePrefab(GameObject obj)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine($"# SuperConsole Prefab Export");
            sb.AppendLine($"# Object: {obj.name}");
            sb.AppendLine($"# Time: {DateTime.Now}");
            sb.AppendLine($"---");

            // 递归序列化层级
            SerializeTransform(obj.transform, sb, 0);

            return sb.ToString();
        }

        private static void SerializeTransform(Transform t, System.Text.StringBuilder sb, int depth)
        {
            string indent = new string(' ', depth * 2);
            GameObject obj = t.gameObject;

            sb.AppendLine($"{indent}GameObject:");
            sb.AppendLine($"{indent}  name: {obj.name}");
            sb.AppendLine($"{indent}  tag: {obj.tag}");
            sb.AppendLine($"{indent}  layer: {obj.layer}");
            sb.AppendLine($"{indent}  active: {obj.activeSelf}");
            sb.AppendLine($"{indent}  position: {t.position.x:F4}, {t.position.y:F4}, {t.position.z:F4}");
            sb.AppendLine($"{indent}  rotation: {t.rotation.eulerAngles.x:F2}, {t.rotation.eulerAngles.y:F2}, {t.rotation.eulerAngles.z:F2}");
            sb.AppendLine($"{indent}  scale: {t.localScale.x:F4}, {t.localScale.y:F4}, {t.localScale.z:F4}");

            // 组件列表
            Component[] comps = obj.GetComponents<Component>();
            if (comps.Length > 1)
            {
                sb.AppendLine($"{indent}  components:");
                foreach (var comp in comps)
                {
                    if (comp is Transform) continue;
                    sb.AppendLine($"{indent}    - {comp.GetType().Name}");
                }
            }

            // 子对象
            if (t.childCount > 0)
            {
                sb.AppendLine($"{indent}  children:");
                foreach (Transform child in t)
                {
                    SerializeTransform(child, sb, depth + 2);
                }
            }
        }

        /// <summary>
        /// 从文本反序列化预制体
        /// </summary>
        private static GameObject DeserializePrefab(string content)
        {
            string[] lines = content.Split('\n');
            GameObject root = null;
            Dictionary<int, GameObject> depthMap = new Dictionary<int, GameObject>();

            int currentDepth = 0;
            GameObject currentObj = null;

            foreach (string line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrEmpty(trimmed) || trimmed.StartsWith("#")) continue;

                // 计算缩进深度
                int depth = 0;
                foreach (char c in line)
                {
                    if (c == ' ') depth++;
                    else break;
                }
                depth /= 2;

                // 解析键值对
                string[] parts = trimmed.Split(':');
                if (parts.Length < 2) continue;

                string key = parts[0].Trim();
                string value = parts[1].Trim();

                if (key == "GameObject")
                {
                    // 创建对象
                    GameObject obj = new GameObject();

                    if (depth == 0)
                    {
                        root = obj;
                        currentObj = obj;
                    }
                    else
                    {
                        // 找到父对象
                        if (depthMap.ContainsKey(depth - 1))
                        {
                            GameObject parent = depthMap[depth - 1];
                            obj.transform.SetParent(parent.transform);
                        }
                    }

                    depthMap[depth] = obj;
                    currentObj = obj;
                    currentDepth = depth;
                }
                else if (currentObj != null)
                {
                    switch (key)
                    {
                        case "name":
                            currentObj.name = value;
                            break;
                        case "tag":
                            currentObj.tag = value;
                            break;
                        case "layer":
                            int.TryParse(value, out int layer);
                            currentObj.layer = layer;
                            break;
                        case "active":
                            bool.TryParse(value, out bool active);
                            currentObj.SetActive(active);
                            break;
                        case "position":
                            string[] pos = value.Split(',');
                            if (pos.Length >= 3)
                            {
                                float.TryParse(pos[0].Trim(), out float x);
                                float.TryParse(pos[1].Trim(), out float y);
                                float.TryParse(pos[2].Trim(), out float z);
                                currentObj.transform.position = new Vector3(x, y, z);
                            }
                            break;
                        case "rotation":
                            string[] rot = value.Split(',');
                            if (rot.Length >= 3)
                            {
                                float.TryParse(rot[0].Trim(), out float x);
                                float.TryParse(rot[1].Trim(), out float y);
                                float.TryParse(rot[2].Trim(), out float z);
                                currentObj.transform.rotation = Quaternion.Euler(x, y, z);
                            }
                            break;
                        case "scale":
                            string[] sca = value.Split(',');
                            if (sca.Length >= 3)
                            {
                                float.TryParse(sca[0].Trim(), out float x);
                                float.TryParse(sca[1].Trim(), out float y);
                                float.TryParse(sca[2].Trim(), out float z);
                                currentObj.transform.localScale = new Vector3(x, y, z);
                            }
                            break;
                    }
                }
            }

            return root;
        }

        /// <summary>
        /// 二进制序列化预制体
        /// </summary>
        private static byte[] SerializePrefabBinary(GameObject obj)
        {
            using (var ms = new MemoryStream())
            using (var writer = new BinaryWriter(ms))
            {
                SerializeTransformBinary(obj.transform, writer);
                return ms.ToArray();
            }
        }

        private static void SerializeTransformBinary(Transform t, BinaryWriter writer)
        {
            GameObject obj = t.gameObject;
            writer.Write(obj.name ?? "");
            writer.Write(obj.tag ?? "");
            writer.Write(obj.layer);
            writer.Write(obj.activeSelf);
            writer.Write(t.position.x);
            writer.Write(t.position.y);
            writer.Write(t.position.z);
            writer.Write(t.rotation.eulerAngles.x);
            writer.Write(t.rotation.eulerAngles.y);
            writer.Write(t.rotation.eulerAngles.z);
            writer.Write(t.localScale.x);
            writer.Write(t.localScale.y);
            writer.Write(t.localScale.z);

            int childCount = t.childCount;
            writer.Write(childCount);
            foreach (Transform child in t)
            {
                SerializeTransformBinary(child, writer);
            }
        }

        /// <summary>
        /// 从二进制反序列化预制体
        /// </summary>
        private static GameObject DeserializePrefabBinary(string path)
        {
            byte[] data = File.ReadAllBytes(path);
            using (var ms = new MemoryStream(data))
            using (var reader = new BinaryReader(ms))
            {
                return DeserializeTransformBinary(null, reader);
            }
        }

        private static GameObject DeserializeTransformBinary(Transform parent, BinaryReader reader)
        {
            string name = reader.ReadString();
            string tag = reader.ReadString();
            int layer = reader.ReadInt32();
            bool active = reader.ReadBoolean();
            float px = reader.ReadSingle();
            float py = reader.ReadSingle();
            float pz = reader.ReadSingle();
            float rx = reader.ReadSingle();
            float ry = reader.ReadSingle();
            float rz = reader.ReadSingle();
            float sx = reader.ReadSingle();
            float sy = reader.ReadSingle();
            float sz = reader.ReadSingle();

            GameObject obj = new GameObject(name);
            obj.tag = tag;
            obj.layer = layer;
            obj.SetActive(active);

            if (parent != null)
                obj.transform.SetParent(parent);

            obj.transform.position = new Vector3(px, py, pz);
            obj.transform.rotation = Quaternion.Euler(rx, ry, rz);
            obj.transform.localScale = new Vector3(sx, sy, sz);

            int childCount = reader.ReadInt32();
            for (int i = 0; i < childCount; i++)
            {
                DeserializeTransformBinary(obj.transform, reader);
            }

            return obj;
        }

        /// <summary>
        /// Mesh 转 OBJ
        /// </summary>
        private static string MeshToObj(Mesh mesh)
        {
            if (mesh == null) return "";
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine($"# Extracted by SuperConsole");
            sb.AppendLine($"# Mesh: {mesh.name}");

            foreach (Vector3 v in mesh.vertices)
                sb.AppendLine($"v {v.x:F6} {v.y:F6} {v.z:F6}");

            if (mesh.uv.Length > 0)
                foreach (Vector2 uv in mesh.uv)
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");

            foreach (Vector3 n in mesh.normals)
                sb.AppendLine($"vn {n.x:F6} {n.y:F6} {n.z:F6}");

            int[] triangles = mesh.triangles;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int v1 = triangles[i] + 1;
                int v2 = triangles[i + 1] + 1;
                int v3 = triangles[i + 2] + 1;
                if (mesh.uv.Length > 0)
                    sb.AppendLine($"f {v1}/{v1} {v2}/{v2} {v3}/{v3}");
                else
                    sb.AppendLine($"f {v1} {v2} {v3}");
            }
            return sb.ToString();
        }

        /// <summary>
        /// 序列化材质
        /// </summary>
        private static string SerializeMaterial(Material mat)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine($"# SuperConsole Material Export");
            sb.AppendLine($"# Material: {mat.name}");
            sb.AppendLine($"shader: {mat.shader?.name ?? "Standard"}");
            sb.AppendLine($"renderQueue: {mat.renderQueue}");

            if (mat.HasProperty("_Color"))
            {
                Color c = mat.GetColor("_Color");
                sb.AppendLine($"color: {c.r:F4}, {c.g:F4}, {c.b:F4}, {c.a:F4}");
            }
            if (mat.HasProperty("_MainTex") && mat.mainTexture != null)
            {
                sb.AppendLine($"mainTexture: {mat.mainTexture.name}");
            }
            if (mat.HasProperty("_Metallic"))
                sb.AppendLine($"metallic: {mat.GetFloat("_Metallic"):F4}");
            if (mat.HasProperty("_Glossiness"))
                sb.AppendLine($"smoothness: {mat.GetFloat("_Glossiness"):F4}");
            return sb.ToString();
        }

        /// <summary>
        /// 序列化动画剪辑
        /// </summary>
        private static string SerializeAnimationClip(AnimationClip clip)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine($"# SuperConsole Animation Export");
            sb.AppendLine($"# Clip: {clip.name}");
            sb.AppendLine($"frameRate: {clip.frameRate:F2}");
            sb.AppendLine($"length: {clip.length:F4}");
            sb.AppendLine($"loop: {clip.isLooping}");
            sb.AppendLine($"events: {clip.events.Length}");

            foreach (var evt in clip.events)
            {
                sb.AppendLine($"  event: {evt.time:F4} | {evt.functionName} | {evt.stringParameter} | {evt.floatParameter:F4}");
            }
            return sb.ToString();
        }
    }
}
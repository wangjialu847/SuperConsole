﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SuperConsole
{
    public static class LogicUI
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 750, 600);
        private static Vector2 scrollPos = Vector2.zero;
        private static Vector2 condScroll = Vector2.zero;
        private static Vector2 actionScroll = Vector2.zero;

        // ===== 当前编辑 =====
        private static LogicEntity editingLogic = null;
        private static int selectedCond = -1;
        private static int selectedAction = -1;

        // ===== 获取窗口位置用于焦点检测 =====
        public static Rect GetWindowRect()
        {
            return windowRect;
        }

        // ===== 重置位置 =====
        public static void ResetPosition()
        {
            windowRect = new Rect(100, 100, 750, 600);
        }

        public static void Toggle()
        {
            visible = !visible;
            if (visible && editingLogic == null && LogicManager.GetAll().Count > 0)
                editingLogic = LogicManager.GetAll()[0];
        }

        public static bool IsVisible() => visible;

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12352);
            windowRect = GUI.Window(12352, windowRect, DrawWindow, "🧠 逻辑体编辑器 [Esc关闭]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            GUILayout.BeginVertical();

            DrawToolbar();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (editingLogic == null)
            {
                GUILayout.Label("没有逻辑体，点击「新建」创建");
                GUILayout.EndVertical();
                GUI.DragWindow();
                return;
            }

            DrawBasicSettings();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal(GUILayout.ExpandHeight(true));

            DrawConditionPanel();
            GUILayout.Box("", GUILayout.Width(2), GUILayout.ExpandHeight(true));
            DrawActionPanel();

            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            DrawFooter();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private static void DrawToolbar()
        {
            GUILayout.BeginHorizontal();

            var all = LogicManager.GetAll();
            string[] names = all.Select(l => l.Name).ToArray();
            int idx = editingLogic != null ? Array.IndexOf(names, editingLogic.Name) : -1;
            if (idx < 0 && names.Length > 0) idx = 0;

            GUILayout.Label("📋 逻辑体:", GUILayout.Width(65));

            int newIdx = GUILayout.SelectionGrid(
                idx >= 0 ? idx : 0,
                names.Length > 0 ? names : new string[] { "(无)" },
                5,
                GUILayout.ExpandWidth(true)
            );

            if (newIdx >= 0 && newIdx < names.Length && (editingLogic == null || editingLogic.Name != names[newIdx]))
                editingLogic = LogicManager.Get(names[newIdx]);

            if (GUILayout.Button("➕ 新建", GUILayout.Width(50)))
            {
                var l = new LogicEntity { Name = "逻辑体_" + (all.Count + 1) };
                LogicManager.Register(l);
                editingLogic = l;
            }

            GUILayout.EndHorizontal();
        }

        private static void DrawBasicSettings()
        {
            GUILayout.BeginHorizontal();

            GUILayout.Label("名称:", GUILayout.Width(35));
            GUI.SetNextControlName("logicName");
            string n = GUILayout.TextField(editingLogic.Name, GUILayout.Width(140));
            if (n != editingLogic.Name) editingLogic.Name = n;

            GUILayout.Label("触发:", GUILayout.Width(35));
            string[] triggers = Enum.GetNames(typeof(TriggerType));
            int ti = Array.IndexOf(triggers, editingLogic.Trigger.ToString());
            int nt = GUILayout.SelectionGrid(ti >= 0 ? ti : 0, triggers, 6, GUILayout.ExpandWidth(true));
            if (nt >= 0) editingLogic.Trigger = (TriggerType)nt;

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();

            GUILayout.Label("描述:", GUILayout.Width(35));
            GUI.SetNextControlName("logicDesc");
            editingLogic.Description = GUILayout.TextField(editingLogic.Description, GUILayout.ExpandWidth(true));

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();

            GUI.color = editingLogic.Enabled ? Color.green : Color.gray;
            GUILayout.Label(editingLogic.Enabled ? "▶ 运行中" : "⏸ 已暂停", GUILayout.Width(70));
            GUI.color = Color.white;

            if (GUILayout.Button(editingLogic.Enabled ? "⏸ 暂停" : "▶ 启动", GUILayout.Width(55)))
            {
                if (editingLogic.Enabled) editingLogic.Stop();
                else editingLogic.Start();
            }

            if (GUILayout.Button("▶ 执行一次", GUILayout.Width(60)))
                editingLogic.Execute();

            if (GUILayout.Button("💾 保存", GUILayout.Width(50)))
                LogicManager.Save(editingLogic);

            if (GUILayout.Button("🗑 删除", GUILayout.Width(50)))
            {
                LogicManager.Unregister(editingLogic.Name);
                var list = LogicManager.GetAll();
                editingLogic = list.Count > 0 ? list[0] : null;
            }

            GUILayout.EndHorizontal();
        }

        private static void DrawConditionPanel()
        {
            GUILayout.BeginVertical(GUILayout.Width(350));

            GUILayout.BeginHorizontal();
            GUILayout.Label($"📋 条件 ({editingLogic.Conditions.Count})", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("➕ 添加", GUILayout.Width(50)))
            {
                editingLogic.Conditions.Add(new LogicCondition());
                selectedCond = editingLogic.Conditions.Count - 1;
            }
            GUILayout.EndHorizontal();

            condScroll = GUILayout.BeginScrollView(condScroll, GUILayout.ExpandHeight(true));

            for (int i = 0; i < editingLogic.Conditions.Count; i++)
            {
                var c = editingLogic.Conditions[i];
                bool isSelected = (selectedCond == i);

                GUILayout.BeginVertical("box");

                GUILayout.BeginHorizontal();
                if (GUILayout.Button(isSelected ? "▼" : "▶", GUILayout.Width(20)))
                    selectedCond = isSelected ? -1 : i;

                GUILayout.Label(c.GetDisplayText(), GUILayout.ExpandWidth(true));

                if (GUILayout.Button("✖", GUILayout.Width(20)))
                {
                    editingLogic.Conditions.RemoveAt(i);
                    selectedCond = -1;
                    break;
                }
                GUILayout.EndHorizontal();

                if (isSelected)
                {
                    GUILayout.BeginVertical("box");

                    string[] types = Enum.GetNames(typeof(ConditionType));
                    int ci = Array.IndexOf(types, c.Type.ToString());
                    int nc = GUILayout.SelectionGrid(ci >= 0 ? ci : 0, types, 4, GUILayout.ExpandWidth(true));
                    if (nc >= 0) c.Type = (ConditionType)nc;

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("目标:", GUILayout.Width(30));
                    GUI.SetNextControlName("condTarget_" + i);
                    c.Target = GUILayout.TextField(c.Target, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("操作:", GUILayout.Width(30));
                    GUI.SetNextControlName("condOp_" + i);
                    c.Operator = GUILayout.TextField(c.Operator, GUILayout.Width(40));
                    GUILayout.Label("值:", GUILayout.Width(20));
                    GUI.SetNextControlName("condVal_" + i);
                    c.Value = GUILayout.TextField(c.Value, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    if (c.Type == ConditionType.Custom)
                    {
                        GUILayout.Label("自定义代码:");
                        GUI.SetNextControlName("condCode_" + i);
                        c.CustomCode = GUILayout.TextArea(c.CustomCode, GUILayout.Height(30));
                    }

                    GUILayout.EndVertical();
                }

                GUILayout.EndVertical();
                GUILayout.Space(2);
            }

            GUILayout.EndScrollView();
            GUILayout.EndVertical();
        }

        private static void DrawActionPanel()
        {
            GUILayout.BeginVertical(GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label($"⚡ 动作 ({editingLogic.Actions.Count})", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("➕ 添加", GUILayout.Width(50)))
            {
                editingLogic.Actions.Add(new LogicAction());
                selectedAction = editingLogic.Actions.Count - 1;
            }
            GUILayout.EndHorizontal();

            actionScroll = GUILayout.BeginScrollView(actionScroll, GUILayout.ExpandHeight(true));

            for (int i = 0; i < editingLogic.Actions.Count; i++)
            {
                var a = editingLogic.Actions[i];
                bool isSelected = (selectedAction == i);

                GUILayout.BeginVertical("box");

                GUILayout.BeginHorizontal();
                if (GUILayout.Button(isSelected ? "▼" : "▶", GUILayout.Width(20)))
                    selectedAction = isSelected ? -1 : i;

                GUILayout.Label(a.GetDisplayText(), GUILayout.ExpandWidth(true));

                if (GUILayout.Button("✖", GUILayout.Width(20)))
                {
                    editingLogic.Actions.RemoveAt(i);
                    selectedAction = -1;
                    break;
                }
                GUILayout.EndHorizontal();

                if (isSelected)
                {
                    GUILayout.BeginVertical("box");

                    string[] types = Enum.GetNames(typeof(ActionType));
                    int ai = Array.IndexOf(types, a.Type.ToString());
                    int na = GUILayout.SelectionGrid(ai >= 0 ? ai : 0, types, 4, GUILayout.ExpandWidth(true));
                    if (na >= 0) a.Type = (ActionType)na;

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("目标:", GUILayout.Width(30));
                    GUI.SetNextControlName("actTarget_" + i);
                    a.Target = GUILayout.TextField(a.Target, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("值:", GUILayout.Width(20));
                    GUI.SetNextControlName("actVal_" + i);
                    a.Value = GUILayout.TextField(a.Value, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    if (a.Type == ActionType.Custom)
                    {
                        GUILayout.Label("自定义代码:");
                        GUI.SetNextControlName("actCode_" + i);
                        a.CustomCode = GUILayout.TextArea(a.CustomCode, GUILayout.Height(30));
                    }

                    GUILayout.EndVertical();
                }

                GUILayout.EndVertical();
                GUILayout.Space(2);
            }

            GUILayout.EndScrollView();
            GUILayout.EndVertical();
        }

        private static void DrawFooter()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("💡 格式: GameObject.Component.field (例: Player.PlayerCharacter.health)", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("关闭", GUILayout.Width(50))) visible = false;
            GUILayout.EndHorizontal();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace SuperConsole
{
    /// <summary>
    /// 3D 预览窗口 — 真正的3D渲染
    /// </summary>
    public static class LogicPreview3D
    {
        // ===== 窗口状态 =====
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 900, 700);
        private static Vector2 scrollPos = Vector2.zero;
        private static Vector2 colliderScrollPos = Vector2.zero;

        // ===== 预览对象 =====
        private static GameObject previewObject = null;
        private static LogicEntityV2 currentLogic = null;

        // ===== 3D 相机 =====
        private static Camera previewCamera = null;
        private static RenderTexture previewRT = null;
        private static GameObject cameraObject = null;
        private static int previewLayer = 31;

        // ===== 相机控制 =====
        private static float camDistance = 5f;
        private static float camRotationX = 30f;
        private static float camRotationY = 45f;
        private static Vector3 targetPosition = Vector3.zero;
        private static bool isDragging = false;
        private static Vector2 lastMousePos;

        // ===== 显示选项 =====
        private static bool showModel = true;
        private static bool showBones = true;
        private static bool showColliders = true;
        private static bool showGrid = true;
        private static bool showAxes = true;
        private static Color boneColor = Color.cyan;
        private static Color[] boneColors = new Color[] { Color.cyan, Color.red, Color.green, Color.yellow, Color.magenta };

        // ===== 骨骼编辑 =====
        private static List<BoneEditData> bones = new List<BoneEditData>();
        private static int selectedBoneIndex = -1;
        private static int editMode = 0;
        private static string posX = "0", posY = "0", posZ = "0";
        private static string rotX = "0", rotY = "0", rotZ = "0";
        private static string scaleX = "1", scaleY = "1", scaleZ = "1";
        private static string poseName = "";

        // ===== 碰撞箱编辑 =====
        private static List<ColliderEditData> colliders = new List<ColliderEditData>();
        private static int selectedColliderIndex = -1;
        private static string[] colliderTypes = { "Box", "Sphere", "Capsule" };

        // ===== 骨骼可视化对象 =====
        private static List<GameObject> boneMarkers = new List<GameObject>();
        private static List<LineRenderer> boneLines = new List<LineRenderer>();
        private static List<GameObject> colliderVisuals = new List<GameObject>();

        // ===== 数据类 =====
        public class BoneEditData
        {
            public string name;
            public Transform transform;
            public Vector3 localPosition;
            public Quaternion localRotation;
            public Vector3 localScale;
            public Vector3 originalPosition;
            public Quaternion originalRotation;
            public Vector3 originalScale;
        }

        public class ColliderEditData
        {
            public string name;
            public string type;
            public bool enabled;
            public Vector3 center;
            public Vector3 size;
            public float radius;
            public float height;
            public int direction;
        }

        // ===== 显示/隐藏 =====
        public static void Toggle(LogicEntityV2 logic)
        {
            if (logic == null) return;

            if (visible && currentLogic == logic)
            {
                visible = false;
                CleanupPreview();
                return;
            }

            currentLogic = logic;
            visible = true;
            LoadPreview(logic);
        }

        public static bool IsVisible() => visible;
        public static void ResetPosition() => windowRect = new Rect(100, 100, 900, 700);

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12361);
            windowRect = GUI.Window(12361, windowRect, DrawWindow, "🎮 3D 预览 — " + (currentLogic?.name ?? "无"));
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                CleanupPreview();
                return;
            }

            GUILayout.BeginVertical();

            // ===== 工具栏 =====
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("🔄 重置视角", GUILayout.Width(80)))
            {
                camDistance = 5f;
                camRotationX = 30f;
                camRotationY = 45f;
                targetPosition = Vector3.zero;
                UpdateCamera();
            }
            if (GUILayout.Button("🎯 聚焦对象", GUILayout.Width(80)))
            {
                if (previewObject != null)
                    targetPosition = previewObject.transform.position;
                UpdateCamera();
            }
            if (GUILayout.Button("✖", GUILayout.Width(25)))
            {
                visible = false;
                CleanupPreview();
                return;
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 3D 场景 =====
            Rect sceneRect = GUILayoutUtility.GetRect(200, 350, GUILayout.ExpandWidth(true));
            DrawScene(sceneRect);

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 显示选项 =====
            DrawDisplayOptions();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 骨骼编辑 =====
            DrawBoneEditor();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 碰撞箱编辑 =====
            DrawColliderEditor();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 底部按钮 =====
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("💾 保存修改", GUILayout.Height(25)))
            {
                SaveChanges();
            }
            if (GUILayout.Button("🚀 应用到对象", GUILayout.Height(25)))
            {
                ApplyToObject();
            }
            if (GUILayout.Button("📦 导出为逻辑体", GUILayout.Height(25)))
            {
                ExportAsLogic();
            }
            if (GUILayout.Button("✖ 关闭", GUILayout.Height(25)))
            {
                visible = false;
                CleanupPreview();
            }
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        // ============================================================
        // 3D 场景绘制（真正的3D渲染）
        // ============================================================
        private static void InitCamera(Rect rect)
        {
            if (cameraObject == null)
            {
                cameraObject = new GameObject("PreviewCamera");
                cameraObject.hideFlags = HideFlags.HideAndDontSave;
                previewCamera = cameraObject.AddComponent<Camera>();
                previewCamera.clearFlags = CameraClearFlags.Skybox;
                previewCamera.backgroundColor = new Color(0.2f, 0.2f, 0.25f);
                previewCamera.nearClipPlane = 0.1f;
                previewCamera.farClipPlane = 100f;
                previewCamera.fieldOfView = 60f;
            }

            // 创建/更新 RenderTexture
            int w = Mathf.Max(1, (int)rect.width);
            int h = Mathf.Max(1, (int)rect.height);

            if (previewRT == null || previewRT.width != w || previewRT.height != h)
            {
                if (previewRT != null)
                {
                    previewRT.Release();
                    UnityEngine.Object.DestroyImmediate(previewRT);
                }
                previewRT = new RenderTexture(w, h, 24);
                previewRT.antiAliasing = 4;
                previewRT.Create();
                previewCamera.targetTexture = previewRT;
            }

            // 设置相机位置
            UpdateCamera();

            // 设置预览对象层级
            if (previewObject != null)
            {
                SetLayerRecursive(previewObject, previewLayer);
                previewCamera.cullingMask = 1 << previewLayer;
            }
            else
            {
                previewCamera.cullingMask = 0;
            }

            // 添加网格辅助线（用 GameObject）
            CreateGridHelper();
        }

        private static void UpdateCamera()
        {
            if (previewCamera == null) return;

            Vector3 targetPos = previewObject != null ? previewObject.transform.position : Vector3.zero;
            Vector3 camPos = targetPos + Quaternion.Euler(camRotationX, camRotationY, 0) * new Vector3(0, 0, -camDistance);

            previewCamera.transform.position = camPos;
            previewCamera.transform.LookAt(targetPos);
        }

        private static void SetLayerRecursive(GameObject obj, int layer)
        {
            if (obj == null) return;
            obj.layer = layer;
            foreach (Transform child in obj.transform)
                SetLayerRecursive(child.gameObject, layer);
        }

        private static GameObject gridHelper = null;

        private static void CreateGridHelper()
        {
            if (gridHelper == null)
            {
                gridHelper = GameObject.CreatePrimitive(PrimitiveType.Cube);
                gridHelper.name = "GridHelper";
                gridHelper.hideFlags = HideFlags.HideAndDontSave;
                gridHelper.transform.localScale = new Vector3(10, 0.01f, 10);

                Renderer renderer = gridHelper.GetComponent<Renderer>();
                if (renderer != null)
                {
                    Material mat = new Material(Shader.Find("Sprites/Default"));
                    mat.color = new Color(0.3f, 0.3f, 0.35f, 0.3f);
                    renderer.material = mat;
                }

                Collider collider = gridHelper.GetComponent<Collider>();
                if (collider != null) UnityEngine.Object.Destroy(collider);

                // 添加网格线
                for (int i = -5; i <= 5; i++)
                {
                    CreateGridLine(new Vector3(i, 0, -5), new Vector3(i, 0, 5), new Color(0.3f, 0.3f, 0.35f, 0.5f));
                    CreateGridLine(new Vector3(-5, 0, i), new Vector3(5, 0, i), new Color(0.3f, 0.3f, 0.35f, 0.5f));
                }
            }

            if (gridHelper != null && previewObject != null)
            {
                gridHelper.transform.position = new Vector3(
                    Mathf.Floor(previewObject.transform.position.x / 10) * 10,
                    0,
                    Mathf.Floor(previewObject.transform.position.z / 10) * 10
                );
                gridHelper.layer = previewLayer;
            }
        }

        private static void CreateGridLine(Vector3 start, Vector3 end, Color color)
        {
            GameObject line = new GameObject("GridLine");
            line.hideFlags = HideFlags.HideAndDontSave;
            LineRenderer lr = line.AddComponent<LineRenderer>();
            lr.material = new Material(Shader.Find("Sprites/Default"));
            lr.startColor = color;
            lr.endColor = color;
            lr.startWidth = 0.02f;
            lr.endWidth = 0.02f;
            lr.positionCount = 2;
            lr.SetPosition(0, start);
            lr.SetPosition(1, end);
            lr.useWorldSpace = true;
            if (gridHelper != null) line.transform.SetParent(gridHelper.transform);
        }

        private static void DrawScene(Rect rect)
        {
            if (Event.current.type == EventType.Repaint)
            {
                if (previewObject != null)
                {
                    InitCamera(rect);
                    previewCamera.Render();

                    // 显示渲染结果
                    if (previewRT != null)
                    {
                        GUI.DrawTexture(rect, previewRT);
                    }
                }
                else
                {
                    GUI.Box(rect, "无预览对象\n\n请先选择一个逻辑体");
                }
            }

            HandleCameraControl(rect);
        }

        private static void HandleCameraControl(Rect rect)
        {
            if (!rect.Contains(Event.current.mousePosition)) return;

            if (Event.current.type == EventType.MouseDown && Event.current.button == 0)
            {
                isDragging = true;
                lastMousePos = Event.current.mousePosition;
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseDrag && isDragging)
            {
                Vector2 delta = Event.current.mousePosition - lastMousePos;
                camRotationY += delta.x * 0.5f;
                camRotationX += delta.y * 0.5f;
                camRotationX = Mathf.Clamp(camRotationX, -89f, 89f);
                lastMousePos = Event.current.mousePosition;
                UpdateCamera();
                Event.current.Use();
            }

            if (Event.current.type == EventType.MouseUp && Event.current.button == 0)
            {
                isDragging = false;
                Event.current.Use();
            }

            if (Event.current.type == EventType.ScrollWheel && rect.Contains(Event.current.mousePosition))
            {
                camDistance -= Event.current.delta.y * 0.3f;
                camDistance = Mathf.Max(0.5f, Mathf.Min(30f, camDistance));
                UpdateCamera();
                Event.current.Use();
            }
        }

        // ============================================================
        // 加载预览
        // ============================================================
        private static void LoadPreview(LogicEntityV2 logic)
        {
            CleanupPreview();

            // 从预制体加载
            GameObject prefab = LogicPrefabSaver.LoadPrefab(logic.FolderPath, "main");
            if (prefab == null)
            {
                // 尝试从模型加载
                if (!string.IsNullOrEmpty(logic.resources.Model))
                {
                    Mesh mesh = LogicResourceLoader.LoadMesh(logic.resources.Model, logic.FolderPath);
                    if (mesh != null)
                    {
                        prefab = new GameObject("Preview_Model");
                        MeshFilter filter = prefab.AddComponent<MeshFilter>();
                        filter.mesh = mesh;
                        MeshRenderer renderer = prefab.AddComponent<MeshRenderer>();
                        renderer.material = new Material(Shader.Find("Standard"));
                    }
                }
            }

            if (prefab == null)
            {
                prefab = GameObject.CreatePrimitive(PrimitiveType.Cube);
                prefab.name = "Preview_Placeholder";
            }

            previewObject = UnityEngine.Object.Instantiate(prefab);
            previewObject.name = "Preview_" + logic.name;

            LoadBones(previewObject);
            LoadColliders(previewObject);

            targetPosition = previewObject.transform.position;

            // 移除所有 Collider 避免干扰
            foreach (var collider in previewObject.GetComponentsInChildren<Collider>())
            {
                if (collider != null) UnityEngine.Object.Destroy(collider);
            }

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
            {
                UpdateBoneEditFields(bones[selectedBoneIndex]);
            }

            // 初始化相机
            if (previewCamera != null) UpdateCamera();
        }

        private static void LoadBones(GameObject obj)
        {
            bones.Clear();
            foreach (var t in obj.GetComponentsInChildren<Transform>())
            {
                if (t == obj.transform) continue;
                bones.Add(new BoneEditData
                {
                    name = t.name,
                    transform = t,
                    localPosition = t.localPosition,
                    localRotation = t.localRotation,
                    localScale = t.localScale,
                    originalPosition = t.localPosition,
                    originalRotation = t.localRotation,
                    originalScale = t.localScale
                });
            }
        }

        private static void LoadColliders(GameObject obj)
        {
            colliders.Clear();
            foreach (var collider in obj.GetComponentsInChildren<Collider>())
            {
                var data = new ColliderEditData { name = collider.name, enabled = collider.enabled };

                if (collider is BoxCollider box)
                {
                    data.type = "Box";
                    data.center = box.center;
                    data.size = box.size;
                }
                else if (collider is SphereCollider sphere)
                {
                    data.type = "Sphere";
                    data.center = sphere.center;
                    data.radius = sphere.radius;
                }
                else if (collider is CapsuleCollider capsule)
                {
                    data.type = "Capsule";
                    data.center = capsule.center;
                    data.radius = capsule.radius;
                    data.height = capsule.height;
                    data.direction = capsule.direction;
                }
                else
                {
                    continue;
                }

                colliders.Add(data);
            }
        }

        // ============================================================
        // 显示选项
        // ============================================================
        private static void DrawDisplayOptions()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("显示:", GUILayout.Width(35));
            showModel = GUILayout.Toggle(showModel, "🎨 模型", GUILayout.Width(70));
            showBones = GUILayout.Toggle(showBones, "🦴 骨骼", GUILayout.Width(70));
            showColliders = GUILayout.Toggle(showColliders, "🎯 碰撞箱", GUILayout.Width(80));
            showGrid = GUILayout.Toggle(showGrid, "📐 网格", GUILayout.Width(70));
            showAxes = GUILayout.Toggle(showAxes, "🧭 轴", GUILayout.Width(60));

            GUILayout.Label("骨骼颜色:", GUILayout.Width(60));
            for (int i = 0; i < boneColors.Length; i++)
            {
                Color originalColor = GUI.color;
                GUI.color = boneColors[i];
                if (GUILayout.Button("", GUILayout.Width(20), GUILayout.Height(20)))
                {
                    boneColor = boneColors[i];
                    UpdateBoneColors();
                }
                GUI.color = originalColor;
            }
            GUILayout.EndHorizontal();
        }

        private static void UpdateBoneColors()
        {
            foreach (var line in boneLines)
            {
                if (line != null)
                {
                    line.startColor = boneColor;
                    line.endColor = boneColor;
                }
            }
            foreach (var marker in boneMarkers)
            {
                if (marker != null)
                {
                    Renderer r = marker.GetComponent<Renderer>();
                    if (r != null) r.material.color = boneColor;
                }
            }
        }

        // ============================================================
        // 骨骼编辑器
        // ============================================================
        private static void DrawBoneEditor()
        {
            GUILayout.Label($"🦴 骨骼列表 ({bones.Count})", GUILayout.ExpandWidth(true));

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(120));

            for (int i = 0; i < bones.Count; i++)
            {
                var bone = bones[i];
                if (bone == null) continue;

                GUILayout.BeginHorizontal();

                string indent = "";
                Transform current = bone.transform;
                int depth = 0;
                while (current != null && current.parent != null && current.parent != previewObject?.transform)
                {
                    indent += "  ";
                    current = current.parent;
                    depth++;
                }
                GUILayout.Label(indent, GUILayout.Width(Mathf.Min(depth * 12, 60)));

                if (i == selectedBoneIndex)
                    GUI.backgroundColor = new Color(0.3f, 0.5f, 0.8f);

                if (GUILayout.Button(bone.name, GUILayout.ExpandWidth(true)))
                {
                    selectedBoneIndex = i;
                    UpdateBoneEditFields(bone);
                }

                GUI.backgroundColor = Color.white;

                if (GUILayout.Button("🔦", GUILayout.Width(25)))
                {
                    HighlightBone(bone);
                }

                GUILayout.EndHorizontal();
            }

            GUILayout.EndScrollView();

            if (selectedBoneIndex >= 0 && selectedBoneIndex < bones.Count)
            {
                var bone = bones[selectedBoneIndex];
                GUILayout.BeginVertical("box");

                GUILayout.BeginHorizontal();
                GUILayout.Label($"📌 {bone.name}", GUILayout.ExpandWidth(true));
                GUILayout.Label($"位置: {bone.transform.localPosition}", GUILayout.Width(150));
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                string[] modes = { "📍 位置", "🔄 旋转", "📐 缩放" };
                int newMode = GUILayout.SelectionGrid(editMode, modes, 3, GUILayout.ExpandWidth(true));
                if (newMode != editMode) editMode = newMode;
                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();

                if (editMode == 0)
                {
                    GUILayout.Label("X:", GUILayout.Width(15));
                    posX = GUILayout.TextField(posX, GUILayout.Width(60));
                    GUILayout.Label("Y:", GUILayout.Width(15));
                    posY = GUILayout.TextField(posY, GUILayout.Width(60));
                    GUILayout.Label("Z:", GUILayout.Width(15));
                    posZ = GUILayout.TextField(posZ, GUILayout.Width(60));
                    if (GUILayout.Button("应用", GUILayout.Width(50))) ApplyBonePosition(bone);
                }
                else if (editMode == 1)
                {
                    GUILayout.Label("X:", GUILayout.Width(15));
                    rotX = GUILayout.TextField(rotX, GUILayout.Width(50));
                    GUILayout.Label("Y:", GUILayout.Width(15));
                    rotY = GUILayout.TextField(rotY, GUILayout.Width(50));
                    GUILayout.Label("Z:", GUILayout.Width(15));
                    rotZ = GUILayout.TextField(rotZ, GUILayout.Width(50));
                    if (GUILayout.Button("应用", GUILayout.Width(50))) ApplyBoneRotation(bone);
                }
                else
                {
                    GUILayout.Label("X:", GUILayout.Width(15));
                    scaleX = GUILayout.TextField(scaleX, GUILayout.Width(60));
                    GUILayout.Label("Y:", GUILayout.Width(15));
                    scaleY = GUILayout.TextField(scaleY, GUILayout.Width(60));
                    GUILayout.Label("Z:", GUILayout.Width(15));
                    scaleZ = GUILayout.TextField(scaleZ, GUILayout.Width(60));
                    if (GUILayout.Button("应用", GUILayout.Width(50))) ApplyBoneScale(bone);
                }

                if (GUILayout.Button("↺ 重置", GUILayout.Width(50)))
                {
                    ResetBone(bone);
                }

                GUILayout.EndHorizontal();

                GUILayout.BeginHorizontal();
                GUILayout.Label("💾 保存姿势:", GUILayout.Width(70));
                poseName = GUILayout.TextField(poseName, GUILayout.Width(80));
                if (GUILayout.Button("保存", GUILayout.Width(50))) SavePose();
                if (GUILayout.Button("加载", GUILayout.Width(50))) LoadPose();
                GUILayout.EndHorizontal();

                GUILayout.EndVertical();
            }
        }

        private static void UpdateBoneEditFields(BoneEditData bone)
        {
            posX = bone.localPosition.x.ToString("F3");
            posY = bone.localPosition.y.ToString("F3");
            posZ = bone.localPosition.z.ToString("F3");

            Vector3 euler = bone.localRotation.eulerAngles;
            rotX = euler.x.ToString("F2");
            rotY = euler.y.ToString("F2");
            rotZ = euler.z.ToString("F2");

            scaleX = bone.localScale.x.ToString("F3");
            scaleY = bone.localScale.y.ToString("F3");
            scaleZ = bone.localScale.z.ToString("F3");
        }

        private static void ApplyBonePosition(BoneEditData bone)
        {
            try
            {
                float x = float.Parse(posX);
                float y = float.Parse(posY);
                float z = float.Parse(posZ);
                bone.transform.localPosition = new Vector3(x, y, z);
                bone.localPosition = bone.transform.localPosition;
            }
            catch { }
        }

        private static void ApplyBoneRotation(BoneEditData bone)
        {
            try
            {
                float x = float.Parse(rotX);
                float y = float.Parse(rotY);
                float z = float.Parse(rotZ);
                bone.transform.localRotation = Quaternion.Euler(x, y, z);
                bone.localRotation = bone.transform.localRotation;
            }
            catch { }
        }

        private static void ApplyBoneScale(BoneEditData bone)
        {
            try
            {
                float x = float.Parse(scaleX);
                float y = float.Parse(scaleY);
                float z = float.Parse(scaleZ);
                bone.transform.localScale = new Vector3(x, y, z);
                bone.localScale = bone.transform.localScale;
            }
            catch { }
        }

        private static void ResetBone(BoneEditData bone)
        {
            bone.transform.localPosition = bone.originalPosition;
            bone.transform.localRotation = bone.originalRotation;
            bone.transform.localScale = bone.originalScale;
            bone.localPosition = bone.originalPosition;
            bone.localRotation = bone.originalRotation;
            bone.localScale = bone.originalScale;
            UpdateBoneEditFields(bone);
        }

        private static void HighlightBone(BoneEditData bone)
        {
            if (bone == null || bone.transform == null) return;
            GameObject marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            marker.name = "BoneHighlight";
            marker.transform.position = bone.transform.position;
            marker.transform.localScale = Vector3.one * 0.15f;
            Renderer renderer = marker.GetComponent<Renderer>();
            if (renderer != null) renderer.material.color = Color.yellow;
            UnityEngine.Object.Destroy(marker, 2f);
        }

        private static void SavePose()
        {
            if (string.IsNullOrEmpty(poseName)) poseName = $"pose_{DateTime.Now:HHmmss}";
            Debug.Log($"[LogicPreview3D] 💾 保存姿势: {poseName}");
        }

        private static void LoadPose()
        {
            Debug.Log($"[LogicPreview3D] 📂 加载姿势: {poseName}");
        }

        // ============================================================
        // 碰撞箱编辑器
        // ============================================================
        private static void DrawColliderEditor()
        {
            GUILayout.Label($"🎯 碰撞箱列表 ({colliders.Count})", GUILayout.ExpandWidth(true));

            colliderScrollPos = GUILayout.BeginScrollView(colliderScrollPos, GUILayout.Height(100));

            for (int i = 0; i < colliders.Count; i++)
            {
                var c = colliders[i];
                if (c == null) continue;

                GUILayout.BeginHorizontal("box");

                if (i == selectedColliderIndex)
                    GUI.backgroundColor = new Color(0.3f, 0.5f, 0.8f);

                if (GUILayout.Button(c.name, GUILayout.Width(80)))
                {
                    selectedColliderIndex = i;
                }

                GUI.backgroundColor = Color.white;

                c.enabled = GUILayout.Toggle(c.enabled, "启用", GUILayout.Width(40));

                int newType = GUILayout.SelectionGrid(Array.IndexOf(colliderTypes, c.type), colliderTypes, 3, GUILayout.ExpandWidth(true));
                if (newType >= 0) c.type = colliderTypes[newType];

                if (i == selectedColliderIndex)
                {
                    if (c.type == "Box")
                    {
                        GUILayout.Label("中心:", GUILayout.Width(30));
                        c.center.x = FloatField(c.center.x, 40);
                        c.center.y = FloatField(c.center.y, 40);
                        c.center.z = FloatField(c.center.z, 40);
                        GUILayout.Label("大小:", GUILayout.Width(30));
                        c.size.x = FloatField(c.size.x, 40);
                        c.size.y = FloatField(c.size.y, 40);
                        c.size.z = FloatField(c.size.z, 40);
                    }
                    else if (c.type == "Sphere")
                    {
                        GUILayout.Label("中心:", GUILayout.Width(30));
                        c.center.x = FloatField(c.center.x, 40);
                        c.center.y = FloatField(c.center.y, 40);
                        c.center.z = FloatField(c.center.z, 40);
                        GUILayout.Label("半径:", GUILayout.Width(30));
                        c.radius = FloatField(c.radius, 40);
                    }
                    else if (c.type == "Capsule")
                    {
                        GUILayout.Label("中心:", GUILayout.Width(30));
                        c.center.x = FloatField(c.center.x, 40);
                        c.center.y = FloatField(c.center.y, 40);
                        c.center.z = FloatField(c.center.z, 40);
                        GUILayout.Label("半径:", GUILayout.Width(30));
                        c.radius = FloatField(c.radius, 40);
                        GUILayout.Label("高度:", GUILayout.Width(30));
                        c.height = FloatField(c.height, 40);
                    }
                }

                if (GUILayout.Button("🗑", GUILayout.Width(25)))
                {
                    colliders.RemoveAt(i);
                    if (selectedColliderIndex >= colliders.Count) selectedColliderIndex = -1;
                    break;
                }

                GUILayout.EndHorizontal();

                if (i == selectedColliderIndex && i < colliders.Count)
                {
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button("✅ 应用修改", GUILayout.Width(100)))
                    {
                        ApplyColliderChanges(colliders[i]);
                    }
                    GUILayout.EndHorizontal();
                }
            }

            GUILayout.EndScrollView();

            GUILayout.BeginHorizontal();
            if (GUILayout.Button("➕ 添加 Box", GUILayout.Width(80)))
            {
                colliders.Add(new ColliderEditData { name = "NewBox", type = "Box", enabled = true, center = Vector3.zero, size = Vector3.one });
            }
            if (GUILayout.Button("➕ 添加 Sphere", GUILayout.Width(90)))
            {
                colliders.Add(new ColliderEditData { name = "NewSphere", type = "Sphere", enabled = true, center = Vector3.zero, radius = 0.5f });
            }
            if (GUILayout.Button("➕ 添加 Capsule", GUILayout.Width(95)))
            {
                colliders.Add(new ColliderEditData { name = "NewCapsule", type = "Capsule", enabled = true, center = Vector3.zero, radius = 0.3f, height = 1f });
            }
            GUILayout.EndHorizontal();
        }

        private static float FloatField(float value, float width)
        {
            string str = value.ToString("F3");
            string newStr = GUILayout.TextField(str, GUILayout.Width(width));
            if (float.TryParse(newStr, out float result))
                return result;
            return value;
        }

        private static void ApplyColliderChanges(ColliderEditData data)
        {
            Debug.Log($"[LogicPreview3D] ✅ 碰撞箱已更新: {data.name}");
        }

        // ============================================================
        // 保存和应用
        // ============================================================
        private static void SaveChanges()
        {
            if (currentLogic != null)
            {
                Debug.Log($"[LogicPreview3D] 💾 保存修改到逻辑体: {currentLogic.name}");
            }
        }

        private static void ApplyToObject()
        {
            if (previewObject == null) return;
            Debug.Log($"[LogicPreview3D] 🚀 应用到对象: {previewObject.name}");
        }

        private static void ExportAsLogic()
        {
            if (previewObject == null) return;
            LogicPrefabExtractor.Extract(previewObject, previewObject.name + "_Exported");
            Debug.Log($"[LogicPreview3D] 📦 导出为逻辑体: {previewObject.name}");
        }

        // ============================================================
        // 清理
        // ============================================================
        private static void CleanupPreview()
        {
            if (previewObject != null)
                UnityEngine.Object.Destroy(previewObject);
            previewObject = null;

            if (gridHelper != null)
                UnityEngine.Object.Destroy(gridHelper);
            gridHelper = null;

            if (previewRT != null)
            {
                previewRT.Release();
                UnityEngine.Object.DestroyImmediate(previewRT);
                previewRT = null;
            }

            if (cameraObject != null)
            {
                UnityEngine.Object.Destroy(cameraObject);
                cameraObject = null;
                previewCamera = null;
            }

            foreach (var marker in boneMarkers)
                if (marker != null) UnityEngine.Object.Destroy(marker);
            boneMarkers.Clear();

            foreach (var line in boneLines)
                if (line != null) UnityEngine.Object.Destroy(line.gameObject);
            boneLines.Clear();

            foreach (var visual in colliderVisuals)
                if (visual != null) UnityEngine.Object.Destroy(visual);
            colliderVisuals.Clear();

            bones.Clear();
            colliders.Clear();
            selectedBoneIndex = -1;
            selectedColliderIndex = -1;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace SuperConsole
{
    // ============================================================
    // 提取选项类
    // ============================================================
    public class ExtractOptions
    {
        public bool ExtractMesh = true;
        public bool ExtractTextures = true;
        public bool ExtractMaterials = true;
        public bool ExtractAnimations = true;
        public bool ExtractAudio = true;
        public bool ExtractColliders = true;
        public bool ExtractBones = true;
        public bool ExtractChildren = true;
        public bool ExtractComponents = false;
        public bool ExtractScripts = false;
    }

    // ============================================================
    // 逻辑体预制体提取器
    // ============================================================
    public static class LogicPrefabExtractor
    {
        // ============================================================
        // 提取对象到逻辑体（默认：提取全部）
        // ============================================================
        public static LogicEntityV2 Extract(GameObject source, string name, LogicType type = LogicType.Prefab)
        {
            return ExtractWithOptions(source, name, type, new ExtractOptions());
        }

        // ============================================================
        // 提取对象到逻辑体（带选项）
        // ============================================================
        public static LogicEntityV2 ExtractWithOptions(GameObject source, string name, LogicType type, ExtractOptions options)
        {
            if (source == null)
            {
                Debug.LogError("[LogicPrefabExtractor] 源对象为空");
                return null;
            }

            // ---- 1. 创建逻辑体 ----
            LogicEntityV2 logic = LogicManagerV2.Create(name, type);

            // ---- 2. 创建目录结构 ----
            string prefabDir = Path.Combine(logic.FolderPath, "prefabs");
            string modelsDir = Path.Combine(logic.FolderPath, "models");
            string texturesDir = Path.Combine(logic.FolderPath, "textures");
            string audioDir = Path.Combine(logic.FolderPath, "audio");
            string materialsDir = Path.Combine(logic.FolderPath, "materials");
            string animationsDir = Path.Combine(logic.FolderPath, "animations");
            string scriptsDir = Path.Combine(logic.FolderPath, "scripts");

            Directory.CreateDirectory(prefabDir);
            Directory.CreateDirectory(modelsDir);
            Directory.CreateDirectory(texturesDir);
            Directory.CreateDirectory(audioDir);
            Directory.CreateDirectory(materialsDir);
            Directory.CreateDirectory(animationsDir);
            if (options.ExtractScripts) Directory.CreateDirectory(scriptsDir);

            // ---- 3. 克隆对象 ----
            GameObject clone = UnityEngine.Object.Instantiate(source);
            clone.name = source.name;

            // ---- 4. 根据选项提取 ----
            if (options.ExtractMesh) ExtractMeshes(clone, modelsDir, ref logic);
            if (options.ExtractTextures) ExtractTextures(clone, texturesDir, ref logic);
            if (options.ExtractMaterials) ExtractMaterials(clone, materialsDir, ref logic);
            if (options.ExtractAnimations) ExtractAnimations(clone, animationsDir, ref logic);
            if (options.ExtractAudio) ExtractAudio(clone, audioDir, ref logic);
            if (options.ExtractColliders) ExtractColliders(clone, ref logic);
            if (options.ExtractBones) ExtractBones(clone, ref logic);
            if (options.ExtractComponents) ExtractComponents(clone, ref logic);
            if (options.ExtractScripts) ExtractScripts(clone, scriptsDir, ref logic);
            if (options.ExtractChildren) ExtractChildren(clone, ref logic);

            // ---- 5. 清理组件（根据选项） ----
            if (!options.ExtractComponents && !options.ExtractScripts)
            {
                CleanComponents(clone);
            }

            // ---- 6. 保存为预制体 ----
            LogicPrefabSaver.SavePrefab(clone, logic.FolderPath, "main");
            logic.resources.Prefab = "prefabs/main.prefab";

            // ---- 7. 清理克隆 ----
            UnityEngine.Object.Destroy(clone);

            // ---- 8. 保存逻辑体 ----
            LogicManagerV2.SaveToFile(logic);

            Debug.Log($"[LogicPrefabExtractor] 提取完成: {logic.GetDisplayName()}");
            return logic;
        }

        // ============================================================
        // 原有方法保持不变，但调用新方法
        // ============================================================
        public static LogicEntityV2 ExtractFromGameObject(GameObject source, string name, LogicType type = LogicType.Prefab)
        {
            return Extract(source, name, type);
        }

        // ============================================================
        // 清理组件（只保留核心组件）
        // ============================================================
        private static void CleanComponents(GameObject obj)
        {
            MonoBehaviour[] scripts = obj.GetComponentsInChildren<MonoBehaviour>(true);
            foreach (var script in scripts)
            {
                if (script is Transform) continue;
                if (script is MeshFilter) continue;
                if (script is MeshRenderer) continue;
                if (script is SkinnedMeshRenderer) continue;
                if (script is Collider) continue;
                if (script is Rigidbody) continue;
                if (script is Animation) continue;
                if (script is Animator) continue;
                if (script is AudioSource) continue;
                UnityEngine.Object.Destroy(script);
            }
        }

        // ============================================================
        // 提取 Mesh
        // ============================================================
        private static void ExtractMeshes(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            MeshFilter[] filters = obj.GetComponentsInChildren<MeshFilter>(true);
            foreach (var filter in filters)
            {
                if (filter == null || filter.mesh == null) continue;

                string meshName = filter.mesh.name;
                if (string.IsNullOrEmpty(meshName) || meshName == "Mesh")
                    meshName = "mesh_" + Guid.NewGuid().ToString().Substring(0, 6);

                string path = Path.Combine(outputDir, meshName + ".obj");
                string relativePath = $"models/{meshName}.obj";

                string objContent = MeshToObj(filter.mesh);
                File.WriteAllText(path, objContent);

                if (string.IsNullOrEmpty(logic.resources.Model))
                    logic.resources.Model = relativePath;

                Debug.Log($"[LogicPrefabExtractor] 提取模型: {meshName} -> {relativePath}");
            }

            SkinnedMeshRenderer[] skinned = obj.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in skinned)
            {
                if (smr == null || smr.sharedMesh == null) continue;

                string meshName = smr.sharedMesh.name;
                if (string.IsNullOrEmpty(meshName) || meshName == "Mesh")
                    meshName = "skinned_" + Guid.NewGuid().ToString().Substring(0, 6);

                string path = Path.Combine(outputDir, meshName + ".obj");
                string relativePath = $"models/{meshName}.obj";

                string objContent = MeshToObj(smr.sharedMesh);
                File.WriteAllText(path, objContent);

                if (string.IsNullOrEmpty(logic.resources.Model))
                    logic.resources.Model = relativePath;

                Debug.Log($"[LogicPrefabExtractor] 提取蒙皮模型: {meshName} -> {relativePath}");
            }
        }

        // ============================================================
        // 提取纹理
        // ============================================================
        private static void ExtractTextures(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            HashSet<string> added = new HashSet<string>();

            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;
                foreach (var mat in renderer.sharedMaterials)
                {
                    if (mat == null || mat.mainTexture == null) continue;
                    Texture2D tex = mat.mainTexture as Texture2D;
                    if (tex == null || added.Contains(tex.name)) continue;

                    added.Add(tex.name);
                    string texName = tex.name;
                    string path = Path.Combine(outputDir, texName + ".png");
                    string relativePath = $"textures/{texName}.png";

                    try
                    {
                        byte[] pngData = tex.EncodeToPNG();
                        if (pngData != null && pngData.Length > 0)
                        {
                            File.WriteAllBytes(path, pngData);
                            if (logic.resources.Textures == null)
                                logic.resources.Textures = new List<string>();
                            logic.resources.Textures.Add(relativePath);
                            Debug.Log($"[LogicPrefabExtractor] 提取纹理: {texName} -> {relativePath}");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning($"[LogicPrefabExtractor] 无法保存纹理 {texName}: {ex.Message}");
                    }
                }
            }
        }

        // ============================================================
        // 提取音频
        // ============================================================
        private static void ExtractAudio(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            AudioSource[] sources = obj.GetComponentsInChildren<AudioSource>(true);
            HashSet<string> added = new HashSet<string>();

            foreach (var source in sources)
            {
                if (source == null || source.clip == null) continue;
                AudioClip clip = source.clip;
                if (added.Contains(clip.name)) continue;

                added.Add(clip.name);
                string clipName = clip.name;
                string relativePath = $"audio/{clipName}.wav";

                if (logic.resources.Audio == null)
                    logic.resources.Audio = new List<string>();
                logic.resources.Audio.Add(relativePath);
                Debug.Log($"[LogicPrefabExtractor] 记录音频: {clipName} -> {relativePath}");
            }
        }

        // ============================================================
        // 提取材质
        // ============================================================
        private static void ExtractMaterials(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            Renderer[] renderers = obj.GetComponentsInChildren<Renderer>(true);
            HashSet<string> added = new HashSet<string>();

            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;
                foreach (var mat in renderer.sharedMaterials)
                {
                    if (mat == null || added.Contains(mat.name)) continue;

                    added.Add(mat.name);
                    string matName = mat.name;
                    string path = Path.Combine(outputDir, matName + ".mat");
                    string relativePath = $"materials/{matName}.mat";

                    SaveMaterialAsText(mat, path);

                    if (logic.resources.Materials == null)
                        logic.resources.Materials = new List<string>();
                    logic.resources.Materials.Add(relativePath);
                    Debug.Log($"[LogicPrefabExtractor] 提取材质: {matName} -> {relativePath}");
                }
            }
        }

        // ============================================================
        // 提取动画
        // ============================================================
        private static void ExtractAnimations(GameObject obj, string outputDir, ref LogicEntityV2 logic)
        {
            Animation anim = obj.GetComponent<Animation>();
            if (anim != null)
            {
                foreach (AnimationState state in anim)
                {
                    if (state == null || state.clip == null) continue;
                    string clipName = state.clip.name;
                    string path = Path.Combine(outputDir, clipName + ".anim");
                    string relativePath = $"animations/{clipName}.anim";

                    SaveAnimationAsText(state.clip, path);

                    if (logic.resources.Animations == null)
                        logic.resources.Animations = new List<string>();
                    logic.resources.Animations.Add(relativePath);
                    Debug.Log($"[LogicPrefabExtractor] 提取动画: {clipName} -> {relativePath}");
                }
            }

            Animator animator = obj.GetComponent<Animator>();
            if (animator != null && animator.runtimeAnimatorController != null)
            {
                Debug.Log($"[LogicPrefabExtractor] 检测到 Animator Controller: {animator.runtimeAnimatorController.name}");
            }
        }

        // ============================================================
        // 提取碰撞箱
        // ============================================================
        private static void ExtractColliders(GameObject obj, ref LogicEntityV2 logic)
        {
            Collider[] colliders = obj.GetComponentsInChildren<Collider>(true);
            if (colliders.Length > 0)
            {
                logic.tags.Add($"colliders:{colliders.Length}");
                Debug.Log($"[LogicPrefabExtractor] 提取碰撞箱: {colliders.Length} 个");
            }
        }

        // ============================================================
        // 提取骨骼
        // ============================================================
        private static void ExtractBones(GameObject obj, ref LogicEntityV2 logic)
        {
            int boneCount = 0;
            foreach (var t in obj.GetComponentsInChildren<Transform>())
            {
                if (t == obj.transform) continue;
                boneCount++;
            }
            if (boneCount > 0)
            {
                logic.tags.Add($"bones:{boneCount}");
                Debug.Log($"[LogicPrefabExtractor] 提取骨骼: {boneCount} 个");
            }
        }

        // ============================================================
        // 提取组件（保留所有组件）
        // ============================================================
        private static void ExtractComponents(GameObject obj, ref LogicEntityV2 logic)
        {
            Component[] comps = obj.GetComponentsInChildren<Component>(true);
            int compCount = 0;
            foreach (var comp in comps)
            {
                if (comp == null || comp is Transform) continue;
                compCount++;
                logic.tags.Add($"component:{comp.GetType().Name}");
            }
            if (compCount > 0)
            {
                Debug.Log($"[LogicPrefabExtractor] 提取组件: {compCount} 个");
            }
        }

        // ============================================================
        // 提取脚本（MonoBehaviour）
        // ============================================================
        private static void ExtractScripts(GameObject obj, string scriptsDir, ref LogicEntityV2 logic)
        {
            MonoBehaviour[] scripts = obj.GetComponentsInChildren<MonoBehaviour>(true);
            int scriptCount = 0;
            foreach (var script in scripts)
            {
                if (script == null) continue;
                if (script is Transform) continue;
                if (script is MeshFilter) continue;
                if (script is MeshRenderer) continue;
                if (script is SkinnedMeshRenderer) continue;
                if (script is Collider) continue;
                if (script is Rigidbody) continue;
                if (script is Animation) continue;
                if (script is Animator) continue;
                if (script is AudioSource) continue;

                scriptCount++;
                Type type = script.GetType();
                string typeName = type.Name;

                // 提取脚本信息
                logic.tags.Add($"script:{typeName}");

                // 尝试保存脚本代码（如果可以）
                try
                {
                    // 获取脚本的 assembly
                    var asm = type.Assembly;
                    // 尝试从文件加载源码（如果有）
                    // 目前只记录脚本类型名称
                }
                catch { }

                Debug.Log($"[LogicPrefabExtractor] 检测到脚本: {typeName}");
            }

            if (scriptCount > 0)
            {
                if (logic.resources.Scripts == null)
                    logic.resources.Scripts = new List<string>();
                logic.resources.Scripts.Add($"scripts_count:{scriptCount}");
                Debug.Log($"[LogicPrefabExtractor] 提取脚本: {scriptCount} 个");
            }
        }

        // ============================================================
        // 提取子对象
        // ============================================================
        private static void ExtractChildren(GameObject obj, ref LogicEntityV2 logic)
        {
            int childCount = obj.transform.childCount;
            if (childCount > 0)
            {
                logic.tags.Add($"children:{childCount}");
                foreach (Transform child in obj.transform)
                {
                    if (child != null)
                        logic.tags.Add($"child:{child.name}");
                }
                Debug.Log($"[LogicPrefabExtractor] 提取子对象: {childCount} 个");
            }
        }

        // ============================================================
        // Mesh → OBJ
        // ============================================================
        private static string MeshToObj(Mesh mesh)
        {
            if (mesh == null) return "";

            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine("# Extracted by SuperConsole");
            sb.AppendLine($"# Mesh: {mesh.name}");

            foreach (Vector3 v in mesh.vertices)
                sb.AppendLine($"v {v.x:F6} {v.y:F6} {v.z:F6}");

            if (mesh.uv.Length > 0)
                foreach (Vector2 uv in mesh.uv)
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");
            else if (mesh.uv2.Length > 0)
                foreach (Vector2 uv in mesh.uv2)
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");

            foreach (Vector3 n in mesh.normals)
                sb.AppendLine($"vn {n.x:F6} {n.y:F6} {n.z:F6}");

            int[] triangles = mesh.triangles;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int v1 = triangles[i] + 1;
                int v2 = triangles[i + 1] + 1;
                int v3 = triangles[i + 2] + 1;

                if (mesh.uv.Length > 0)
                    sb.AppendLine($"f {v1}/{v1} {v2}/{v2} {v3}/{v3}");
                else
                    sb.AppendLine($"f {v1} {v2} {v3}");
            }

            return sb.ToString();
        }

        // ============================================================
        // 保存材质为 YAML 文本
        // ============================================================
        private static void SaveMaterialAsText(Material mat, string path)
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine($"%YAML 1.1");
                sb.AppendLine($"%TAG !u! tag:unity3d.com,2011:");
                sb.AppendLine($"--- !u!21 &2100000");
                sb.AppendLine($"Material:");
                sb.AppendLine($"  serializedVersion: 6");
                sb.AppendLine($"  m_Name: {mat.name}");
                sb.AppendLine($"  m_Shader: {{fileID: 4800000, guid: {GetShaderGuid(mat.shader)}, type: 3}}");

                if (mat.HasProperty("_Color"))
                {
                    Color c = mat.GetColor("_Color");
                    sb.AppendLine($"  m_Colors:");
                    sb.AppendLine($"  - _Color: {{r: {c.r:F4}, g: {c.g:F4}, b: {c.b:F4}, a: {c.a:F4}}}");
                }

                if (mat.HasProperty("_MainTex") && mat.mainTexture != null)
                {
                    sb.AppendLine($"  m_Textures:");
                    sb.AppendLine($"  - _MainTex: {{fileID: 2800000, guid: {mat.mainTexture.name}, type: 3}}");
                }

                File.WriteAllText(path, sb.ToString());
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicPrefabExtractor] 无法保存材质 {mat.name}: {ex.Message}");
            }
        }

        // ============================================================
        // 保存动画为 YAML 文本
        // ============================================================
        private static void SaveAnimationAsText(AnimationClip clip, string path)
        {
            try
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine($"%YAML 1.1");
                sb.AppendLine($"%TAG !u! tag:unity3d.com,2011:");
                sb.AppendLine($"--- !u!74 &7400000");
                sb.AppendLine($"AnimationClip:");
                sb.AppendLine($"  m_Name: {clip.name}");
                sb.AppendLine($"  m_FrameRate: {clip.frameRate:F2}");
                sb.AppendLine($"  m_LoopTime: {(clip.isLooping ? 1 : 0)}");
                sb.AppendLine($"  m_Motion:");
                sb.AppendLine($"    m_Length: {clip.length:F4}");

                if (clip.events.Length > 0)
                {
                    sb.AppendLine($"  m_Events:");
                    foreach (var evt in clip.events)
                    {
                        sb.AppendLine($"  - time: {evt.time:F4}");
                        sb.AppendLine($"    functionName: {evt.functionName}");
                        sb.AppendLine($"    stringParameter: {evt.stringParameter}");
                        sb.AppendLine($"    floatParameter: {evt.floatParameter:F4}");
                        sb.AppendLine($"    intParameter: {evt.intParameter}");
                    }
                }

                File.WriteAllText(path, sb.ToString());
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicPrefabExtractor] 无法保存动画 {clip.name}: {ex.Message}");
            }
        }

        // ============================================================
        // 获取 Shader GUID
        // ============================================================
        private static string GetShaderGuid(Shader shader)
        {
            if (shader == null) return "00000000000000000000000000000000";

            Dictionary<string, string> shaderGuids = new Dictionary<string, string>
            {
                { "Standard", "0b858cefaa35b4aac80ac717755a0527" },
                { "Unlit/Color", "0b858cefaa35b4aac80ac717755a0528" },
                { "Unlit/Texture", "0b858cefaa35b4aac80ac717755a0529" },
                { "Unlit/Transparent", "0b858cefaa35b4aac80ac717755a0530" },
                { "Sprites/Default", "0b858cefaa35b4aac80ac717755a0531" },
                { "UI/Default", "0b858cefaa35b4aac80ac717755a0532" }
            };

            if (shaderGuids.ContainsKey(shader.name))
                return shaderGuids[shader.name];

            return "00000000000000000000000000000000";
        }
    }
}
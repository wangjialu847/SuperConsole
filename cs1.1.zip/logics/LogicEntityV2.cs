﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace SuperConsole
{
    // ============================================================
    // 逻辑体类型
    // ============================================================
    public enum LogicType
    {
        Prefab,     // 预制体
        Scene,      // 场景
        Map,        // 地图
        Character,  // 角色
        Weapon,     // 武器
        Vehicle,    // 载具
        Prop,       // 道具
        Mod,        // 完整模组
        Custom      // 自定义
    }

    // ============================================================
    // 资源引用
    // ============================================================
    [Serializable]
    public class LogicResources
    {
        public string Prefab;           // prefabs/main.prefab
        public string Model;            // models/character.fbx
        public List<string> Textures;   // textures/diffuse.png
        public List<string> Audio;      // audio/sound.wav
        public List<string> Materials;  // materials/character.mat
        public List<string> Animations; // animations/idle.anim
        public List<string> Scripts;    // scripts/behavior.cs
        public string Colliders;        // colliders/config.json
        public string Scene;            // scenes/level.unity
        public string Map;              // maps/config.json
        public string Rules;            // rules/config.json
        public string GameMode;         // gamemodes/config.json
        public string DLL;              // logic.dll
    }

    // ============================================================
    // 逻辑体主数据
    // ============================================================
    [Serializable]
    public class LogicEntityV2
    {
        // ===== 元数据 =====
        public string id;               // 10位字母数字
        public string name;             // 显示名称
        public string version;          // 1.0.0
        public string author;           // 作者
        public string description;      // 描述
        public string created;          // 创建时间
        public string modified;         // 修改时间
        public LogicType type;          // 类型
        public bool enabled;            // 是否启用

        // ===== 资源 =====
        public LogicResources resources;

        // ===== 依赖 =====
        public List<string> dependencies;

        // ===== 标签 =====
        public List<string> tags;

        // ===== 运行时数据（不保存） =====
        [NonSerialized]
        public string FolderPath;       // 文件夹路径
        [NonSerialized]
        public GameObject GameObject;   // 加载后的 GameObject
        [NonSerialized]
        public bool IsLoaded;           // 是否已加载

        // ============================================================
        // 构造函数
        // ============================================================
        public LogicEntityV2()
        {
            id = GenerateId();
            name = "未命名逻辑体";
            version = "1.0.0";
            author = "未知";
            description = "";
            type = LogicType.Prefab;
            enabled = true;
            resources = new LogicResources();
            dependencies = new List<string>();
            tags = new List<string>();
            created = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
            modified = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
        }

        // ============================================================
        // 生成 10 位 ID
        // ============================================================
        public static string GenerateId()
        {
            string chars = "abcdefghijklmnopqrstuvwxyz0123456789";
            char[] id = new char[10];
            for (int i = 0; i < 10; i++)
            {
                id[i] = chars[UnityEngine.Random.Range(0, chars.Length)];
            }
            return new string(id);
        }

        // ============================================================
        // 更新时间戳
        // ============================================================
        public void Touch()
        {
            modified = DateTime.Now.ToString("yyyy-MM-ddTHH:mm:ss");
        }

        // ============================================================
        // 获取显示名
        // ============================================================
        public string GetDisplayName()
        {
            return string.IsNullOrEmpty(name) ? id : name;
        }

        // ============================================================
        // 获取类型图标
        // ============================================================
        public string GetTypeIcon()
        {
            switch (type)
            {
                case LogicType.Prefab: return "📦";
                case LogicType.Scene: return "🗺️";
                case LogicType.Map: return "📐";
                case LogicType.Character: return "🧑";
                case LogicType.Weapon: return "🔫";
                case LogicType.Vehicle: return "🚗";
                case LogicType.Prop: return "🪑";
                case LogicType.Mod: return "🧠";
                default: return "📄";
            }
        }

        // ============================================================
        // 获取类型名称
        // ============================================================
        public string GetTypeName()
        {
            switch (type)
            {
                case LogicType.Prefab: return "预制体";
                case LogicType.Scene: return "场景";
                case LogicType.Map: return "地图";
                case LogicType.Character: return "角色";
                case LogicType.Weapon: return "武器";
                case LogicType.Vehicle: return "载具";
                case LogicType.Prop: return "道具";
                case LogicType.Mod: return "完整模组";
                default: return "自定义";
            }
        }

        // ============================================================
        // 获取状态文本
        // ============================================================
        public string GetStatusText()
        {
            if (!enabled) return "⏸️ 已禁用";
            if (IsLoaded) return "✅ 已加载";
            return "⏳ 未加载";
        }
    }
}
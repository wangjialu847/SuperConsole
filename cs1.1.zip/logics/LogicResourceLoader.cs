﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using BepInEx;
using UnityEngine.Networking;

namespace SuperConsole
{
    /// <summary>
    /// 逻辑体资源加载器
    /// 支持从本地 Assets/ 和游戏 Resources/ 加载
    /// </summary>
    public static class LogicResourceLoader
    {
        // ===== 路径 =====
        private static string assetsPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
        private static string modelsPath = Path.Combine(assetsPath, "Models");
        private static string texturesPath = Path.Combine(assetsPath, "Textures");
        private static string audioPath = Path.Combine(assetsPath, "Audio");
        private static string prefabsPath = Path.Combine(assetsPath, "Prefabs");
        private static string animationsPath = Path.Combine(assetsPath, "Animations");
        private static string materialsPath = Path.Combine(assetsPath, "Materials");

        // ===== 缓存 =====
        private static Dictionary<string, Mesh> meshCache = new Dictionary<string, Mesh>();
        private static Dictionary<string, Texture2D> textureCache = new Dictionary<string, Texture2D>();
        private static Dictionary<string, AudioClip> audioCache = new Dictionary<string, AudioClip>();
        private static Dictionary<string, GameObject> prefabCache = new Dictionary<string, GameObject>();
        private static Dictionary<string, AnimationClip> animationCache = new Dictionary<string, AnimationClip>();
        private static Dictionary<string, Material> materialCache = new Dictionary<string, Material>();

        static LogicResourceLoader()
        {
            EnsureDirectories();
            Debug.Log("[LogicResourceLoader] ✅ 已初始化，支持本地 + 游戏资源加载");
        }

        private static void EnsureDirectories()
        {
            if (!Directory.Exists(assetsPath)) Directory.CreateDirectory(assetsPath);
            if (!Directory.Exists(modelsPath)) Directory.CreateDirectory(modelsPath);
            if (!Directory.Exists(texturesPath)) Directory.CreateDirectory(texturesPath);
            if (!Directory.Exists(audioPath)) Directory.CreateDirectory(audioPath);
            if (!Directory.Exists(prefabsPath)) Directory.CreateDirectory(prefabsPath);
            if (!Directory.Exists(animationsPath)) Directory.CreateDirectory(animationsPath);
            if (!Directory.Exists(materialsPath)) Directory.CreateDirectory(materialsPath);
        }

        public static string GetAssetsPath() => assetsPath;
        public static string GetModelsPath() => modelsPath;
        public static string GetTexturesPath() => texturesPath;
        public static string GetAudioPath() => audioPath;
        public static string GetPrefabsPath() => prefabsPath;
        public static string GetAnimationsPath() => animationsPath;
        public static string GetMaterialsPath() => materialsPath;

        // ============================================================
        // 通用加载接口
        // ============================================================

        /// <summary>
        /// 从任意位置加载资源（自动识别）
        /// 顺序：本地 Assets/ → 逻辑体文件夹 → 游戏 Resources/
        /// </summary>
        public static T LoadResource<T>(string path, string logicFolderPath = null) where T : UnityEngine.Object
        {
            if (typeof(T) == typeof(Mesh))
                return LoadMesh(path, logicFolderPath) as T;
            if (typeof(T) == typeof(Texture2D))
                return LoadTexture(path, logicFolderPath) as T;
            if (typeof(T) == typeof(AudioClip))
                return LoadAudio(path, logicFolderPath) as T;
            if (typeof(T) == typeof(GameObject))
                return LoadPrefab(path, logicFolderPath) as T;
            if (typeof(T) == typeof(AnimationClip))
                return LoadAnimation(path, logicFolderPath) as T;
            if (typeof(T) == typeof(Material))
                return LoadMaterial(path, logicFolderPath) as T;

            return null;
        }

        // ============================================================
        // 1. 加载 Mesh
        // ============================================================
        public static Mesh LoadMesh(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (meshCache.ContainsKey(key)) return meshCache[key];

            Mesh mesh = null;

            // 1.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    mesh = LoadOBJ(fullPath);
                    if (mesh != null)
                    {
                        meshCache[key] = mesh;
                        return mesh;
                    }
                }
            }

            // 1.2 从本地 Assets/Models 加载
            string localPath = Path.Combine(modelsPath, path);
            if (File.Exists(localPath))
            {
                mesh = LoadOBJ(localPath);
                if (mesh != null)
                {
                    meshCache[key] = mesh;
                    return mesh;
                }
            }

            // 1.3 从游戏 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            mesh = Resources.Load<Mesh>(resourceName);
            if (mesh != null)
            {
                meshCache[key] = mesh;
                return mesh;
            }

            return null;
        }

        // ============================================================
        // 2. 加载 Texture2D
        // ============================================================
        public static Texture2D LoadTexture(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (textureCache.ContainsKey(key)) return textureCache[key];

            Texture2D tex = null;

            // 2.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    tex = LoadImageFile(fullPath);
                    if (tex != null)
                    {
                        textureCache[key] = tex;
                        return tex;
                    }
                }
            }

            // 2.2 从本地 Assets/Textures 加载
            string localPath = Path.Combine(texturesPath, path);
            if (File.Exists(localPath))
            {
                tex = LoadImageFile(localPath);
                if (tex != null)
                {
                    textureCache[key] = tex;
                    return tex;
                }
            }

            // 2.3 从游戏 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            tex = Resources.Load<Texture2D>(resourceName);
            if (tex != null)
            {
                textureCache[key] = tex;
                return tex;
            }

            return null;
        }

        // ============================================================
        // 3. 加载 AudioClip
        // ============================================================
        public static AudioClip LoadAudio(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (audioCache.ContainsKey(key)) return audioCache[key];

            AudioClip clip = null;

            // 3.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    clip = LoadAudioFile(fullPath);
                    if (clip != null)
                    {
                        audioCache[key] = clip;
                        return clip;
                    }
                }
            }

            // 3.2 从本地 Assets/Audio 加载
            string localPath = Path.Combine(audioPath, path);
            if (File.Exists(localPath))
            {
                clip = LoadAudioFile(localPath);
                if (clip != null)
                {
                    audioCache[key] = clip;
                    return clip;
                }
            }

            // 3.3 从游戏 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            clip = Resources.Load<AudioClip>(resourceName);
            if (clip != null)
            {
                audioCache[key] = clip;
                return clip;
            }

            return null;
        }

        // ============================================================
        // 4. 加载 GameObject (Prefab)
        // ============================================================
        public static GameObject LoadPrefab(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (prefabCache.ContainsKey(key)) return prefabCache[key];

            GameObject prefab = null;

            // 4.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    prefab = LogicPrefabSaver.LoadPrefab(logicFolderPath, "main");
                    if (prefab != null)
                    {
                        prefabCache[key] = prefab;
                        return prefab;
                    }
                }
            }

            // 4.2 从本地 Assets/Prefabs 加载
            string localPath = Path.Combine(prefabsPath, path);
            if (File.Exists(localPath))
            {
                prefab = LogicPrefabSaver.LoadPrefab(prefabsPath, Path.GetFileNameWithoutExtension(path));
                if (prefab != null)
                {
                    prefabCache[key] = prefab;
                    return prefab;
                }
            }

            // 4.3 从游戏 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            prefab = Resources.Load<GameObject>(resourceName);
            if (prefab != null)
            {
                prefabCache[key] = prefab;
                return prefab;
            }

            return null;
        }

        // ============================================================
        // 5. 加载 AnimationClip
        // ============================================================
        public static AnimationClip LoadAnimation(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (animationCache.ContainsKey(key)) return animationCache[key];

            AnimationClip clip = null;

            // 5.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    clip = LoadAnimationFile(fullPath);
                    if (clip != null)
                    {
                        animationCache[key] = clip;
                        return clip;
                    }
                }
            }

            // 5.2 从本地 Assets/Animations 加载
            string localPath = Path.Combine(animationsPath, path);
            if (File.Exists(localPath))
            {
                clip = LoadAnimationFile(localPath);
                if (clip != null)
                {
                    animationCache[key] = clip;
                    return clip;
                }
            }

            // 5.3 从游戏 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            clip = Resources.Load<AnimationClip>(resourceName);
            if (clip != null)
            {
                animationCache[key] = clip;
                return clip;
            }

            return null;
        }

        // ============================================================
        // 6. 加载 Material
        // ============================================================
        public static Material LoadMaterial(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (materialCache.ContainsKey(key)) return materialCache[key];

            Material mat = null;

            // 6.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    mat = LoadMaterialFile(fullPath);
                    if (mat != null)
                    {
                        materialCache[key] = mat;
                        return mat;
                    }
                }
            }

            // 6.2 从本地 Assets/Materials 加载
            string localPath = Path.Combine(materialsPath, path);
            if (File.Exists(localPath))
            {
                mat = LoadMaterialFile(localPath);
                if (mat != null)
                {
                    materialCache[key] = mat;
                    return mat;
                }
            }

            // 6.3 从游戏 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            mat = Resources.Load<Material>(resourceName);
            if (mat != null)
            {
                materialCache[key] = mat;
                return mat;
            }

            return null;
        }

        // ============================================================
        // 通用：从游戏加载资源（Resources.Load）
        // ============================================================
        public static T LoadFromResources<T>(string name) where T : UnityEngine.Object
        {
            return Resources.Load<T>(name);
        }

        /// <summary>
        /// 从游戏 Resources 加载所有资源
        /// </summary>
        public static T[] LoadAllFromResources<T>(string folder = "") where T : UnityEngine.Object
        {
            return Resources.LoadAll<T>(folder);
        }

        // ============================================================
        // 工具方法：加载图片文件
        // ============================================================
        private static Texture2D LoadImageFile(string path)
        {
            try
            {
                byte[] data = File.ReadAllBytes(path);
                Texture2D tex = new Texture2D(2, 2);
                if (ImageConversion.LoadImage(tex, data))
                    return tex;
            }
            catch { }
            return null;
        }

        // ============================================================
        // 工具方法：加载音频文件（UnityWebRequest，Unity 2020 通用）
        // ============================================================
        private static AudioClip LoadAudioFile(string path)
        {
            try
            {
                string url = "file://" + path.Replace("\\", "/");
                var www = UnityWebRequestMultimedia.GetAudioClip(url, (AudioType)17);
                www.SendWebRequest();
                while (!www.isDone) { }
                if (www.result == UnityWebRequest.Result.Success)
                {
                    return DownloadHandlerAudioClip.GetContent(www);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicResourceLoader] ⚠️ 音频加载异常: {ex.Message}");
            }
            return null;
        }

        // ============================================================
        // 工具方法：加载 OBJ
        // ============================================================
        private static Mesh LoadOBJ(string path)
        {
            try
            {
                string[] lines = File.ReadAllLines(path);
                List<Vector3> vertices = new List<Vector3>();
                List<Vector2> uvs = new List<Vector2>();
                List<int> triangles = new List<int>();

                foreach (string line in lines)
                {
                    if (line.StartsWith("v "))
                    {
                        string[] parts = line.Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 3)
                            vertices.Add(new Vector3(float.Parse(parts[0]), float.Parse(parts[1]), float.Parse(parts[2])));
                    }
                    else if (line.StartsWith("vt "))
                    {
                        string[] parts = line.Substring(3).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 2)
                            uvs.Add(new Vector2(float.Parse(parts[0]), float.Parse(parts[1])));
                    }
                    else if (line.StartsWith("f "))
                    {
                        string[] parts = line.Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (string part in parts)
                        {
                            string[] indices = part.Split('/');
                            if (indices.Length > 0 && !string.IsNullOrEmpty(indices[0]))
                                triangles.Add(int.Parse(indices[0]) - 1);
                        }
                    }
                }

                if (vertices.Count == 0 || triangles.Count == 0) return null;

                Mesh mesh = new Mesh();
                mesh.vertices = vertices.ToArray();
                mesh.triangles = triangles.ToArray();
                if (uvs.Count > 0) mesh.uv = uvs.ToArray();
                mesh.RecalculateNormals();
                mesh.RecalculateBounds();
                return mesh;
            }
            catch { return null; }
        }

        // ============================================================
        // 工具方法：加载材质文件
        // ============================================================
        private static Material LoadMaterialFile(string path)
        {
            try
            {
                string[] lines = File.ReadAllLines(path);
                string shaderName = "Standard";
                Color color = Color.white;
                string textureName = null;

                foreach (string line in lines)
                {
                    if (line.StartsWith("shader:"))
                        shaderName = line.Substring(7).Trim();
                    else if (line.StartsWith("color:"))
                    {
                        string[] parts = line.Substring(6).Trim().Split(',');
                        if (parts.Length >= 3)
                        {
                            float r = float.Parse(parts[0].Trim());
                            float g = float.Parse(parts[1].Trim());
                            float b = float.Parse(parts[2].Trim());
                            float a = parts.Length >= 4 ? float.Parse(parts[3].Trim()) : 1f;
                            color = new Color(r, g, b, a);
                        }
                    }
                    else if (line.StartsWith("mainTexture:"))
                        textureName = line.Substring(12).Trim();
                }

                Shader shader = Shader.Find(shaderName);
                if (shader == null) shader = Shader.Find("Standard");

                Material mat = new Material(shader);
                mat.color = color;

                if (!string.IsNullOrEmpty(textureName))
                {
                    string dir = Path.GetDirectoryName(path);
                    string texPath = Path.Combine(dir, "..", "textures", textureName + ".png");
                    if (File.Exists(texPath))
                    {
                        byte[] data = File.ReadAllBytes(texPath);
                        Texture2D tex = new Texture2D(2, 2);
                        if (ImageConversion.LoadImage(tex, data))
                            mat.mainTexture = tex;
                    }
                }

                return mat;
            }
            catch { return null; }
        }

        // ============================================================
        // 工具方法：加载动画文件（通用版）
        // ============================================================
        private static AnimationClip LoadAnimationFile(string path)
        {
            try
            {
                string[] lines = File.ReadAllLines(path);
                string name = Path.GetFileNameWithoutExtension(path);
                float frameRate = 30f;
                bool loop = false;

                foreach (string line in lines)
                {
                    if (line.StartsWith("frameRate:"))
                        float.TryParse(line.Substring(10).Trim(), out frameRate);
                    else if (line.StartsWith("loop:"))
                        bool.TryParse(line.Substring(5).Trim(), out loop);
                }

                AnimationClip clip = new AnimationClip();
                clip.name = name;
                clip.frameRate = frameRate;
                clip.legacy = true;

                var field = typeof(AnimationClip).GetField("m_Loop",
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance);
                if (field != null)
                    field.SetValue(clip, loop);
                else
                    clip.wrapMode = loop ? WrapMode.Loop : WrapMode.Default;

                return clip;
            }
            catch { return null; }
        }

        // ============================================================
        // 缓存管理
        // ============================================================
        public static void ClearCache()
        {
            meshCache.Clear();
            textureCache.Clear();
            audioCache.Clear();
            prefabCache.Clear();
            animationCache.Clear();
            materialCache.Clear();
        }

        public static void ClearCache<T>()
        {
            if (typeof(T) == typeof(Mesh)) meshCache.Clear();
            else if (typeof(T) == typeof(Texture2D)) textureCache.Clear();
            else if (typeof(T) == typeof(AudioClip)) audioCache.Clear();
            else if (typeof(T) == typeof(GameObject)) prefabCache.Clear();
            else if (typeof(T) == typeof(AnimationClip)) animationCache.Clear();
            else if (typeof(T) == typeof(Material)) materialCache.Clear();
        }

        public static string GetStatus()
        {
            return $"[LogicResourceLoader] 📊 缓存: Mesh:{meshCache.Count} Tex:{textureCache.Count} Audio:{audioCache.Count} Prefab:{prefabCache.Count} Anim:{animationCache.Count} Mat:{materialCache.Count}";
        }
    }
}
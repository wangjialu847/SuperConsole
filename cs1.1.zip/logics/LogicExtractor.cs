﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SuperConsole
{
    // ============================================================
    // 场景提取器 - 从场景提取所有对象为逻辑体
    // ============================================================
    public static class LogicExtractor
    {
        // ============================================================
        // 从 GameObject 提取（单个对象）
        // ============================================================
        public static LogicEntityV2 ExtractFromGameObject(GameObject source, string name, LogicType type = LogicType.Prefab)
        {
            if (source == null)
            {
                Debug.LogError("[LogicExtractor] ❌ 源对象为空");
                return null;
            }

            // 1. 创建逻辑体
            LogicEntityV2 logic = LogicManagerV2.Create(name, type);

            // 2. 创建预制体目录
            string prefabPath = Path.Combine(logic.FolderPath, "prefabs");
            if (!Directory.Exists(prefabPath))
            {
                Directory.CreateDirectory(prefabPath);
            }
            logic.resources.Prefab = "prefabs/main.prefab";

            // 3. 初始化资源列表
            logic.resources.Textures = new List<string>();
            logic.resources.Audio = new List<string>();
            logic.resources.Materials = new List<string>();
            logic.resources.Animations = new List<string>();
            logic.resources.Scripts = new List<string>();

            // 4. 使用 LogicPrefabSaver 保存预制体
            LogicPrefabSaver.SavePrefab(source, logic.FolderPath, "main");
            logic.resources.Prefab = "prefabs/main.prefab";

            // 5. 分析对象组件
            Component[] components = source.GetComponents<Component>();
            foreach (var comp in components)
            {
                if (comp == null) continue;
                Debug.Log($"[LogicExtractor] 🔍 检测到组件: {comp.GetType().Name}");
            }

            // 6. 检测子对象
            int childCount = source.transform.childCount;
            if (childCount > 0)
            {
                Debug.Log($"[LogicExtractor] 📂 检测到 {childCount} 个子对象");
                // 保存子对象信息到 mod.json 的 tags 里
                foreach (Transform child in source.transform)
                {
                    if (child != null)
                        logic.tags.Add("child:" + child.name);
                }
            }

            // 7. 保存
            LogicManagerV2.SaveToFile(logic);

            Debug.Log($"[LogicExtractor] ✅ 提取完成: {logic.GetDisplayName()}");
            return logic;
        }

        // ============================================================
        // 从场景提取（完整场景）
        // ============================================================
        public static LogicEntityV2 ExtractFromScene(string name, bool includeAllObjects = true)
        {
            LogicEntityV2 logic = LogicManagerV2.Create(name, LogicType.Scene);

            // 创建场景目录
            string sceneDir = Path.Combine(logic.FolderPath, "scenes");
            if (!Directory.Exists(sceneDir))
                Directory.CreateDirectory(sceneDir);

            // 创建模型/纹理/材质/动画目录（场景可能包含这些资源）
            string modelsDir = Path.Combine(logic.FolderPath, "models");
            string texturesDir = Path.Combine(logic.FolderPath, "textures");
            string audioDir = Path.Combine(logic.FolderPath, "audio");
            string materialsDir = Path.Combine(logic.FolderPath, "materials");
            string animationsDir = Path.Combine(logic.FolderPath, "animations");

            Directory.CreateDirectory(modelsDir);
            Directory.CreateDirectory(texturesDir);
            Directory.CreateDirectory(audioDir);
            Directory.CreateDirectory(materialsDir);
            Directory.CreateDirectory(animationsDir);

            // 获取场景所有根对象
            Scene currentScene = SceneManager.GetActiveScene();
            GameObject[] rootObjects = currentScene.GetRootGameObjects();

            Debug.Log($"[LogicExtractor] 🗺️ 场景: {currentScene.name}, 根对象: {rootObjects.Length}");

            // 统计
            int totalObjects = 0;
            int totalMeshes = 0;
            int totalTextures = 0;
            int totalMaterials = 0;
            int totalAnimations = 0;
            int totalAudio = 0;

            // 收集所有对象
            List<GameObject> allObjects = new List<GameObject>();
            foreach (var root in rootObjects)
            {
                if (root == null) continue;
                allObjects.Add(root);
                foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                {
                    if (child != null && child.gameObject != null)
                        allObjects.Add(child.gameObject);
                }
            }

            totalObjects = allObjects.Count;

            // 提取每个对象的 Mesh/Texture/Material/Animation
            HashSet<string> addedMeshes = new HashSet<string>();
            HashSet<string> addedTextures = new HashSet<string>();
            HashSet<string> addedMaterials = new HashSet<string>();
            HashSet<string> addedAnimations = new HashSet<string>();
            HashSet<string> addedAudio = new HashSet<string>();

            foreach (var obj in allObjects)
            {
                if (obj == null) continue;

                // ---- 提取 Mesh ----
                MeshFilter mf = obj.GetComponent<MeshFilter>();
                if (mf != null && mf.mesh != null && !addedMeshes.Contains(mf.mesh.name))
                {
                    addedMeshes.Add(mf.mesh.name);
                    string meshName = GetSafeName(mf.mesh.name, "mesh");
                    string path = Path.Combine(modelsDir, meshName + ".obj");
                    string objContent = MeshToObj(mf.mesh);
                    File.WriteAllText(path, objContent);
                    totalMeshes++;
                    if (string.IsNullOrEmpty(logic.resources.Model))
                        logic.resources.Model = $"models/{meshName}.obj";
                }

                // ---- 提取 SkinnedMesh ----
                SkinnedMeshRenderer smr = obj.GetComponent<SkinnedMeshRenderer>();
                if (smr != null && smr.sharedMesh != null && !addedMeshes.Contains(smr.sharedMesh.name))
                {
                    addedMeshes.Add(smr.sharedMesh.name);
                    string meshName = GetSafeName(smr.sharedMesh.name, "skinned");
                    string path = Path.Combine(modelsDir, meshName + ".obj");
                    string objContent = MeshToObj(smr.sharedMesh);
                    File.WriteAllText(path, objContent);
                    totalMeshes++;
                    if (string.IsNullOrEmpty(logic.resources.Model))
                        logic.resources.Model = $"models/{meshName}.obj";
                }

                // ---- 提取 Texture ----
                Renderer renderer = obj.GetComponent<Renderer>();
                if (renderer != null)
                {
                    foreach (var mat in renderer.sharedMaterials)
                    {
                        if (mat == null) continue;
                        if (mat.mainTexture != null)
                        {
                            Texture2D tex = mat.mainTexture as Texture2D;
                            if (tex != null && !addedTextures.Contains(tex.name))
                            {
                                addedTextures.Add(tex.name);
                                string texName = GetSafeName(tex.name, "texture");
                                string path = Path.Combine(texturesDir, texName + ".png");
                                try
                                {
                                    byte[] data = tex.EncodeToPNG();
                                    if (data != null && data.Length > 0)
                                    {
                                        File.WriteAllBytes(path, data);
                                        totalTextures++;
                                        logic.resources.Textures.Add($"textures/{texName}.png");
                                    }
                                }
                                catch { }
                            }
                        }

                        // ---- 提取 Material ----
                        if (!addedMaterials.Contains(mat.name))
                        {
                            addedMaterials.Add(mat.name);
                            string matName = GetSafeName(mat.name, "material");
                            string path = Path.Combine(materialsDir, matName + ".mat");
                            string content = SerializeMaterial(mat);
                            File.WriteAllText(path, content);
                            totalMaterials++;
                            logic.resources.Materials.Add($"materials/{matName}.mat");
                        }
                    }
                }

                // ---- 提取 Animation ----
                Animation anim = obj.GetComponent<Animation>();
                if (anim != null)
                {
                    foreach (AnimationState state in anim)
                    {
                        if (state == null || state.clip == null) continue;
                        if (!addedAnimations.Contains(state.clip.name))
                        {
                            addedAnimations.Add(state.clip.name);
                            string clipName = GetSafeName(state.clip.name, "anim");
                            string path = Path.Combine(animationsDir, clipName + ".anim");
                            string content = SerializeAnimationClip(state.clip);
                            File.WriteAllText(path, content);
                            totalAnimations++;
                            logic.resources.Animations.Add($"animations/{clipName}.anim");
                        }
                    }
                }

                // ---- 提取 Animator ----
                Animator animator = obj.GetComponent<Animator>();
                if (animator != null && animator.runtimeAnimatorController != null)
                {
                    var clips = animator.runtimeAnimatorController.animationClips;
                    foreach (var clip in clips)
                    {
                        if (clip == null) continue;
                        if (!addedAnimations.Contains(clip.name))
                        {
                            addedAnimations.Add(clip.name);
                            string clipName = GetSafeName(clip.name, "anim");
                            string path = Path.Combine(animationsDir, clipName + ".anim");
                            string content = SerializeAnimationClip(clip);
                            File.WriteAllText(path, content);
                            totalAnimations++;
                            logic.resources.Animations.Add($"animations/{clipName}.anim");
                        }
                    }
                }

                // ---- 提取 Audio ----
                AudioSource audioSource = obj.GetComponent<AudioSource>();
                if (audioSource != null && audioSource.clip != null && !addedAudio.Contains(audioSource.clip.name))
                {
                    addedAudio.Add(audioSource.clip.name);
                    string clipName = GetSafeName(audioSource.clip.name, "audio");
                    totalAudio++;
                    logic.resources.Audio.Add($"audio/{clipName}.wav");
                    // 音频无法运行时保存为 wav，只记录引用
                    Debug.Log($"[LogicExtractor] 🔊 记录音频: {audioSource.clip.name}");
                }
            }

            // ---- 保存场景列表 ----
            string sceneListPath = Path.Combine(sceneDir, "objects.json");
            string sceneJson = SerializeSceneObjects(allObjects);
            File.WriteAllText(sceneListPath, sceneJson);
            logic.resources.Scene = $"scenes/objects.json";

            // ---- 更新描述 ----
            logic.description = $"从场景 {currentScene.name} 提取，包含 {totalObjects} 个对象，{totalMeshes} 个模型，{totalTextures} 个纹理，{totalMaterials} 个材质，{totalAnimations} 个动画，{totalAudio} 个音频";

            // ---- 保存 ----
            logic.tags.Add($"scene:{currentScene.name}");
            logic.tags.Add($"objects:{totalObjects}");
            LogicManagerV2.SaveToFile(logic);

            Debug.Log($"[LogicExtractor] 🗺️ 场景提取完成: {logic.GetDisplayName()}");
            Debug.Log($"   📊 对象: {totalObjects}, 模型: {totalMeshes}, 纹理: {totalTextures}, 材质: {totalMaterials}, 动画: {totalAnimations}, 音频: {totalAudio}");

            return logic;
        }

        // ============================================================
        // 序列化场景对象列表
        // ============================================================
        private static string SerializeSceneObjects(List<GameObject> objects)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[");
            for (int i = 0; i < objects.Count; i++)
            {
                var obj = objects[i];
                if (obj == null) continue;

                sb.AppendLine("  {");
                sb.AppendLine($"    \"name\": \"{EscapeJson(obj.name)}\",");
                sb.AppendLine($"    \"tag\": \"{EscapeJson(obj.tag)}\",");
                sb.AppendLine($"    \"layer\": {obj.layer},");
                sb.AppendLine($"    \"active\": {obj.activeSelf.ToString().ToLower()},");
                sb.AppendLine($"    \"position\": \"{obj.transform.position.x:F3},{obj.transform.position.y:F3},{obj.transform.position.z:F3}\",");
                sb.AppendLine($"    \"rotation\": \"{obj.transform.rotation.eulerAngles.x:F3},{obj.transform.rotation.eulerAngles.y:F3},{obj.transform.rotation.eulerAngles.z:F3}\",");
                sb.AppendLine($"    \"scale\": \"{obj.transform.localScale.x:F3},{obj.transform.localScale.y:F3},{obj.transform.localScale.z:F3}\",");
                sb.AppendLine($"    \"components\": [");

                Component[] comps = obj.GetComponents<Component>();
                for (int j = 0; j < comps.Length; j++)
                {
                    var comp = comps[j];
                    if (comp == null) continue;
                    if (comp is Transform) continue;
                    string compName = comp.GetType().Name;
                    sb.Append($"      \"{compName}\"");
                    if (j < comps.Length - 1) sb.Append(",");
                    sb.AppendLine();
                }

                sb.AppendLine("    ]");

                if (i < objects.Count - 1)
                    sb.AppendLine("  },");
                else
                    sb.AppendLine("  }");
            }
            sb.AppendLine("]");
            return sb.ToString();
        }

        // ============================================================
        // 工具方法
        // ============================================================

        private static string GetSafeName(string name, string fallback)
        {
            if (string.IsNullOrEmpty(name) || name == "Mesh" || name == "Texture")
                return $"{fallback}_{Guid.NewGuid().ToString().Substring(0, 6)}";
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        private static string EscapeJson(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\\", "\\\\").Replace("\"", "\\\"")
                       .Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");
        }

        // ============================================================
        // Mesh → OBJ
        // ============================================================
        private static string MeshToObj(Mesh mesh)
        {
            if (mesh == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"# Extracted by SuperConsole");
            sb.AppendLine($"# Mesh: {mesh.name}");

            foreach (Vector3 v in mesh.vertices)
                sb.AppendLine($"v {v.x:F6} {v.y:F6} {v.z:F6}");

            if (mesh.uv.Length > 0)
                foreach (Vector2 uv in mesh.uv)
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");

            foreach (Vector3 n in mesh.normals)
                sb.AppendLine($"vn {n.x:F6} {n.y:F6} {n.z:F6}");

            int[] triangles = mesh.triangles;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int v1 = triangles[i] + 1;
                int v2 = triangles[i + 1] + 1;
                int v3 = triangles[i + 2] + 1;
                if (mesh.uv.Length > 0)
                    sb.AppendLine($"f {v1}/{v1} {v2}/{v2} {v3}/{v3}");
                else
                    sb.AppendLine($"f {v1} {v2} {v3}");
            }
            return sb.ToString();
        }

        // ============================================================
        // 序列化材质
        // ============================================================
        private static string SerializeMaterial(Material mat)
        {
            if (mat == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"# SuperConsole Material Export");
            sb.AppendLine($"# Material: {mat.name}");
            sb.AppendLine($"shader: {mat.shader?.name ?? "Standard"}");
            sb.AppendLine($"renderQueue: {mat.renderQueue}");

            if (mat.HasProperty("_Color"))
            {
                Color c = mat.GetColor("_Color");
                sb.AppendLine($"color: {c.r:F4}, {c.g:F4}, {c.b:F4}, {c.a:F4}");
            }
            if (mat.HasProperty("_MainTex") && mat.mainTexture != null)
                sb.AppendLine($"mainTexture: {mat.mainTexture.name}");
            if (mat.HasProperty("_Metallic"))
                sb.AppendLine($"metallic: {mat.GetFloat("_Metallic"):F4}");
            if (mat.HasProperty("_Glossiness"))
                sb.AppendLine($"smoothness: {mat.GetFloat("_Glossiness"):F4}");
            return sb.ToString();
        }

        // ============================================================
        // 序列化动画
        // ============================================================
        private static string SerializeAnimationClip(AnimationClip clip)
        {
            if (clip == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"# SuperConsole Animation Export");
            sb.AppendLine($"# Clip: {clip.name}");
            sb.AppendLine($"frameRate: {clip.frameRate:F2}");
            sb.AppendLine($"length: {clip.length:F4}");
            sb.AppendLine($"loop: {clip.isLooping}");
            sb.AppendLine($"events: {clip.events.Length}");

            foreach (var evt in clip.events)
            {
                sb.AppendLine($"  event: {evt.time:F4} | {evt.functionName} | {evt.stringParameter} | {evt.floatParameter:F4}");
            }
            return sb.ToString();
        }
    }
}
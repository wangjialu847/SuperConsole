﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SuperConsole
{
    public static class LogicUI_V2
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(0, 0, Screen.width, Screen.height);
        private static Vector2 scrollPos = Vector2.zero;
        private static LogicEntityV2 editingLogic = null;

        // ===== 加载状态跟踪 =====
        private static string statusMessage = "";
        private static float statusTimer = 0f;
        private static Color statusColor = Color.white;

        // ===== 组件管理 - 自动补全 =====
        private static string addComponentInput = "";
        private static bool showComponentDropdown = false;
        private static int componentSelectedIndex = -1;
        private static List<string> componentSuggestions = new List<string>();
        private static Rect addComponentRect = Rect.zero;
        private static Vector2 dropdownScrollPos = Vector2.zero;
        private static int dropdownWindowId = 12400;

        // ===== 组件管理 - 组件列表滚动 =====
        private static Vector2 componentListScroll = Vector2.zero;

        // ===== 自动补全控件名称 =====
        private const string AUTOCOMPLETE_CONTROL_NAME = "logicAutoCompleteInput";

        public static Rect GetWindowRect() => windowRect;
        public static void ResetPosition() => windowRect = new Rect(0, 0, Screen.width, Screen.height);

        public static void Toggle()
        {
            visible = !visible;
            if (visible)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
                statusMessage = "";
                statusTimer = 0f;

                if (editingLogic == null)
                {
                    var all = LogicManagerV2.GetAll();
                    if (all.Count > 0) editingLogic = all[0];
                }
                RefreshLoadStatus();
                LoadComponentTypes();
                addComponentInput = "";
                showComponentDropdown = false;
                componentSelectedIndex = -1;
            }
        }

        public static bool IsVisible() => visible;

        // ===== 刷新加载状态 =====
        private static void RefreshLoadStatus()
        {
            foreach (var logic in LogicManagerV2.GetAll())
            {
                if (logic.GameObject != null)
                {
                    try
                    {
                        if (logic.GameObject == null || logic.GameObject.Equals(null))
                        {
                            logic.GameObject = null;
                            logic.IsLoaded = false;
                        }
                        else
                        {
                            logic.IsLoaded = true;
                        }
                    }
                    catch
                    {
                        logic.GameObject = null;
                        logic.IsLoaded = false;
                    }
                }
                else
                {
                    logic.IsLoaded = false;
                }
            }
        }

        // ===== 加载组件类型 =====
        private static void LoadComponentTypes()
        {
            componentSuggestions.Clear();
            try
            {
                var types = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(a => { try { return a.GetTypes(); } catch { return new Type[0]; } })
                    .Where(t => typeof(Component).IsAssignableFrom(t) && !t.IsAbstract && !t.IsInterface)
                    .Select(t => t.Name)
                    .Distinct()
                    .OrderBy(n => n)
                    .ToList();

                componentSuggestions.AddRange(types);
                Debug.Log($"[LogicUI_V2] 加载了 {componentSuggestions.Count} 个组件类型");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicUI_V2] 加载组件类型失败: {ex.Message}");
            }
        }

        private static Type FindType(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;

            Type targetType = Type.GetType(typeName);
            if (targetType != null) return targetType;

            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    targetType = asm.GetType(typeName);
                    if (targetType != null) return targetType;

                    foreach (var t in asm.GetTypes())
                    {
                        if (t.Name == typeName || t.FullName == typeName)
                            return t;
                    }
                }
                catch { }
            }
            return null;
        }

        public static void Draw()
        {
            if (!visible) return;
            GUI.FocusWindow(12360);
            windowRect = GUI.Window(12360, windowRect, DrawWindow, "逻辑体编辑器 V2 [Esc关闭]");

            // ✅ 在主窗口之上绘制下拉列表（使用 GUI.Window）
            DrawDropdownWindow();
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            if (windowRect.width < Screen.width * 0.8f || windowRect.height < Screen.height * 0.8f)
            {
                windowRect = new Rect(0, 0, Screen.width, Screen.height);
            }

            if (statusTimer > 0)
            {
                statusTimer -= Time.deltaTime;
                if (statusTimer <= 0) statusMessage = "";
            }

            GUILayout.BeginVertical();

            DrawTitleBar();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (editingLogic == null)
            {
                GUILayout.Label("没有逻辑体，点击「新建」创建");
                GUILayout.EndVertical();
                GUI.DragWindow();
                return;
            }

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.ExpandHeight(true));

            DrawBasicInfo();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            DrawResourceInfo();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            DrawActionButtons();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            DrawComponentTab();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            DrawStatusBar();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("💡 在对象浏览器中选中对象 → 点击「提取当前对象」", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("关闭", GUILayout.Width(60))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndScrollView();
            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        // ============================================================
        // 标题栏
        // ============================================================
        private static void DrawTitleBar()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("逻辑体列表", GUILayout.Width(100));

            var all = LogicManagerV2.GetAll();
            string[] names = all.Select(l => l.GetDisplayName()).ToArray();
            int idx = editingLogic != null ? Array.IndexOf(names, editingLogic.GetDisplayName()) : -1;
            if (idx < 0 && names.Length > 0) idx = 0;

            int newIdx = GUILayout.SelectionGrid(
                idx >= 0 ? idx : 0,
                names.Length > 0 ? names : new string[] { "(无)" },
                4,
                GUILayout.ExpandWidth(true)
            );

            if (newIdx >= 0 && newIdx < names.Length && (editingLogic == null || editingLogic.GetDisplayName() != names[newIdx]))
            {
                editingLogic = LogicManagerV2.GetAll()[newIdx];
                RefreshLoadStatus();
                statusMessage = $"已切换到: {editingLogic.GetDisplayName()}";
                statusTimer = 2f;
                statusColor = Color.cyan;
                addComponentInput = "";
                showComponentDropdown = false;
            }

            if (GUILayout.Button("新建", GUILayout.Width(50)))
            {
                var logic = LogicManagerV2.Create("新逻辑体_" + (all.Count + 1));
                editingLogic = logic;
                statusMessage = $"✅ 已创建: {logic.GetDisplayName()}";
                statusTimer = 2f;
                statusColor = Color.green;
            }

            if (GUILayout.Button("刷新", GUILayout.Width(50)))
            {
                LogicManagerV2.Refresh();
                RefreshLoadStatus();
                var list = LogicManagerV2.GetAll();
                if (list.Count > 0 && editingLogic != null)
                {
                    editingLogic = list.FirstOrDefault(l => l.id == editingLogic.id);
                    if (editingLogic == null) editingLogic = list[0];
                }
                statusMessage = $"🔄 已刷新，共 {list.Count} 个逻辑体";
                statusTimer = 2f;
                statusColor = Color.white;
            }

            if (GUILayout.Button("导出 .mod", GUILayout.Width(80)))
            {
                if (editingLogic != null)
                {
                    LogicManagerV2.ExportToMod(editingLogic.id);
                    statusMessage = $"📦 导出 .mod 成功: {editingLogic.name}";
                    statusTimer = 2f;
                    statusColor = Color.green;
                }
            }

            if (GUILayout.Button("导入 .mod", GUILayout.Width(80)))
            {
                string logicsPath = Path.Combine(BepInEx.Paths.PluginPath, "SuperConsole", "Logics");
                if (Directory.Exists(logicsPath))
                {
                    string[] modFiles = Directory.GetFiles(logicsPath, "*.mod");
                    if (modFiles.Length == 0)
                    {
                        statusMessage = "❌ 没有找到 .mod 文件";
                        statusTimer = 2f;
                        statusColor = Color.red;
                    }
                    else
                    {
                        int count = 0;
                        foreach (string modFile in modFiles)
                        {
                            LogicManagerV2.ImportMod(modFile);
                            count++;
                        }
                        statusMessage = $"📦 导入了 {count} 个 .mod 文件";
                        statusTimer = 2f;
                        statusColor = Color.green;
                    }
                }
                LogicManagerV2.Refresh();
                RefreshLoadStatus();
                var list = LogicManagerV2.GetAll();
                if (list.Count > 0) editingLogic = list[0];
            }

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 基本信息
        // ============================================================
        private static void DrawBasicInfo()
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("名称:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_name");
            string n = GUILayout.TextField(editingLogic.name, GUILayout.Width(150));
            if (n != editingLogic.name) editingLogic.name = n;

            GUILayout.Label("ID:", GUILayout.Width(25));
            GUILayout.Label(editingLogic.id, GUILayout.Width(120));

            GUILayout.Label("类型:", GUILayout.Width(35));
            string[] types = Enum.GetNames(typeof(LogicType));
            int ti = Array.IndexOf(types, editingLogic.type.ToString());
            int nt = GUILayout.SelectionGrid(ti >= 0 ? ti : 0, types, 8, GUILayout.ExpandWidth(true));
            if (nt >= 0) editingLogic.type = (LogicType)nt;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("版本:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_version");
            string v = GUILayout.TextField(editingLogic.version, GUILayout.Width(80));
            if (v != editingLogic.version) editingLogic.version = v;

            GUILayout.Label("作者:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_author");
            string a = GUILayout.TextField(editingLogic.author, GUILayout.Width(120));
            if (a != editingLogic.author) editingLogic.author = a;

            bool isLoaded = editingLogic.IsLoaded && editingLogic.GameObject != null;

            if (isLoaded)
            {
                try
                {
                    if (editingLogic.GameObject == null || editingLogic.GameObject.Equals(null))
                    {
                        isLoaded = false;
                        editingLogic.IsLoaded = false;
                        editingLogic.GameObject = null;
                    }
                }
                catch
                {
                    isLoaded = false;
                    editingLogic.IsLoaded = false;
                    editingLogic.GameObject = null;
                }
            }

            GUI.color = isLoaded ? Color.green : Color.gray;
            GUILayout.Label(isLoaded ? "✅ 已加载" : "⏳ 未加载", GUILayout.Width(80));
            GUI.color = Color.white;

            if (isLoaded && editingLogic.GameObject != null)
            {
                GUILayout.Label($"位置: {editingLogic.GameObject.transform.position:F2}", GUILayout.Width(150));
            }

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("描述:", GUILayout.Width(35));
            GUI.SetNextControlName("v2_desc");
            string d = GUILayout.TextField(editingLogic.description, GUILayout.ExpandWidth(true));
            if (d != editingLogic.description) editingLogic.description = d;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("状态:", GUILayout.Width(35));
            GUILayout.Label(editingLogic.GetStatusText(), GUILayout.Width(80));

            if (GUILayout.Button(editingLogic.enabled ? "禁用" : "启用", GUILayout.Width(50)))
            {
                editingLogic.enabled = !editingLogic.enabled;
                LogicManagerV2.SaveToFile(editingLogic);
                statusMessage = editingLogic.enabled ? "✅ 已启用" : "⏸️ 已禁用";
                statusTimer = 2f;
                statusColor = editingLogic.enabled ? Color.green : Color.yellow;
            }

            if (GUILayout.Button("保存", GUILayout.Width(50)))
            {
                LogicManagerV2.SaveToFile(editingLogic);
                statusMessage = "💾 已保存";
                statusTimer = 2f;
                statusColor = Color.green;
            }

            if (GUILayout.Button("删除", GUILayout.Width(50)))
            {
                if (editingLogic.GameObject != null)
                {
                    UnityEngine.Object.Destroy(editingLogic.GameObject);
                    editingLogic.GameObject = null;
                    editingLogic.IsLoaded = false;
                }
                LogicManagerV2.Delete(editingLogic.id);
                var list = LogicManagerV2.GetAll();
                editingLogic = list.Count > 0 ? list[0] : null;
                statusMessage = "🗑️ 已删除";
                statusTimer = 2f;
                statusColor = Color.red;
            }

            if (isLoaded)
            {
                if (GUILayout.Button("清除实例", GUILayout.Width(60)))
                {
                    if (editingLogic.GameObject != null)
                    {
                        UnityEngine.Object.Destroy(editingLogic.GameObject);
                        editingLogic.GameObject = null;
                        editingLogic.IsLoaded = false;
                        statusMessage = $"🗑️ 已清除实例: {editingLogic.GetDisplayName()}";
                        statusTimer = 2f;
                        statusColor = Color.yellow;
                    }
                }
            }

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 资源信息
        // ============================================================
        private static void DrawResourceInfo()
        {
            GUILayout.Label("📦 资源", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label($"预制体: {(string.IsNullOrEmpty(editingLogic.resources.Prefab) ? "(无)" : editingLogic.resources.Prefab)}", GUILayout.Width(250));
            GUILayout.Label($"模型: {(string.IsNullOrEmpty(editingLogic.resources.Model) ? "(无)" : editingLogic.resources.Model)}", GUILayout.Width(250));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("纹理: " + (editingLogic.resources.Textures?.Count ?? 0), GUILayout.Width(80));
            GUILayout.Label("音频: " + (editingLogic.resources.Audio?.Count ?? 0), GUILayout.Width(80));
            GUILayout.Label("材质: " + (editingLogic.resources.Materials?.Count ?? 0), GUILayout.Width(80));
            GUILayout.Label("动画: " + (editingLogic.resources.Animations?.Count ?? 0), GUILayout.Width(80));
            GUILayout.Label("脚本: " + (editingLogic.resources.Scripts?.Count ?? 0), GUILayout.Width(80));
            if (!string.IsNullOrEmpty(editingLogic.resources.DLL))
                GUILayout.Label($"DLL: {editingLogic.resources.DLL}", GUILayout.Width(150));
            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 操作按钮
        // ============================================================
        private static void DrawActionButtons()
        {
            GUILayout.Label("🚀 操作", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();

            if (GUILayout.Button("提取当前对象", GUILayout.Height(30)))
            {
                if (SuperConsole.selectedObject != null)
                {
                    LogicExtractorUI.Toggle(SuperConsole.selectedObject);
                    LogicManagerV2.Refresh();
                    RefreshLoadStatus();
                    var list = LogicManagerV2.GetAll();
                    if (list.Count > 0) editingLogic = list[0];
                    statusMessage = $"📦 提取选项已打开: {SuperConsole.selectedObject.name}";
                    statusTimer = 2f;
                    statusColor = Color.cyan;
                }
                else
                {
                    statusMessage = "⚠️ 请先在对象浏览器中选中一个对象";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            if (GUILayout.Button("提取场景", GUILayout.Height(30)))
            {
                string sceneName = SceneManager.GetActiveScene().name;
                if (string.IsNullOrEmpty(sceneName)) sceneName = "未命名场景";
                LogicExtractor.ExtractFromScene(sceneName);
                LogicManagerV2.Refresh();
                RefreshLoadStatus();
                var list = LogicManagerV2.GetAll();
                if (list.Count > 0) editingLogic = list[list.Count - 1];
                statusMessage = $"🗺️ 场景提取完成: {sceneName}";
                statusTimer = 2f;
                statusColor = Color.green;
            }

            if (GUILayout.Button("3D 预览", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                {
                    LogicPreview3D.Toggle(editingLogic);
                    statusMessage = $"🎮 3D 预览已打开: {editingLogic.name}";
                    statusTimer = 2f;
                    statusColor = Color.cyan;
                }
                else
                {
                    statusMessage = "⚠️ 请先选择一个逻辑体";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();

            if (GUILayout.Button("🎯 召唤到玩家", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                {
                    GameObject result = LogicSpawnerV2.SpawnAtPlayer(editingLogic.id);
                    if (result != null)
                    {
                        editingLogic.IsLoaded = true;
                        editingLogic.GameObject = result;
                        statusMessage = $"✅ 已召唤到玩家: {editingLogic.GetDisplayName()}";
                        statusTimer = 2f;
                        statusColor = Color.green;
                    }
                    else
                    {
                        statusMessage = "❌ 召唤失败，请检查玩家是否存在";
                        statusTimer = 2f;
                        statusColor = Color.red;
                    }
                }
                else
                {
                    statusMessage = "⚠️ 请先选择一个逻辑体";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            if (GUILayout.Button("🖱️ 召唤到鼠标", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                {
                    GameObject result = LogicSpawnerV2.SpawnAtMouse(editingLogic.id);
                    if (result != null)
                    {
                        editingLogic.IsLoaded = true;
                        editingLogic.GameObject = result;
                        statusMessage = $"✅ 已召唤到鼠标位置: {editingLogic.GetDisplayName()}";
                        statusTimer = 2f;
                        statusColor = Color.green;
                    }
                    else
                    {
                        statusMessage = "❌ 召唤失败";
                        statusTimer = 2f;
                        statusColor = Color.red;
                    }
                }
                else
                {
                    statusMessage = "⚠️ 请先选择一个逻辑体";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            if (GUILayout.Button("🎯 召唤到选中对象", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                {
                    if (SuperConsole.selectedObject != null)
                    {
                        GameObject result = LogicSpawnerV2.SpawnAtSelectedObject(editingLogic.id);
                        if (result != null)
                        {
                            editingLogic.IsLoaded = true;
                            editingLogic.GameObject = result;
                            statusMessage = $"✅ 已召唤到选中对象: {SuperConsole.selectedObject.name} → {editingLogic.GetDisplayName()}";
                            statusTimer = 2f;
                            statusColor = Color.green;
                        }
                        else
                        {
                            statusMessage = "❌ 召唤失败";
                            statusTimer = 2f;
                            statusColor = Color.red;
                        }
                    }
                    else
                    {
                        statusMessage = "⚠️ 请先在对象浏览器中选中一个对象";
                        statusTimer = 2f;
                        statusColor = Color.yellow;
                    }
                }
                else
                {
                    statusMessage = "⚠️ 请先选择一个逻辑体";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            if (GUILayout.Button("📍 召唤到坐标", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                {
                    LogicSpawnCoordUI.Toggle(editingLogic);
                    statusMessage = "📍 请输入坐标";
                    statusTimer = 2f;
                    statusColor = Color.cyan;
                }
                else
                {
                    statusMessage = "⚠️ 请先选择一个逻辑体";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();

            if (GUILayout.Button("📊 批量召唤 (5个)", GUILayout.Height(30)))
            {
                if (editingLogic != null)
                {
                    LogicSpawnerV2.SpawnMultiple(editingLogic.id, Vector3.zero, 5, 2f);
                    RefreshLoadStatus();
                    statusMessage = $"📊 批量召唤 5 个 {editingLogic.GetDisplayName()}";
                    statusTimer = 2f;
                    statusColor = Color.green;
                }
                else
                {
                    statusMessage = "⚠️ 请先选择一个逻辑体";
                    statusTimer = 2f;
                    statusColor = Color.yellow;
                }
            }

            if (GUILayout.Button("🗑️ 清除所有实例", GUILayout.Height(30)))
            {
                int count = 0;
                foreach (var logic in LogicManagerV2.GetAll())
                {
                    if (logic.GameObject != null)
                    {
                        try
                        {
                            UnityEngine.Object.Destroy(logic.GameObject);
                            count++;
                        }
                        catch { }
                        logic.GameObject = null;
                        logic.IsLoaded = false;
                    }
                }
                statusMessage = $"🗑️ 清除了 {count} 个逻辑体实例";
                statusTimer = 2f;
                statusColor = Color.yellow;
            }

            if (GUILayout.Button("🔄 刷新状态", GUILayout.Height(30)))
            {
                RefreshLoadStatus();
                int loadedCount = LogicManagerV2.GetAll().Count(l => l.IsLoaded);
                statusMessage = $"🔄 已刷新，{loadedCount} 个已加载";
                statusTimer = 2f;
                statusColor = Color.white;
            }

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 组件管理 Tab
        // ============================================================
        private static void DrawComponentTab()
        {
            GUILayout.Label("🧩 组件管理 - 给逻辑体对象添加/管理组件", GUILayout.ExpandWidth(true));
            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            bool isSpawned = editingLogic != null && editingLogic.GameObject != null;

            if (!isSpawned)
            {
                GUILayout.Label("⚠️ 逻辑体尚未召唤到场景，无法管理组件");
                GUILayout.Label("💡 请先点击「召唤到玩家」或「召唤到鼠标」将逻辑体召出");
                GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));
                return;
            }

            GUILayout.Label($"📋 当前对象: {editingLogic.GameObject.name} 的组件", GUILayout.ExpandWidth(true));

            componentListScroll = GUILayout.BeginScrollView(componentListScroll, GUILayout.Height(120));

            var comps = editingLogic.GameObject.GetComponents<Component>();
            if (comps.Length == 0)
            {
                GUILayout.Label("  (没有组件)");
            }
            else
            {
                foreach (var comp in comps)
                {
                    if (comp == null) continue;
                    GUILayout.BeginHorizontal("box");

                    string compName = comp.GetType().Name;
                    GUILayout.Label($"  {compName}", GUILayout.Width(200));

                    if (comp is Behaviour behaviour)
                    {
                        bool enabled = GUILayout.Toggle(behaviour.enabled, "启用", GUILayout.Width(50));
                        if (enabled != behaviour.enabled) behaviour.enabled = enabled;
                    }

                    if (GUILayout.Button("删除", GUILayout.Width(50)))
                    {
                        UnityEngine.Object.Destroy(comp);
                        Debug.Log($"[LogicUI_V2] 已删除组件: {compName}");
                        break;
                    }
                    GUILayout.EndHorizontal();
                }
            }

            GUILayout.EndScrollView();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== 添加组件（带自动补全） =====
            GUILayout.Label("➕ 添加组件:", GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("组件名:", GUILayout.Width(50));

            // ✅ 核心修复：使用固定 Control Name
            GUI.SetNextControlName(AUTOCOMPLETE_CONTROL_NAME);
            string newComponent = GUILayout.TextField(addComponentInput, GUILayout.Width(200));

            // 获取输入框位置（用于绘制下拉列表）
            if (Event.current.type == EventType.Repaint)
            {
                addComponentRect = GUILayoutUtility.GetLastRect();
                // 将位置转换为屏幕坐标
                addComponentRect.x += windowRect.x;
                addComponentRect.y += windowRect.y;
            }

            // 检测输入变化
            if (newComponent != addComponentInput)
            {
                addComponentInput = newComponent;
                componentSelectedIndex = -1;

                if (!string.IsNullOrEmpty(addComponentInput))
                {
                    var matches = GetMatches();
                    showComponentDropdown = matches.Count > 0;
                    dropdownScrollPos = Vector2.zero;
                }
                else
                {
                    showComponentDropdown = false;
                }
            }

            if (GUILayout.Button("添加", GUILayout.Width(50)))
            {
                AddComponentFromInput();
            }
            GUILayout.EndHorizontal();

            // 显示匹配数量提示
            if (showComponentDropdown && !string.IsNullOrEmpty(addComponentInput))
            {
                var matches = GetMatches();
                if (matches.Count > 0)
                {
                    GUILayout.Label($"💡 找到 {matches.Count} 个匹配组件 (按 ↑↓ 选择，Enter 确认)", GUILayout.ExpandWidth(true));
                }
            }

            GUILayout.Label("💡 组件名会自动补全，输入几个字母即可选择", GUILayout.ExpandWidth(true));
            GUILayout.Label("💡 添加后组件会立即生效，无需重启", GUILayout.ExpandWidth(true));
        }

        // ============================================================
        // ✅ 自动补全核心方法（使用 GUI.Window）
        // ============================================================

        private static List<string> GetMatches()
        {
            if (string.IsNullOrEmpty(addComponentInput))
                return new List<string>();

            return componentSuggestions
                .Where(s => s.StartsWith(addComponentInput, StringComparison.OrdinalIgnoreCase))
                .OrderBy(s => s)
                .ToList();
        }

        /// <summary>
        /// 使用 GUI.Window 绘制下拉列表
        /// </summary>
        private static void DrawDropdownWindow()
        {
            if (!showComponentDropdown || string.IsNullOrEmpty(addComponentInput))
                return;

            var matches = GetMatches();
            if (matches.Count == 0)
            {
                showComponentDropdown = false;
                return;
            }

            // 计算下拉列表位置
            float maxHeight = 180f;
            float itemHeight = 20f;
            float totalHeight = Math.Min(matches.Count * itemHeight, maxHeight);
            bool needsScroll = matches.Count * itemHeight > maxHeight;

            Rect dropdownRect = new Rect(
                addComponentRect.x,
                addComponentRect.y + addComponentRect.height + 2,
                Math.Max(220, addComponentRect.width),
                totalHeight + (needsScroll ? 16 : 0)
            );

            // 确保在屏幕内
            if (dropdownRect.x + dropdownRect.width > Screen.width)
                dropdownRect.x = Screen.width - dropdownRect.width - 10;
            if (dropdownRect.y + dropdownRect.height > Screen.height)
                dropdownRect.y = Screen.height - dropdownRect.height - 10;

            // 使用 GUI.Window
            GUI.Window(dropdownWindowId, dropdownRect, (id) =>
            {
                // ✅ 键盘导航 - 直接在 Window 内处理
                if (Event.current.type == EventType.KeyDown)
                {
                    // 检查焦点是否在输入框上
                    if (GUI.GetNameOfFocusedControl() == AUTOCOMPLETE_CONTROL_NAME)
                    {
                        if (Event.current.keyCode == KeyCode.DownArrow)
                        {
                            componentSelectedIndex = Math.Min(componentSelectedIndex + 1, matches.Count - 1);
                            Event.current.Use();
                        }
                        else if (Event.current.keyCode == KeyCode.UpArrow)
                        {
                            componentSelectedIndex = Math.Max(componentSelectedIndex - 1, 0);
                            Event.current.Use();
                        }
                        else if (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.Tab)
                        {
                            if (componentSelectedIndex >= 0 && componentSelectedIndex < matches.Count)
                            {
                                addComponentInput = matches[componentSelectedIndex];
                                showComponentDropdown = false;
                                componentSelectedIndex = -1;
                                GUI.FocusControl(null);
                                Event.current.Use();
                            }
                        }
                        else if (Event.current.keyCode == KeyCode.Escape)
                        {
                            showComponentDropdown = false;
                            componentSelectedIndex = -1;
                            Event.current.Use();
                        }
                    }
                }

                // 绘制匹配列表（支持滚轮）
                dropdownScrollPos = GUILayout.BeginScrollView(dropdownScrollPos, GUILayout.Height(dropdownRect.height - 16));

                for (int i = 0; i < matches.Count; i++)
                {
                    string match = matches[i];
                    GUILayout.BeginHorizontal();

                    if (i == componentSelectedIndex)
                        GUI.backgroundColor = new Color(0.3f, 0.5f, 0.8f);

                    if (GUILayout.Button(match, GUILayout.ExpandWidth(true), GUILayout.Height(itemHeight)))
                    {
                        addComponentInput = match;
                        showComponentDropdown = false;
                        componentSelectedIndex = -1;
                        GUI.FocusControl(null);
                    }

                    GUI.backgroundColor = Color.white;
                    GUILayout.EndHorizontal();
                }

                GUILayout.EndScrollView();

            }, "", GUI.skin.box);
        }

        private static void AddComponentFromInput()
        {
            if (string.IsNullOrEmpty(addComponentInput) || editingLogic == null || editingLogic.GameObject == null)
                return;

            string matchedType = FindMatchingType(addComponentInput, componentSuggestions);
            if (!string.IsNullOrEmpty(matchedType))
            {
                Type compType = FindType(matchedType);
                if (compType != null && typeof(Component).IsAssignableFrom(compType))
                {
                    editingLogic.GameObject.AddComponent(compType);
                    Debug.Log($"[LogicUI_V2] ✅ 已添加组件: {matchedType} 到 {editingLogic.GameObject.name}");
                    statusMessage = $"✅ 已添加组件: {matchedType}";
                    statusTimer = 2f;
                    statusColor = Color.green;
                    addComponentInput = "";
                    showComponentDropdown = false;
                    componentSelectedIndex = -1;
                    LoadComponentTypes();
                }
                else
                {
                    statusMessage = $"❌ 找不到组件类型: {matchedType}";
                    statusTimer = 2f;
                    statusColor = Color.red;
                }
            }
            else
            {
                statusMessage = $"❌ 找不到组件类型: {addComponentInput}";
                statusTimer = 2f;
                statusColor = Color.red;
            }
        }

        private static string FindMatchingType(string input, List<string> suggestions)
        {
            if (string.IsNullOrEmpty(input)) return null;

            if (suggestions.Contains(input))
                return input;

            var matches = suggestions
                .Where(s => s.StartsWith(input, StringComparison.OrdinalIgnoreCase))
                .OrderBy(s => s)
                .ToList();

            if (matches.Count == 1)
                return matches[0];
            if (matches.Count > 0 && input.Length > 3)
                return matches[0];

            return null;
        }

        // ============================================================
        // 状态栏
        // ============================================================
        private static void DrawStatusBar()
        {
            GUILayout.BeginHorizontal();

            var all = LogicManagerV2.GetAll();
            int loadedCount = all.Count(l => l.IsLoaded);
            int totalCount = all.Count;
            GUILayout.Label($"📊 共 {totalCount} 个逻辑体，{loadedCount} 个已加载", GUILayout.Width(250));

            if (editingLogic != null)
            {
                bool isLoaded = editingLogic.IsLoaded && editingLogic.GameObject != null;
                if (isLoaded)
                {
                    try
                    {
                        if (editingLogic.GameObject == null || editingLogic.GameObject.Equals(null))
                        {
                            isLoaded = false;
                            editingLogic.IsLoaded = false;
                            editingLogic.GameObject = null;
                        }
                    }
                    catch
                    {
                        isLoaded = false;
                        editingLogic.IsLoaded = false;
                        editingLogic.GameObject = null;
                    }
                }

                GUI.color = isLoaded ? Color.green : Color.gray;
                GUILayout.Label(isLoaded ? "✅ 当前已加载" : "⏳ 当前未加载", GUILayout.Width(120));
                GUI.color = Color.white;

                if (isLoaded && editingLogic.GameObject != null)
                {
                    GUILayout.Label($"位置: {editingLogic.GameObject.transform.position:F2}", GUILayout.Width(180));
                }
            }

            GUILayout.FlexibleSpace();

            if (!string.IsNullOrEmpty(statusMessage))
            {
                GUI.color = statusColor;
                GUILayout.Label(statusMessage, GUILayout.Width(300));
                GUI.color = Color.white;
            }

            GUILayout.EndHorizontal();
        }

        // ============================================================
        // 外部调用接口
        // ============================================================

        public static void ShowStatus(string message, float duration = 2f, Color? color = null)
        {
            statusMessage = message;
            statusTimer = duration;
            statusColor = color ?? Color.white;
        }

        public static void RefreshAndUpdate()
        {
            LogicManagerV2.Refresh();
            RefreshLoadStatus();
            var list = LogicManagerV2.GetAll();
            if (list.Count > 0 && editingLogic != null)
            {
                editingLogic = list.FirstOrDefault(l => l.id == editingLogic.id);
                if (editingLogic == null) editingLogic = list[0];
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using BepInEx;

namespace SuperConsole
{
    public static class LogicSpawnerV2
    {
        // ===== 召唤到玩家 =====
        public static GameObject SpawnAtPlayer(string id)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }

            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player == null)
            {
                player = GameObject.Find("PlayerCharacter(Clone)");
            }
            if (player == null)
            {
                player = GameObject.Find("Player");
            }
            if (player == null)
            {
                Debug.LogError("[LogicSpawnerV2] ❌ 找不到玩家");
                return null;
            }
            return SpawnAtPosition(logic, player.transform.position);
        }

        // ===== 召唤到坐标 =====
        public static GameObject SpawnAtCoordinates(string id, Vector3 position)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }
            return SpawnAtPosition(logic, position);
        }

        // ===== 召唤到鼠标（修复版） =====
        public static GameObject SpawnAtMouse(string id)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }

            Vector3 spawnPos = Vector3.zero;
            bool found = false;

            try
            {
                Camera cam = Camera.main;
                if (cam == null)
                {
                    Debug.LogError("[LogicSpawnerV2] ❌ 找不到主摄像机");
                    return SpawnAtPosition(logic, Vector3.zero);
                }

                Ray ray = cam.ScreenPointToRay(Input.mousePosition);

                // 方法1: Physics.Raycast (带层过滤)
                int layerMask = ~LayerMask.GetMask("UI", "Ignore Raycast", "Water");
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit, 1000f, layerMask))
                {
                    spawnPos = hit.point;
                    found = true;
                    Debug.Log("[LogicSpawnerV2] ✅ 点击到物体: " + hit.collider.name + " 位置: " + spawnPos);
                }

                // 方法2: Plane 检测 (地面平面)
                if (!found)
                {
                    Plane groundPlane = new Plane(Vector3.up, Vector3.zero);
                    float distance;
                    if (groundPlane.Raycast(ray, out distance))
                    {
                        spawnPos = ray.GetPoint(distance);
                        found = true;
                        Debug.Log("[LogicSpawnerV2] ✅ 点击到地面平面: " + spawnPos);
                    }
                }

                // 方法3: 使用摄像机前方固定距离
                if (!found)
                {
                    float distance = 5f;
                    spawnPos = cam.transform.position + cam.transform.forward * distance;
                    spawnPos.y = 0; // 放在地面上
                    Debug.Log("[LogicSpawnerV2] ⚠️ 使用摄像机前方位置: " + spawnPos);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("[LogicSpawnerV2] ❌ 召唤到鼠标失败: " + ex.Message);
                return SpawnAtPosition(logic, Vector3.zero);
            }

            return SpawnAtPosition(logic, spawnPos);
        }

        // ===== 🆕 召唤到选中对象（通过对象浏览器选中的对象） =====
        public static GameObject SpawnAtSelectedObject(string id)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }

            GameObject target = SuperConsole.selectedObject;
            if (target == null)
            {
                Debug.LogError("[LogicSpawnerV2] ❌ 没有选中的对象，请先在对象浏览器中选中一个对象");
                return null;
            }

            Debug.Log($"[LogicSpawnerV2] 🎯 召唤到选中对象: {target.name} 位置: {target.transform.position}");
            return SpawnAtPosition(logic, target.transform.position);
        }

        // ===== 🆕 召唤到指定 GameObject =====
        public static GameObject SpawnAtGameObject(string id, GameObject target)
        {
            if (target == null)
            {
                Debug.LogError("[LogicSpawnerV2] ❌ 目标对象为空");
                return null;
            }

            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return null; }

            Debug.Log($"[LogicSpawnerV2] 🎯 召唤到对象: {target.name} 位置: {target.transform.position}");
            return SpawnAtPosition(logic, target.transform.position);
        }

        // ===== 🆕 召唤到对象浏览器选中的对象（别名） =====
        public static GameObject SpawnAtBrowserSelection(string id)
        {
            return SpawnAtSelectedObject(id);
        }

        // ===== 核心：在位置生成 =====
        private static GameObject SpawnAtPosition(LogicEntityV2 logic, Vector3 position)
        {
            if (logic == null) return null;

            // 检查是否已有 GameObject 实例（避免重复生成）
            if (logic.GameObject != null)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 逻辑体已存在实例: {logic.GetDisplayName()}");
                return logic.GameObject;
            }

            GameObject prefab = LoadPrefab(logic);
            if (prefab == null)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 无法加载预制体，使用占位 Cube");
                prefab = GameObject.CreatePrimitive(PrimitiveType.Cube);
                // 移除 Collider 避免干扰
                Collider collider = prefab.GetComponent<Collider>();
                if (collider != null) UnityEngine.Object.Destroy(collider);
            }

            // 确保位置在地面上（如果 y 小于 0）
            if (position.y < 0) position.y = 0;

            GameObject instance = UnityEngine.Object.Instantiate(prefab, position, Quaternion.identity);
            instance.name = logic.GetDisplayName() + "_" + logic.id;
            instance.SetActive(logic.enabled);

            // 保存引用
            logic.GameObject = instance;
            logic.IsLoaded = true;

            // ---- 应用所有资源 ----
            ApplyModel(instance, logic);
            ApplyTextures(instance, logic);
            ApplyMaterials(instance, logic);
            ApplyAnimations(instance, logic);

            // ---- 加载 DLL 扩展 ----
            if (!string.IsNullOrEmpty(logic.resources.DLL))
            {
                LogicDLLLoader.AttachComponents(instance, logic);
                LogicDLLLoader.Initialize(instance, logic);
            }

            Debug.Log($"[LogicSpawnerV2] 🚀 召唤逻辑体: {logic.GetDisplayName()} -> {position}");
            return instance;
        }

        private static GameObject LoadPrefab(LogicEntityV2 logic)
        {
            if (string.IsNullOrEmpty(logic.resources.Prefab)) return null;

            // 1. 从逻辑体文件夹加载
            GameObject prefab = LogicPrefabSaver.LoadPrefab(logic.FolderPath, "main");
            if (prefab != null) return prefab;

            // 2. 从本地 Assets/Prefabs 加载
            string localPath = Path.Combine(LogicResourceLoader.GetPrefabsPath(), Path.GetFileName(logic.resources.Prefab));
            prefab = LogicResourceLoader.LoadPrefab(localPath);
            if (prefab != null) return prefab;

            // 3. 从 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(logic.resources.Prefab);
            GameObject resourcePrefab = Resources.Load<GameObject>(resourceName);
            if (resourcePrefab != null) return resourcePrefab;

            return null;
        }

        // ============================================================
        // 1. 应用模型
        // ============================================================
        private static void ApplyModel(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (string.IsNullOrEmpty(logic.resources.Model)) return;

                Mesh mesh = LogicResourceLoader.LoadMesh(logic.resources.Model, logic.FolderPath);
                if (mesh == null)
                {
                    Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 加载模型失败: {logic.resources.Model}");
                    return;
                }

                MeshFilter filter = instance.GetComponent<MeshFilter>();
                if (filter == null) filter = instance.AddComponent<MeshFilter>();
                filter.mesh = mesh;

                MeshRenderer renderer = instance.GetComponent<MeshRenderer>();
                if (renderer == null) renderer = instance.AddComponent<MeshRenderer>();

                if (renderer.material == null || renderer.material.shader == null)
                    renderer.material = new Material(Shader.Find("Standard"));

                Debug.Log($"[LogicSpawnerV2] 🎨 应用模型: {logic.resources.Model}");
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用模型失败: {ex.Message}");
            }
        }

        // ============================================================
        // 2. 应用纹理
        // ============================================================
        private static void ApplyTextures(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (logic.resources.Textures == null || logic.resources.Textures.Count == 0) return;

                Renderer renderer = instance.GetComponent<Renderer>();
                if (renderer == null) return;

                if (renderer.material == null || renderer.material.shader == null)
                    renderer.material = new Material(Shader.Find("Standard"));

                foreach (string texPath in logic.resources.Textures)
                {
                    Texture2D tex = LogicResourceLoader.LoadTexture(texPath, logic.FolderPath);
                    if (tex != null)
                    {
                        renderer.material.mainTexture = tex;
                        renderer.material.SetTexture("_MainTex", tex);
                        Debug.Log($"[LogicSpawnerV2] 🖼️ 应用纹理: {texPath} ({tex.width}x{tex.height})");
                        return;
                    }
                    else
                    {
                        Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 加载纹理失败: {texPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用纹理失败: {ex.Message}");
            }
        }

        // ============================================================
        // 3. 应用材质
        // ============================================================
        private static void ApplyMaterials(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (logic.resources.Materials == null || logic.resources.Materials.Count == 0) return;

                Renderer renderer = instance.GetComponent<Renderer>();
                if (renderer == null) return;

                foreach (string matPath in logic.resources.Materials)
                {
                    Material mat = LogicResourceLoader.LoadMaterial(matPath, logic.FolderPath);
                    if (mat != null)
                    {
                        renderer.material = mat;
                        Debug.Log($"[LogicSpawnerV2] 🧪 应用材质: {matPath}");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用材质失败: {ex.Message}");
            }
        }

        // ============================================================
        // 4. 应用动画
        // ============================================================
        private static void ApplyAnimations(GameObject instance, LogicEntityV2 logic)
        {
            try
            {
                if (logic.resources.Animations == null || logic.resources.Animations.Count == 0) return;

                Animation anim = instance.GetComponent<Animation>();
                if (anim == null) anim = instance.AddComponent<Animation>();

                foreach (string animPath in logic.resources.Animations)
                {
                    AnimationClip clip = LogicResourceLoader.LoadAnimation(animPath, logic.FolderPath);
                    if (clip != null)
                    {
                        anim.AddClip(clip, clip.name);
                        if (anim.clip == null)
                        {
                            anim.clip = clip;
                            anim.Play();
                        }
                        Debug.Log($"[LogicSpawnerV2] 🎬 应用动画: {animPath}");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicSpawnerV2] ⚠️ 应用动画失败: {ex.Message}");
            }
        }

        // ============================================================
        // 批量召唤
        // ============================================================
        public static void SpawnMultiple(string id, Vector3 center, int count, float radius)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) { Debug.LogError($"[LogicSpawnerV2] ❌ 找不到逻辑体: {id}"); return; }

            for (int i = 0; i < count; i++)
            {
                Vector3 offset = UnityEngine.Random.insideUnitSphere * radius;
                offset.y = Mathf.Abs(offset.y);
                SpawnAtPosition(logic, center + offset);
            }
            Debug.Log($"[LogicSpawnerV2] 📊 批量召唤 {count} 个 {logic.GetDisplayName()}");
        }

        // ============================================================
        // 🆕 清除所有已召唤的逻辑体实例
        // ============================================================
        public static void ClearAllInstances()
        {
            int count = 0;
            foreach (var logic in LogicManagerV2.GetAll())
            {
                if (logic.GameObject != null)
                {
                    UnityEngine.Object.Destroy(logic.GameObject);
                    logic.GameObject = null;
                    logic.IsLoaded = false;
                    count++;
                }
            }
            Debug.Log($"[LogicSpawnerV2] 🗑️ 清除了 {count} 个逻辑体实例");
        }

        // ============================================================
        // 🆕 清除指定逻辑体的实例
        // ============================================================
        public static void ClearInstance(string id)
        {
            var logic = LogicManagerV2.Get(id);
            if (logic == null) return;

            if (logic.GameObject != null)
            {
                UnityEngine.Object.Destroy(logic.GameObject);
                logic.GameObject = null;
                logic.IsLoaded = false;
                Debug.Log($"[LogicSpawnerV2] 🗑️ 清除了逻辑体实例: {logic.GetDisplayName()}");
            }
        }
    }
}
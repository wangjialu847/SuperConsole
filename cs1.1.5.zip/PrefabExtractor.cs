﻿using System.IO;
using UnityEngine;

namespace SuperConsole
{
    public static class PrefabExtractor
    {
        public static LogicEntityV2 ExtractPrefab(GameObject target, string name = null)
        {
            if (target == null)
            {
                return null;
            }

            if (string.IsNullOrEmpty(name))
            {
                name = target.name;
            }

            LogicEntityV2 logic = LogicManagerV2.Create(name, LogicType.Prefab);
            LogicPrefabSaver.SavePrefab(target, logic.FolderPath, "main");
            logic.resources.Prefab = "prefabs/main.prefab";
            LogicManagerV2.SaveToFile(logic);

            Debug.Log("[PrefabExtractor] Extracted: " + logic.GetDisplayName());
            return logic;
        }
    }
}
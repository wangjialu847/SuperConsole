﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEngine.Networking;

namespace SuperConsole
{
    public class AssetEntry
    {
        public string Name;
        public string Path;
        public string Type;
        public string Extension;
        public GameObject GameObject;
        public Texture2D Texture;
        public AudioClip AudioClip;
        public Material Material;
        public AnimationClip AnimationClip;
        public DateTime LoadedTime;
        public bool IsLoaded;
    }

    public static class AssetManager
    {
        private static string assetPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
        private static List<AssetEntry> loadedAssets = new List<AssetEntry>();

        private static HashSet<string> modelExtensions = new HashSet<string> { ".obj", ".fbx" };
        private static HashSet<string> textureExtensions = new HashSet<string> { ".png", ".jpg", ".jpeg", ".tga", ".dds" };
        private static HashSet<string> audioExtensions = new HashSet<string> { ".wav", ".mp3", ".ogg" };
        private static HashSet<string> prefabExtensions = new HashSet<string> { ".prefab" };
        private static HashSet<string> animationExtensions = new HashSet<string> { ".anim" };
        private static HashSet<string> materialExtensions = new HashSet<string> { ".mat" };

        static AssetManager()
        {
            EnsureDirectories();
            ScanAllAssets();
        }

        private static void EnsureDirectories()
        {
            string[] dirs = new string[] { "Models", "Textures", "Audio", "Prefabs", "Animations", "Materials" };
            for (int i = 0; i < dirs.Length; i++)
            {
                string p = Path.Combine(assetPath, dirs[i]);
                if (!Directory.Exists(p))
                {
                    Directory.CreateDirectory(p);
                }
            }
        }

        public static void ScanAllAssets()
        {
            loadedAssets.Clear();
            ScanDirectory(Path.Combine(assetPath, "Models"), "model", modelExtensions);
            ScanDirectory(Path.Combine(assetPath, "Textures"), "texture", textureExtensions);
            ScanDirectory(Path.Combine(assetPath, "Audio"), "audio", audioExtensions);
            ScanDirectory(Path.Combine(assetPath, "Prefabs"), "prefab", prefabExtensions);
            ScanDirectory(Path.Combine(assetPath, "Animations"), "animation", animationExtensions);
            ScanDirectory(Path.Combine(assetPath, "Materials"), "material", materialExtensions);
            Debug.Log("[AssetManager] Found " + loadedAssets.Count + " assets");
        }

        private static void ScanDirectory(string dir, string type, HashSet<string> exts)
        {
            if (!Directory.Exists(dir))
            {
                return;
            }
            string[] files = Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                string file = files[i];
                string ext = Path.GetExtension(file).ToLower();
                if (!exts.Contains(ext))
                {
                    continue;
                }
                AssetEntry entry = new AssetEntry();
                entry.Name = Path.GetFileNameWithoutExtension(file);
                entry.Path = file;
                entry.Type = type;
                entry.Extension = ext;
                entry.IsLoaded = false;
                loadedAssets.Add(entry);
            }
        }

        public static AssetEntry LoadAsset(string name)
        {
            AssetEntry entry = loadedAssets.FirstOrDefault(a => a.Name == name);
            if (entry == null || entry.IsLoaded)
            {
                return entry;
            }

            try
            {
                switch (entry.Type)
                {
                    case "model":
                        LoadModel(entry);
                        break;
                    case "texture":
                        LoadTexture(entry);
                        break;
                    case "audio":
                        LoadAudio(entry);
                        break;
                    case "prefab":
                        LoadPrefab(entry);
                        break;
                    case "animation":
                        LoadAnimation(entry);
                        break;
                    case "material":
                        LoadMaterial(entry);
                        break;
                }
                entry.IsLoaded = true;
                entry.LoadedTime = DateTime.Now;
            }
            catch (Exception ex)
            {
                Debug.LogError("[AssetManager] Load failed: " + entry.Name + " - " + ex.Message);
            }
            return entry;
        }

        // ===== Core Loaders =====

        private static void LoadModel(AssetEntry entry)
        {
            GameObject obj = new GameObject(entry.Name);
            MeshFilter filter = obj.AddComponent<MeshFilter>();
            MeshRenderer renderer = obj.AddComponent<MeshRenderer>();

            Mesh mesh = null;
            if (entry.Extension == ".obj")
            {
                mesh = ObjImporter.Import(entry.Path);
            }
            else
            {
                Debug.LogWarning("[AssetManager] Only .obj supported for now: " + entry.Name);
            }

            if (mesh == null)
            {
                mesh = CreateDefaultMesh();
            }
            filter.mesh = mesh;
            renderer.material = new Material(Shader.Find("Standard"));
            entry.GameObject = obj;
        }

        private static void LoadTexture(AssetEntry entry)
        {
            byte[] data = File.ReadAllBytes(entry.Path);
            Texture2D tex = new Texture2D(2, 2);
            if (ImageConversion.LoadImage(tex, data))
            {
                entry.Texture = tex;
            }
            else
            {
                Debug.LogWarning("[AssetManager] Failed to load texture: " + entry.Name);
            }
        }

        private static void LoadAudio(AssetEntry entry)
        {
            string url = "file://" + entry.Path.Replace("\\", "/");
            UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url, AudioType.UNKNOWN);
            www.SendWebRequest();
            while (!www.isDone)
            {
            }
            if (www.result == UnityWebRequest.Result.Success)
            {
                entry.AudioClip = DownloadHandlerAudioClip.GetContent(www);
            }
        }

        private static void LoadPrefab(AssetEntry entry)
        {
            string folderPath = Path.GetDirectoryName(entry.Path);
            string name = Path.GetFileNameWithoutExtension(entry.Path);
            GameObject prefab = LogicPrefabSaver.LoadPrefab(folderPath, name);
            if (prefab == null)
            {
                prefab = new GameObject(entry.Name);
            }
            entry.GameObject = prefab;
        }

        private static void LoadAnimation(AssetEntry entry)
        {
            AnimationClip clip = new AnimationClip();
            clip.name = entry.Name;
            entry.AnimationClip = clip;
            Debug.Log("[AssetManager] Animation placeholder loaded: " + entry.Name);
        }

        private static void LoadMaterial(AssetEntry entry)
        {
            Material mat = new Material(Shader.Find("Standard"));
            mat.name = entry.Name;
            entry.Material = mat;
            Debug.Log("[AssetManager] Material placeholder loaded: " + entry.Name);
        }

        // ===== Helpers =====

        private static Mesh CreateDefaultMesh()
        {
            Mesh m = new Mesh();
            Vector3[] verts = new Vector3[]
            {
                new Vector3(-0.5f, -0.5f, 0f),
                new Vector3(0.5f, -0.5f, 0f),
                new Vector3(0.5f, 0.5f, 0f),
                new Vector3(-0.5f, 0.5f, 0f)
            };
            int[] tris = new int[] { 0, 1, 2, 0, 2, 3 };
            Vector2[] uvs = new Vector2[]
            {
                new Vector2(0f, 0f),
                new Vector2(1f, 0f),
                new Vector2(1f, 1f),
                new Vector2(0f, 1f)
            };
            m.vertices = verts;
            m.triangles = tris;
            m.uv = uvs;
            m.RecalculateNormals();
            m.RecalculateBounds();
            return m;
        }

        public static GameObject InstantiateAsset(string name, Vector3 pos, Quaternion rot)
        {
            AssetEntry entry = LoadAsset(name);
            if (entry == null || entry.GameObject == null)
            {
                return null;
            }
            GameObject obj = UnityEngine.Object.Instantiate(entry.GameObject, pos, rot);
            obj.name = entry.Name + "_Instance";
            return obj;
        }

        public static List<AssetEntry> GetAllAssets()
        {
            return new List<AssetEntry>(loadedAssets);
        }

        // ===== OBJ Importer =====

        private static class ObjImporter
        {
            public static Mesh Import(string path)
            {
                string[] lines = File.ReadAllLines(path);
                List<Vector3> verts = new List<Vector3>();
                List<Vector2> uvs = new List<Vector2>();
                List<int> tris = new List<int>();

                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i];
                    if (line.StartsWith("v "))
                    {
                        string[] parts = line.Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 3)
                        {
                            float x = float.Parse(parts[0]);
                            float y = float.Parse(parts[1]);
                            float z = float.Parse(parts[2]);
                            verts.Add(new Vector3(x, y, z));
                        }
                    }
                    else if (line.StartsWith("vt "))
                    {
                        string[] parts = line.Substring(3).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 2)
                        {
                            float u = float.Parse(parts[0]);
                            float v = float.Parse(parts[1]);
                            uvs.Add(new Vector2(u, v));
                        }
                    }
                    else if (line.StartsWith("f "))
                    {
                        string[] parts = line.Substring(2).Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 0; j < parts.Length; j++)
                        {
                            string[] idx = parts[j].Split('/');
                            if (idx.Length > 0)
                            {
                                int val;
                                if (int.TryParse(idx[0], out val))
                                {
                                    tris.Add(val - 1);
                                }
                            }
                        }
                    }
                }

                if (verts.Count == 0 || tris.Count == 0)
                {
                    return null;
                }

                Mesh m = new Mesh();
                m.vertices = verts.ToArray();
                m.triangles = tris.ToArray();
                if (uvs.Count > 0)
                {
                    m.uv = uvs.ToArray();
                }
                m.RecalculateNormals();
                m.RecalculateBounds();
                return m;
            }
        }
    }
}
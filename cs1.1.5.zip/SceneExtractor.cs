﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using BepInEx;

namespace SuperConsole
{
    public static class SceneExtractor
    {
        public static LogicEntityV2 ExtractScene(string name = null)
        {
            Scene scene = SceneManager.GetActiveScene();
            if (string.IsNullOrEmpty(name))
            {
                name = scene.name;
            }

            LogicEntityV2 logic = LogicManagerV2.Create(name, LogicType.Scene);
            string prefabDir = Path.Combine(logic.FolderPath, "prefabs");
            if (!Directory.Exists(prefabDir))
            {
                Directory.CreateDirectory(prefabDir);
            }

            GameObject[] rootObjects = scene.GetRootGameObjects();
            for (int i = 0; i < rootObjects.Length; i++)
            {
                GameObject obj = rootObjects[i];
                if (obj == null)
                {
                    continue;
                }
                ExtractObject(obj, logic);
            }

            logic.resources.Prefab = "prefabs/main.prefab";
            LogicManagerV2.SaveToFile(logic);
            Debug.Log("[SceneExtractor] Extracted " + rootObjects.Length + " objects from scene: " + scene.name);
            return logic;
        }

        private static void ExtractObject(GameObject obj, LogicEntityV2 logic)
        {
            GameObject clone = UnityEngine.Object.Instantiate(obj);
            clone.name = obj.name;
            LogicPrefabSaver.SavePrefab(clone, logic.FolderPath, obj.name);
            UnityEngine.Object.Destroy(clone);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using BepInEx;
using UnityEngine.Networking;

namespace SuperConsole
{
    /// <summary>
    /// 逻辑体资源加载器
    /// 加载顺序：逻辑体文件夹 → 本地 Assets/ → 游戏 Resources/
    /// </summary>
    public static class LogicResourceLoader
    {
        // ===== 路径 =====
        private static readonly string assetsPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Assets");
        private static readonly string modelsPath = Path.Combine(assetsPath, "Models");
        private static readonly string texturesPath = Path.Combine(assetsPath, "Textures");
        private static readonly string audioPath = Path.Combine(assetsPath, "Audio");
        private static readonly string prefabsPath = Path.Combine(assetsPath, "Prefabs");
        private static readonly string animationsPath = Path.Combine(assetsPath, "Animations");
        private static readonly string materialsPath = Path.Combine(assetsPath, "Materials");

        // ===== 缓存 =====
        private static readonly Dictionary<string, Mesh> meshCache = new Dictionary<string, Mesh>();
        private static readonly Dictionary<string, Texture2D> textureCache = new Dictionary<string, Texture2D>();
        private static readonly Dictionary<string, AudioClip> audioCache = new Dictionary<string, AudioClip>();
        private static readonly Dictionary<string, GameObject> prefabCache = new Dictionary<string, GameObject>();
        private static readonly Dictionary<string, AnimationClip> animationCache = new Dictionary<string, AnimationClip>();
        private static readonly Dictionary<string, Material> materialCache = new Dictionary<string, Material>();

        static LogicResourceLoader()
        {
            EnsureDirectories();
            Debug.Log("[LogicResourceLoader] ✅ 已初始化");
        }

        private static void EnsureDirectories()
        {
            if (!Directory.Exists(assetsPath)) Directory.CreateDirectory(assetsPath);
            if (!Directory.Exists(modelsPath)) Directory.CreateDirectory(modelsPath);
            if (!Directory.Exists(texturesPath)) Directory.CreateDirectory(texturesPath);
            if (!Directory.Exists(audioPath)) Directory.CreateDirectory(audioPath);
            if (!Directory.Exists(prefabsPath)) Directory.CreateDirectory(prefabsPath);
            if (!Directory.Exists(animationsPath)) Directory.CreateDirectory(animationsPath);
            if (!Directory.Exists(materialsPath)) Directory.CreateDirectory(materialsPath);
        }

        public static string GetAssetsPath() => assetsPath;
        public static string GetModelsPath() => modelsPath;
        public static string GetTexturesPath() => texturesPath;
        public static string GetAudioPath() => audioPath;
        public static string GetPrefabsPath() => prefabsPath;
        public static string GetAnimationsPath() => animationsPath;
        public static string GetMaterialsPath() => materialsPath;

        // ============================================================
        // 通用加载接口
        // ============================================================

        public static T LoadResource<T>(string path, string logicFolderPath = null) where T : UnityEngine.Object
        {
            if (typeof(T) == typeof(Mesh)) return LoadMesh(path, logicFolderPath) as T;
            if (typeof(T) == typeof(Texture2D)) return LoadTexture(path, logicFolderPath) as T;
            if (typeof(T) == typeof(AudioClip)) return LoadAudio(path, logicFolderPath) as T;
            if (typeof(T) == typeof(GameObject)) return LoadPrefab(path, logicFolderPath) as T;
            if (typeof(T) == typeof(AnimationClip)) return LoadAnimation(path, logicFolderPath) as T;
            if (typeof(T) == typeof(Material)) return LoadMaterial(path, logicFolderPath) as T;
            return null;
        }

        // ============================================================
        // 1. 加载 Mesh
        // ============================================================
        public static Mesh LoadMesh(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (meshCache.TryGetValue(key, out Mesh cached)) return cached;

            Mesh mesh = null;

            // 1.1 从逻辑体文件夹加载
            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    mesh = LoadOBJ(fullPath);
                    if (mesh != null)
                    {
                        meshCache[key] = mesh;
                        Debug.Log($"[LogicResourceLoader] ✅ 加载模型: {path} (逻辑体)");
                        return mesh;
                    }
                }
            }

            // 1.2 从本地 Assets 加载（路径已经包含子目录，如 "models/character.obj"）
            string localPath = Path.Combine(assetsPath, path);
            if (File.Exists(localPath))
            {
                mesh = LoadOBJ(localPath);
                if (mesh != null)
                {
                    meshCache[key] = mesh;
                    Debug.Log($"[LogicResourceLoader] ✅ 加载模型: {path} (本地)");
                    return mesh;
                }
            }

            // 1.3 从 Resources 加载
            string resourceName = Path.GetFileNameWithoutExtension(path);
            mesh = Resources.Load<Mesh>(resourceName);
            if (mesh != null)
            {
                meshCache[key] = mesh;
                Debug.Log($"[LogicResourceLoader] ✅ 加载模型: {path} (Resources)");
                return mesh;
            }

            Debug.LogWarning($"[LogicResourceLoader] ⚠️ 找不到模型: {path}");
            return null;
        }

        // ============================================================
        // 2. 加载 Texture2D
        // ============================================================
        public static Texture2D LoadTexture(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (textureCache.TryGetValue(key, out Texture2D cached)) return cached;

            Texture2D tex = null;

            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    tex = LoadImageFile(fullPath);
                    if (tex != null)
                    {
                        textureCache[key] = tex;
                        Debug.Log($"[LogicResourceLoader] ✅ 加载纹理: {path} (逻辑体)");
                        return tex;
                    }
                }
            }

            string localPath = Path.Combine(assetsPath, path);
            if (File.Exists(localPath))
            {
                tex = LoadImageFile(localPath);
                if (tex != null)
                {
                    textureCache[key] = tex;
                    Debug.Log($"[LogicResourceLoader] ✅ 加载纹理: {path} (本地)");
                    return tex;
                }
            }

            string resourceName = Path.GetFileNameWithoutExtension(path);
            tex = Resources.Load<Texture2D>(resourceName);
            if (tex != null)
            {
                textureCache[key] = tex;
                Debug.Log($"[LogicResourceLoader] ✅ 加载纹理: {path} (Resources)");
                return tex;
            }

            Debug.LogWarning($"[LogicResourceLoader] ⚠️ 找不到纹理: {path}");
            return null;
        }

        // ============================================================
        // 3. 加载 AudioClip
        // ============================================================
        public static AudioClip LoadAudio(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (audioCache.TryGetValue(key, out AudioClip cached)) return cached;

            AudioClip clip = null;

            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    clip = LoadAudioFile(fullPath);
                    if (clip != null)
                    {
                        audioCache[key] = clip;
                        Debug.Log($"[LogicResourceLoader] ✅ 加载音频: {path} (逻辑体)");
                        return clip;
                    }
                }
            }

            string localPath = Path.Combine(assetsPath, path);
            if (File.Exists(localPath))
            {
                clip = LoadAudioFile(localPath);
                if (clip != null)
                {
                    audioCache[key] = clip;
                    Debug.Log($"[LogicResourceLoader] ✅ 加载音频: {path} (本地)");
                    return clip;
                }
            }

            string resourceName = Path.GetFileNameWithoutExtension(path);
            clip = Resources.Load<AudioClip>(resourceName);
            if (clip != null)
            {
                audioCache[key] = clip;
                Debug.Log($"[LogicResourceLoader] ✅ 加载音频: {path} (Resources)");
                return clip;
            }

            Debug.LogWarning($"[LogicResourceLoader] ⚠️ 找不到音频: {path}");
            return null;
        }

        // ============================================================
        // 4. 加载 Prefab
        // ============================================================
        public static GameObject LoadPrefab(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (prefabCache.TryGetValue(key, out GameObject cached)) return cached;

            GameObject prefab = null;

            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    prefab = LogicPrefabSaver.LoadPrefab(logicFolderPath, Path.GetFileNameWithoutExtension(path));
                    if (prefab != null)
                    {
                        prefabCache[key] = prefab;
                        Debug.Log($"[LogicResourceLoader] ✅ 加载预制体: {path} (逻辑体)");
                        return prefab;
                    }
                }
            }

            string localPath = Path.Combine(assetsPath, path);
            if (File.Exists(localPath))
            {
                prefab = LogicPrefabSaver.LoadPrefab(Path.GetDirectoryName(localPath), Path.GetFileNameWithoutExtension(path));
                if (prefab != null)
                {
                    prefabCache[key] = prefab;
                    Debug.Log($"[LogicResourceLoader] ✅ 加载预制体: {path} (本地)");
                    return prefab;
                }
            }

            string resourceName = Path.GetFileNameWithoutExtension(path);
            prefab = Resources.Load<GameObject>(resourceName);
            if (prefab != null)
            {
                prefabCache[key] = prefab;
                Debug.Log($"[LogicResourceLoader] ✅ 加载预制体: {path} (Resources)");
                return prefab;
            }

            Debug.LogWarning($"[LogicResourceLoader] ⚠️ 找不到预制体: {path}");
            return null;
        }

        // ============================================================
        // 5. 加载 AnimationClip
        // ============================================================
        public static AnimationClip LoadAnimation(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (animationCache.TryGetValue(key, out AnimationClip cached)) return cached;

            AnimationClip clip = null;

            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    clip = LoadAnimationFile(fullPath);
                    if (clip != null)
                    {
                        animationCache[key] = clip;
                        Debug.Log($"[LogicResourceLoader] ✅ 加载动画: {path} (逻辑体)");
                        return clip;
                    }
                }
            }

            string localPath = Path.Combine(assetsPath, path);
            if (File.Exists(localPath))
            {
                clip = LoadAnimationFile(localPath);
                if (clip != null)
                {
                    animationCache[key] = clip;
                    Debug.Log($"[LogicResourceLoader] ✅ 加载动画: {path} (本地)");
                    return clip;
                }
            }

            string resourceName = Path.GetFileNameWithoutExtension(path);
            clip = Resources.Load<AnimationClip>(resourceName);
            if (clip != null)
            {
                animationCache[key] = clip;
                Debug.Log($"[LogicResourceLoader] ✅ 加载动画: {path} (Resources)");
                return clip;
            }

            Debug.LogWarning($"[LogicResourceLoader] ⚠️ 找不到动画: {path}");
            return null;
        }

        // ============================================================
        // 6. 加载 Material
        // ============================================================
        public static Material LoadMaterial(string path, string logicFolderPath = null)
        {
            if (string.IsNullOrEmpty(path)) return null;

            string key = path;
            if (materialCache.TryGetValue(key, out Material cached)) return cached;

            Material mat = null;

            if (!string.IsNullOrEmpty(logicFolderPath))
            {
                string fullPath = Path.Combine(logicFolderPath, path);
                if (File.Exists(fullPath))
                {
                    mat = LoadMaterialFile(fullPath);
                    if (mat != null)
                    {
                        materialCache[key] = mat;
                        Debug.Log($"[LogicResourceLoader] ✅ 加载材质: {path} (逻辑体)");
                        return mat;
                    }
                }
            }

            string localPath = Path.Combine(assetsPath, path);
            if (File.Exists(localPath))
            {
                mat = LoadMaterialFile(localPath);
                if (mat != null)
                {
                    materialCache[key] = mat;
                    Debug.Log($"[LogicResourceLoader] ✅ 加载材质: {path} (本地)");
                    return mat;
                }
            }

            string resourceName = Path.GetFileNameWithoutExtension(path);
            mat = Resources.Load<Material>(resourceName);
            if (mat != null)
            {
                materialCache[key] = mat;
                Debug.Log($"[LogicResourceLoader] ✅ 加载材质: {path} (Resources)");
                return mat;
            }

            Debug.LogWarning($"[LogicResourceLoader] ⚠️ 找不到材质: {path}");
            return null;
        }

        // ============================================================
        // Resources 快捷方法
        // ============================================================
        public static T LoadFromResources<T>(string name) where T : UnityEngine.Object
            => Resources.Load<T>(name);

        public static T[] LoadAllFromResources<T>(string folder = "") where T : UnityEngine.Object
            => Resources.LoadAll<T>(folder);

        // ============================================================
        // 工具方法
        // ============================================================

        private static Texture2D LoadImageFile(string path)
        {
            try
            {
                byte[] data = File.ReadAllBytes(path);
                Texture2D tex = new Texture2D(2, 2);
                if (ImageConversion.LoadImage(tex, data))
                    return tex;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicResourceLoader] 加载图片失败: {path} - {ex.Message}");
            }
            return null;
        }

        private static AudioClip LoadAudioFile(string path)
        {
            try
            {
                string url = "file://" + path.Replace("\\", "/");
                using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url, AudioType.UNKNOWN))
                {
                    www.SendWebRequest();
                    while (!www.isDone) { }
                    if (www.result == UnityWebRequest.Result.Success)
                        return DownloadHandlerAudioClip.GetContent(www);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicResourceLoader] 加载音频失败: {path} - {ex.Message}");
            }
            return null;
        }

        private static Mesh LoadOBJ(string path)
        {
            try
            {
                string[] lines = File.ReadAllLines(path);
                List<Vector3> vertices = new List<Vector3>();
                List<Vector2> uvs = new List<Vector2>();
                List<int> triangles = new List<int>();

                foreach (var line in lines)
                {
                    if (line.StartsWith("v "))
                    {
                        var parts = line.Substring(2).Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 3)
                            vertices.Add(new Vector3(float.Parse(parts[0]), float.Parse(parts[1]), float.Parse(parts[2])));
                    }
                    else if (line.StartsWith("vt "))
                    {
                        var parts = line.Substring(3).Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 2)
                            uvs.Add(new Vector2(float.Parse(parts[0]), float.Parse(parts[1])));
                    }
                    else if (line.StartsWith("f "))
                    {
                        var parts = line.Substring(2).Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        foreach (var part in parts)
                        {
                            var indices = part.Split('/');
                            if (indices.Length > 0 && int.TryParse(indices[0], out int idx))
                                triangles.Add(idx - 1);
                        }
                    }
                }

                if (vertices.Count == 0 || triangles.Count == 0)
                {
                    Debug.LogWarning($"[LogicResourceLoader] OBJ 无有效数据: {path}");
                    return null;
                }

                Mesh mesh = new Mesh
                {
                    vertices = vertices.ToArray(),
                    triangles = triangles.ToArray()
                };
                if (uvs.Count > 0) mesh.uv = uvs.ToArray();
                mesh.RecalculateNormals();
                mesh.RecalculateBounds();
                return mesh;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicResourceLoader] OBJ 加载失败: {path} - {ex.Message}");
                return null;
            }
        }

        private static Material LoadMaterialFile(string path)
        {
            try
            {
                string[] lines = File.ReadAllLines(path);
                string shaderName = "Standard";
                Color color = Color.white;
                string textureName = null;

                foreach (var line in lines)
                {
                    if (line.StartsWith("shader:"))
                        shaderName = line.Substring(7).Trim();
                    else if (line.StartsWith("color:"))
                    {
                        var parts = line.Substring(6).Trim().Split(',');
                        if (parts.Length >= 3)
                        {
                            float r = float.Parse(parts[0].Trim());
                            float g = float.Parse(parts[1].Trim());
                            float b = float.Parse(parts[2].Trim());
                            float a = parts.Length >= 4 ? float.Parse(parts[3].Trim()) : 1f;
                            color = new Color(r, g, b, a);
                        }
                    }
                    else if (line.StartsWith("mainTexture:"))
                        textureName = line.Substring(12).Trim();
                }

                Shader shader = Shader.Find(shaderName) ?? Shader.Find("Standard");
                Material mat = new Material(shader);
                mat.color = color;

                if (!string.IsNullOrEmpty(textureName))
                {
                    string dir = Path.GetDirectoryName(path);
                    string texPath = Path.Combine(dir, "..", "textures", textureName + ".png");
                    if (File.Exists(texPath))
                    {
                        byte[] data = File.ReadAllBytes(texPath);
                        Texture2D tex = new Texture2D(2, 2);
                        if (ImageConversion.LoadImage(tex, data))
                            mat.mainTexture = tex;
                    }
                }

                return mat;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicResourceLoader] 材质加载失败: {path} - {ex.Message}");
                return null;
            }
        }

        private static AnimationClip LoadAnimationFile(string path)
        {
            try
            {
                string[] lines = File.ReadAllLines(path);
                string name = Path.GetFileNameWithoutExtension(path);
                float frameRate = 30f;
                bool loop = false;

                foreach (var line in lines)
                {
                    if (line.StartsWith("frameRate:"))
                        float.TryParse(line.Substring(10).Trim(), out frameRate);
                    else if (line.StartsWith("loop:"))
                        bool.TryParse(line.Substring(5).Trim(), out loop);
                }

                AnimationClip clip = new AnimationClip
                {
                    name = name,
                    frameRate = frameRate,
                    legacy = true
                };

                var field = typeof(AnimationClip).GetField("m_Loop",
                    System.Reflection.BindingFlags.NonPublic |
                    System.Reflection.BindingFlags.Instance);
                if (field != null)
                    field.SetValue(clip, loop);
                else
                    clip.wrapMode = loop ? WrapMode.Loop : WrapMode.Default;

                return clip;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[LogicResourceLoader] 动画加载失败: {path} - {ex.Message}");
                return null;
            }
        }

        // ============================================================
        // 缓存管理
        // ============================================================

        public static void ClearCache()
        {
            meshCache.Clear();
            textureCache.Clear();
            audioCache.Clear();
            prefabCache.Clear();
            animationCache.Clear();
            materialCache.Clear();
            Debug.Log("[LogicResourceLoader] 🧹 缓存已清除");
        }

        public static void ClearCache<T>()
        {
            if (typeof(T) == typeof(Mesh)) meshCache.Clear();
            else if (typeof(T) == typeof(Texture2D)) textureCache.Clear();
            else if (typeof(T) == typeof(AudioClip)) audioCache.Clear();
            else if (typeof(T) == typeof(GameObject)) prefabCache.Clear();
            else if (typeof(T) == typeof(AnimationClip)) animationCache.Clear();
            else if (typeof(T) == typeof(Material)) materialCache.Clear();
        }

        public static string GetStatus()
        {
            return $"[LogicResourceLoader] 缓存: Mesh={meshCache.Count}, Tex={textureCache.Count}, Audio={audioCache.Count}, Prefab={prefabCache.Count}, Anim={animationCache.Count}, Mat={materialCache.Count}";
        }
    }
}
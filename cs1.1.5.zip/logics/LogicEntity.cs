﻿using System;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using BepInEx;

namespace SuperConsole
{
    // ============================================================
    // Enum Definitions
    // ============================================================
    public enum TriggerType
    {
        OnUpdate, OnFixedUpdate, OnEvent, OnInterval, OnLoad, Manual
    }

    public enum ConditionType
    {
        ValueCheck, EventTrigger, TimeElapsed, InputKey, ObjectExists, Custom
    }

    public enum ActionType
    {
        SetValue, ExecuteMethod, SpawnObject, DestroyObject, Teleport, Hook, Custom
    }

    // ============================================================
    // Condition Class
    // ============================================================
    [Serializable]
    public class LogicCondition
    {
        public ConditionType Type = ConditionType.ValueCheck;
        public string Target = "";
        public string Operator = "==";
        public string Value = "";
        public string CustomCode = "";

        public bool Check()
        {
            try
            {
                switch (Type)
                {
                    case ConditionType.ValueCheck: return CheckValue();
                    case ConditionType.TimeElapsed: return CheckTime();
                    case ConditionType.InputKey: return CheckInput();
                    case ConditionType.ObjectExists: return GameObject.Find(Target) != null;
                    case ConditionType.Custom: return true;
                    default: return true;
                }
            }
            catch { return false; }
        }

        private bool CheckValue()
        {
            if (string.IsNullOrEmpty(Target)) return false;
            object current = GetTargetValue(Target);
            if (current == null) return false;

            double cur = Convert.ToDouble(current);
            double val = Convert.ToDouble(Value);

            switch (Operator)
            {
                case "<": return cur < val;
                case ">": return cur > val;
                case "==": return Math.Abs(cur - val) < 0.0001;
                case ">=": return cur >= val;
                case "<=": return cur <= val;
                default: return false;
            }
        }

        private object GetTargetValue(string target)
        {
            string[] parts = target.Split('.');
            if (parts.Length < 2) return null;

            GameObject obj = GameObject.Find(parts[0]);
            if (obj == null) return null;

            Type compType = TypeFinder.FindType(parts[1]);
            if (compType == null) return null;

            Component comp = obj.GetComponent(compType);
            if (comp == null) return null;

            if (parts.Length == 2) return comp;

            var field = compType.GetField(parts[2], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (field != null) return field.GetValue(comp);

            var prop = compType.GetProperty(parts[2], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (prop != null) return prop.GetValue(comp);

            return null;
        }

        private float timer = 0;
        private bool CheckTime()
        {
            if (!float.TryParse(Value, out float interval)) return false;
            timer += Time.deltaTime;
            if (timer >= interval) { timer = 0; return true; }
            return false;
        }

        private bool CheckInput()
        {
            if (Enum.TryParse<KeyCode>(Value, true, out KeyCode key))
                return Input.GetKeyDown(key);
            return false;
        }

        public string GetDisplayText()
        {
            switch (Type)
            {
                case ConditionType.ValueCheck: return $"{Target} {Operator} {Value}";
                case ConditionType.TimeElapsed: return $"Every {Value} seconds";
                case ConditionType.InputKey: return $"Press {Value}";
                case ConditionType.ObjectExists: return $"Object {Target} exists";
                case ConditionType.Custom: return "Custom condition";
                default: return "Unknown";
            }
        }
    }

    // ============================================================
    // Action Class
    // ============================================================
    [Serializable]
    public class LogicAction
    {
        public ActionType Type = ActionType.SetValue;
        public string Target = "";
        public string Value = "";
        public string CustomCode = "";

        public void Execute()
        {
            try
            {
                switch (Type)
                {
                    case ActionType.SetValue: SetValue(); break;
                    case ActionType.ExecuteMethod: ExecuteMethod(); break;
                    case ActionType.SpawnObject: SpawnObject(); break;
                    case ActionType.DestroyObject: DestroyObject(); break;
                    case ActionType.Teleport: Teleport(); break;
                    case ActionType.Custom: ExecuteCustom(); break;
                }
            }
            catch (Exception ex) { Debug.LogError($"[LogicAction] Execution failed: {ex.Message}"); }
        }

        private void SetValue()
        {
            if (string.IsNullOrEmpty(Target)) return;
            string[] parts = Target.Split('.');
            if (parts.Length < 3) return;

            GameObject obj = GameObject.Find(parts[0]);
            if (obj == null) return;

            Type compType = TypeFinder.FindType(parts[1]);
            if (compType == null) return;

            Component comp = obj.GetComponent(compType);
            if (comp == null) return;

            var field = compType.GetField(parts[2], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (field != null)
            {
                object converted = Convert.ChangeType(Value, field.FieldType);
                field.SetValue(comp, converted);
                return;
            }

            var prop = compType.GetProperty(parts[2], BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            if (prop != null && prop.CanWrite)
            {
                object converted = Convert.ChangeType(Value, prop.PropertyType);
                prop.SetValue(comp, converted);
            }
        }

        private void ExecuteMethod()
        {
            Debug.Log($"[LogicAction] Executing method: {Target}");
        }

        private void SpawnObject()
        {
            Debug.Log($"[LogicAction] Spawning object: {Value}");
        }

        private void DestroyObject()
        {
            if (string.IsNullOrEmpty(Target)) return;
            GameObject obj = GameObject.Find(Target);
            if (obj != null) UnityEngine.Object.Destroy(obj);
        }

        private void Teleport()
        {
            if (string.IsNullOrEmpty(Target)) return;
            string[] parts = Target.Split(',');
            if (parts.Length < 4) return;

            GameObject obj = GameObject.Find(parts[0]);
            if (obj == null) return;

            float x = float.Parse(parts[1]);
            float y = float.Parse(parts[2]);
            float z = float.Parse(parts[3]);
            obj.transform.position = new Vector3(x, y, z);
        }

        private void ExecuteCustom()
        {
            if (string.IsNullOrEmpty(CustomCode)) return;
            Debug.Log($"[LogicAction] Executing custom code: {CustomCode}");
        }

        public string GetDisplayText()
        {
            switch (Type)
            {
                case ActionType.SetValue: return $"Set {Target} = {Value}";
                case ActionType.ExecuteMethod: return $"Execute {Target}";
                case ActionType.SpawnObject: return $"Spawn {Value}";
                case ActionType.DestroyObject: return $"Delete {Target}";
                case ActionType.Teleport: return $"Teleport {Target}";
                case ActionType.Custom: return "Custom action";
                default: return "Unknown";
            }
        }
    }

    // ============================================================
    // Logic Entity Main Class
    // ============================================================
    [Serializable]
    public class LogicEntity
    {
        public string Name = "New Logic";
        public string Description = "";
        public TriggerType Trigger = TriggerType.OnUpdate;
        public int Priority = 0;
        public bool Enabled = true;
        public List<LogicCondition> Conditions = new List<LogicCondition>();
        public List<LogicAction> Actions = new List<LogicAction>();
        public DateTime CreatedTime = DateTime.Now;
        public DateTime LastRunTime = DateTime.Now;
        private bool isRunning = false;

        public void Update()
        {
            if (!Enabled || isRunning) return;

            if (Trigger == TriggerType.OnUpdate || Trigger == TriggerType.OnFixedUpdate || Trigger == TriggerType.OnInterval)
            {
                bool allMet = true;
                foreach (var c in Conditions)
                {
                    if (!c.Check()) { allMet = false; break; }
                }
                if (allMet) Execute();
            }
        }

        public void Execute()
        {
            if (isRunning) return;
            isRunning = true;
            try
            {
                foreach (var a in Actions) a.Execute();
                LastRunTime = DateTime.Now;
                Debug.Log($"[LogicEntity] Executed: {Name}");
            }
            finally { isRunning = false; }
        }

        public void Start() { Enabled = true; }
        public void Stop() { Enabled = false; isRunning = false; }
        public bool IsRunning() { return isRunning; }
        public string GetStatusText()
        {
            if (!Enabled) return "⏸️ Paused";
            if (isRunning) return "🔄 Running";
            return "✅ Enabled";
        }
        public Color GetStatusColor()
        {
            if (!Enabled) return Color.gray;
            if (isRunning) return Color.yellow;
            return Color.green;
        }
    }

    // ============================================================
    // Type Finder Tool
    // ============================================================
    public static class TypeFinder
    {
        public static Type FindType(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return null;
            Type t = Type.GetType(typeName);
            if (t != null) return t;

            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try
                {
                    t = asm.GetType(typeName);
                    if (t != null) return t;
                    foreach (var type in asm.GetTypes())
                    {
                        try { if (type.Name == typeName || type.FullName == typeName) return type; }
                        catch { }
                    }
                }
                catch { }
            }
            return null;
        }
    }

    // ============================================================
    // Logic Manager (Full Version)
    // ============================================================
    public static class LogicManager
    {
        private static List<LogicEntity> logics = new List<LogicEntity>();
        private static string logicPath = Path.Combine(Paths.PluginPath, "SuperConsole", "Logicsv1");

        static LogicManager() { EnsureDirectory(); LoadAll(); }

        private static void EnsureDirectory()
        {
            if (!Directory.Exists(logicPath))
                Directory.CreateDirectory(logicPath);
        }

        public static void Register(LogicEntity logic)
        {
            if (!logics.Any(l => l.Name == logic.Name))
            {
                logics.Add(logic);
                Debug.Log($"[LogicManager] Registered: {logic.Name}");
            }
        }

        public static void Unregister(string name)
        {
            var l = logics.FirstOrDefault(x => x.Name == name);
            if (l != null) { l.Stop(); logics.Remove(l); }
        }

        public static void UpdateAll()
        {
            foreach (var l in logics) if (l.Enabled) l.Update();
        }

        public static List<LogicEntity> GetAll() => new List<LogicEntity>(logics);
        public static LogicEntity Get(string name) => logics.FirstOrDefault(l => l.Name == name);

        public static void Save(LogicEntity logic)
        {
            try
            {
                string file = Path.Combine(logicPath, GetSafeFileName(logic.Name) + ".json");
                string json = Serialize(logic);
                File.WriteAllText(file, json);
                Debug.Log($"[LogicManager] ✅ Saved: {logic.Name}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicManager] ❌ Save failed: {logic.Name} - {ex.Message}");
            }
        }

        public static void LoadAll()
        {
            if (!Directory.Exists(logicPath)) return;
            foreach (string file in Directory.GetFiles(logicPath, "*.json"))
            {
                try
                {
                    var logic = Deserialize(File.ReadAllText(file));
                    if (logic != null && !string.IsNullOrEmpty(logic.Name))
                    {
                        Register(logic);
                        Debug.Log($"[LogicManager] ✅ Loaded: {logic.Name} ({logic.Conditions.Count} conditions, {logic.Actions.Count} actions)");
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[LogicManager] ❌ Load failed: {file} - {ex.Message}");
                }
            }
        }

        // ============================================================
        // ✅ Complete Serialization
        // ============================================================
        private static string Serialize(LogicEntity logic)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine($"  \"Name\": \"{EscapeJson(logic.Name)}\",");
            sb.AppendLine($"  \"Description\": \"{EscapeJson(logic.Description)}\",");
            sb.AppendLine($"  \"Trigger\": \"{logic.Trigger}\",");
            sb.AppendLine($"  \"Priority\": {logic.Priority},");
            sb.AppendLine($"  \"Enabled\": {logic.Enabled.ToString().ToLower()},");

            // ---- Conditions ----
            sb.AppendLine("  \"Conditions\": [");
            for (int i = 0; i < logic.Conditions.Count; i++)
            {
                var c = logic.Conditions[i];
                sb.AppendLine("    {");
                sb.AppendLine($"      \"Type\": \"{c.Type}\",");
                sb.AppendLine($"      \"Target\": \"{EscapeJson(c.Target)}\",");
                sb.AppendLine($"      \"Operator\": \"{EscapeJson(c.Operator)}\",");
                sb.AppendLine($"      \"Value\": \"{EscapeJson(c.Value)}\",");
                sb.AppendLine($"      \"CustomCode\": \"{EscapeJson(c.CustomCode)}\"");
                sb.Append(i < logic.Conditions.Count - 1 ? "    }," : "    }");
                sb.AppendLine();
            }
            sb.AppendLine("  ],");

            // ---- Actions ----
            sb.AppendLine("  \"Actions\": [");
            for (int i = 0; i < logic.Actions.Count; i++)
            {
                var a = logic.Actions[i];
                sb.AppendLine("    {");
                sb.AppendLine($"      \"Type\": \"{a.Type}\",");
                sb.AppendLine($"      \"Target\": \"{EscapeJson(a.Target)}\",");
                sb.AppendLine($"      \"Value\": \"{EscapeJson(a.Value)}\",");
                sb.AppendLine($"      \"CustomCode\": \"{EscapeJson(a.CustomCode)}\"");
                sb.Append(i < logic.Actions.Count - 1 ? "    }," : "    }");
                sb.AppendLine();
            }
            sb.AppendLine("  ]");
            sb.AppendLine("}");
            return sb.ToString();
        }

        // ============================================================
        // ✅ Complete Deserialization (supports Conditions and Actions)
        // ============================================================
        private static LogicEntity Deserialize(string json)
        {
            LogicEntity logic = new LogicEntity();
            string[] lines = json.Split('\n');

            bool inConditions = false;
            bool inActions = false;
            LogicCondition currentCondition = null;
            LogicAction currentAction = null;

            foreach (var line in lines)
            {
                string trimmed = line.Trim().Trim(',');
                if (string.IsNullOrEmpty(trimmed)) continue;

                // ---- Main fields ----
                if (trimmed.StartsWith("\"Name\":"))
                    logic.Name = ExtractJsonString(trimmed);
                else if (trimmed.StartsWith("\"Description\":"))
                    logic.Description = ExtractJsonString(trimmed);
                else if (trimmed.StartsWith("\"Trigger\":"))
                    Enum.TryParse(ExtractJsonString(trimmed), out logic.Trigger);
                else if (trimmed.StartsWith("\"Priority\":"))
                    int.TryParse(trimmed.Split(':')[1].Trim(), out logic.Priority);
                else if (trimmed.StartsWith("\"Enabled\":"))
                    logic.Enabled = trimmed.Split(':')[1].Trim().ToLower() == "true";

                // ---- Enter conditions array ----
                else if (trimmed.StartsWith("\"Conditions\":"))
                {
                    inConditions = true;
                    inActions = false;
                }
                // ---- Enter actions array ----
                else if (trimmed.StartsWith("\"Actions\":"))
                {
                    inConditions = false;
                    inActions = true;
                }

                // ---- Parse conditions ----
                else if (inConditions)
                {
                    if (trimmed == "[") continue;
                    if (trimmed == "]") { inConditions = false; continue; }
                    if (trimmed == "{") { currentCondition = new LogicCondition(); continue; }
                    if (trimmed == "}")
                    {
                        if (currentCondition != null)
                        {
                            if (!string.IsNullOrEmpty(currentCondition.Target) ||
                                !string.IsNullOrEmpty(currentCondition.Value) ||
                                currentCondition.Type == ConditionType.Custom)
                            {
                                logic.Conditions.Add(currentCondition);
                            }
                        }
                        currentCondition = null;
                        continue;
                    }
                    if (currentCondition != null)
                    {
                        if (trimmed.StartsWith("\"Type\":"))
                            Enum.TryParse(ExtractJsonString(trimmed), out currentCondition.Type);
                        else if (trimmed.StartsWith("\"Target\":"))
                            currentCondition.Target = UnescapeJson(ExtractJsonString(trimmed));
                        else if (trimmed.StartsWith("\"Operator\":"))
                            currentCondition.Operator = UnescapeJson(ExtractJsonString(trimmed));
                        else if (trimmed.StartsWith("\"Value\":"))
                            currentCondition.Value = UnescapeJson(ExtractJsonString(trimmed));
                        else if (trimmed.StartsWith("\"CustomCode\":"))
                            currentCondition.CustomCode = UnescapeJson(ExtractJsonString(trimmed));
                    }
                }

                // ---- Parse actions ----
                else if (inActions)
                {
                    if (trimmed == "[") continue;
                    if (trimmed == "]") { inActions = false; continue; }
                    if (trimmed == "{") { currentAction = new LogicAction(); continue; }
                    if (trimmed == "}")
                    {
                        if (currentAction != null)
                        {
                            if (!string.IsNullOrEmpty(currentAction.Target) ||
                                !string.IsNullOrEmpty(currentAction.Value) ||
                                currentAction.Type == ActionType.Custom)
                            {
                                logic.Actions.Add(currentAction);
                            }
                        }
                        currentAction = null;
                        continue;
                    }
                    if (currentAction != null)
                    {
                        if (trimmed.StartsWith("\"Type\":"))
                            Enum.TryParse(ExtractJsonString(trimmed), out currentAction.Type);
                        else if (trimmed.StartsWith("\"Target\":"))
                            currentAction.Target = UnescapeJson(ExtractJsonString(trimmed));
                        else if (trimmed.StartsWith("\"Value\":"))
                            currentAction.Value = UnescapeJson(ExtractJsonString(trimmed));
                        else if (trimmed.StartsWith("\"CustomCode\":"))
                            currentAction.CustomCode = UnescapeJson(ExtractJsonString(trimmed));
                    }
                }
            }
            return logic;
        }

        // ============================================================
        // Helper Methods
        // ============================================================
        private static string ExtractJsonString(string line)
        {
            int start = line.IndexOf('"', line.IndexOf(':') + 1) + 1;
            int end = line.LastIndexOf('"');
            if (start > 0 && end > start)
                return line.Substring(start, end - start);
            return "";
        }

        private static string EscapeJson(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\\", "\\\\").Replace("\"", "\\\"")
                       .Replace("\n", "\\n").Replace("\r", "\\r")
                       .Replace("\t", "\\t");
        }

        private static string UnescapeJson(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\\n", "\n").Replace("\\r", "\r")
                       .Replace("\\t", "\t").Replace("\\\"", "\"")
                       .Replace("\\\\", "\\");
        }

        private static string GetSafeFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "unnamed";
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }
    }

    // ============================================================
    // Logic Texture Window (Visual Editor) - Deprecated, use LogicUI
    // ============================================================
    public static class LogicTexture
    {
        private static bool visible = false;
        private static Rect windowRect = new Rect(100, 100, 650, 550);
        private static Vector2 scrollPos = Vector2.zero;
        private static LogicEntity editingLogic = null;
        private static bool showAddCondition = false;
        private static bool showAddAction = false;
        private static int selectedConditionIndex = -1;
        private static int selectedActionIndex = -1;

        public static void Toggle()
        {
            visible = !visible;
            if (visible && editingLogic == null && LogicManager.GetAll().Count > 0)
                editingLogic = LogicManager.GetAll()[0];
        }

        public static void Draw()
        {
            if (!visible) return;
            windowRect = GUI.Window(12399, windowRect, DrawWindow, "🧠 Logic Editor [Esc to close]");
        }

        private static void DrawWindow(int id)
        {
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape)
            {
                visible = false;
                return;
            }

            GUILayout.BeginVertical();

            // ===== Toolbar =====
            GUILayout.BeginHorizontal();
            GUILayout.Label("📋 Logic:", GUILayout.Width(70));

            var allLogics = LogicManager.GetAll();
            string[] names = allLogics.Select(l => l.Name).ToArray();
            int currentIdx = editingLogic != null ? Array.IndexOf(names, editingLogic.Name) : -1;

            if (currentIdx < 0 && names.Length > 0) currentIdx = 0;

            int newIdx = GUILayout.SelectionGrid(currentIdx >= 0 ? currentIdx : 0, names.Length > 0 ? names : new string[] { "(None)" }, 4, GUILayout.ExpandWidth(true));

            if (newIdx >= 0 && newIdx < names.Length && (editingLogic == null || editingLogic.Name != names[newIdx]))
            {
                editingLogic = LogicManager.Get(names[newIdx]);
            }

            if (GUILayout.Button("➕ New", GUILayout.Width(50)))
            {
                var newLogic = new LogicEntity();
                newLogic.Name = "Logic_" + (LogicManager.GetAll().Count + 1);
                LogicManager.Register(newLogic);
                editingLogic = newLogic;
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            if (editingLogic == null)
            {
                GUILayout.Label("No logic entity. Click 'New' to create one.");
                GUILayout.EndVertical();
                GUI.DragWindow();
                return;
            }

            // ===== Basic Info =====
            GUILayout.BeginHorizontal();
            GUILayout.Label("Name:", GUILayout.Width(40));
            string newName = GUILayout.TextField(editingLogic.Name, GUILayout.Width(150));
            if (newName != editingLogic.Name) editingLogic.Name = newName;

            GUILayout.Label("Trigger:", GUILayout.Width(40));
            string[] triggers = Enum.GetNames(typeof(TriggerType));
            int triggerIdx = Array.IndexOf(triggers, editingLogic.Trigger.ToString());
            int newTriggerIdx = GUILayout.SelectionGrid(triggerIdx >= 0 ? triggerIdx : 0, triggers, 6, GUILayout.ExpandWidth(true));
            if (newTriggerIdx >= 0) editingLogic.Trigger = (TriggerType)newTriggerIdx;
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Desc:", GUILayout.Width(40));
            editingLogic.Description = GUILayout.TextField(editingLogic.Description, GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Status:", GUILayout.Width(40));
            GUI.color = editingLogic.GetStatusColor();
            GUILayout.Label(editingLogic.GetStatusText(), GUILayout.Width(80));
            GUI.color = Color.white;

            if (GUILayout.Button(editingLogic.Enabled ? "⏸️ Pause" : "▶️ Start", GUILayout.Width(60)))
            {
                if (editingLogic.Enabled) editingLogic.Stop();
                else editingLogic.Start();
            }
            if (GUILayout.Button("▶ Execute", GUILayout.Width(60))) editingLogic.Execute();
            if (GUILayout.Button("💾 Save", GUILayout.Width(50))) LogicManager.Save(editingLogic);
            if (GUILayout.Button("🗑️ Delete", GUILayout.Width(50)))
            {
                LogicManager.Unregister(editingLogic.Name);
                var list = LogicManager.GetAll();
                editingLogic = list.Count > 0 ? list[0] : null;
            }
            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            // ===== Conditions and Actions editing area =====
            GUILayout.BeginHorizontal();

            // Left: Conditions
            GUILayout.BeginVertical(GUILayout.Width(300));
            GUILayout.Label("📋 Conditions (" + editingLogic.Conditions.Count + ")", GUILayout.ExpandWidth(true));

            if (GUILayout.Button("➕ Add condition", GUILayout.Width(100)))
            {
                editingLogic.Conditions.Add(new LogicCondition());
                selectedConditionIndex = editingLogic.Conditions.Count - 1;
            }

            scrollPos = GUILayout.BeginScrollView(scrollPos, GUILayout.Height(200));

            for (int i = 0; i < editingLogic.Conditions.Count; i++)
            {
                var c = editingLogic.Conditions[i];
                GUILayout.BeginHorizontal("box");

                if (GUILayout.Button(i == selectedConditionIndex ? "▼" : "▶", GUILayout.Width(20)))
                {
                    selectedConditionIndex = (selectedConditionIndex == i) ? -1 : i;
                }

                GUILayout.Label(c.GetDisplayText(), GUILayout.ExpandWidth(true));

                if (GUILayout.Button("✖", GUILayout.Width(20)))
                {
                    editingLogic.Conditions.RemoveAt(i);
                    selectedConditionIndex = -1;
                    break;
                }
                GUILayout.EndHorizontal();

                if (selectedConditionIndex == i)
                {
                    GUILayout.BeginVertical("box");
                    string[] condTypes = Enum.GetNames(typeof(ConditionType));
                    int ctIdx = Array.IndexOf(condTypes, c.Type.ToString());
                    int newCtIdx = GUILayout.SelectionGrid(ctIdx >= 0 ? ctIdx : 0, condTypes, 3, GUILayout.ExpandWidth(true));
                    if (newCtIdx >= 0) c.Type = (ConditionType)newCtIdx;

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("Target:", GUILayout.Width(40));
                    c.Target = GUILayout.TextField(c.Target, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("Operator:", GUILayout.Width(50));
                    c.Operator = GUILayout.TextField(c.Operator, GUILayout.Width(50));
                    GUILayout.Label("Value:", GUILayout.Width(35));
                    c.Value = GUILayout.TextField(c.Value, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    if (c.Type == ConditionType.Custom)
                    {
                        GUILayout.Label("Custom code:");
                        c.CustomCode = GUILayout.TextArea(c.CustomCode, GUILayout.Height(40));
                    }
                    GUILayout.EndVertical();
                }
                GUILayout.Space(2);
            }
            GUILayout.EndScrollView();
            GUILayout.EndVertical();

            GUILayout.Box("", GUILayout.Width(2), GUILayout.ExpandHeight(true));

            // Right: Actions
            GUILayout.BeginVertical(GUILayout.ExpandWidth(true));
            GUILayout.Label("⚡ Actions (" + editingLogic.Actions.Count + ")", GUILayout.ExpandWidth(true));

            if (GUILayout.Button("➕ Add action", GUILayout.Width(100)))
            {
                editingLogic.Actions.Add(new LogicAction());
                selectedActionIndex = editingLogic.Actions.Count - 1;
            }

            GUILayout.BeginScrollView(Vector2.zero, GUILayout.Height(200));

            for (int i = 0; i < editingLogic.Actions.Count; i++)
            {
                var a = editingLogic.Actions[i];
                GUILayout.BeginHorizontal("box");

                if (GUILayout.Button(i == selectedActionIndex ? "▼" : "▶", GUILayout.Width(20)))
                {
                    selectedActionIndex = (selectedActionIndex == i) ? -1 : i;
                }

                GUILayout.Label(a.GetDisplayText(), GUILayout.ExpandWidth(true));

                if (GUILayout.Button("✖", GUILayout.Width(20)))
                {
                    editingLogic.Actions.RemoveAt(i);
                    selectedActionIndex = -1;
                    break;
                }
                GUILayout.EndHorizontal();

                if (selectedActionIndex == i)
                {
                    GUILayout.BeginVertical("box");
                    string[] actTypes = Enum.GetNames(typeof(ActionType));
                    int atIdx = Array.IndexOf(actTypes, a.Type.ToString());
                    int newAtIdx = GUILayout.SelectionGrid(atIdx >= 0 ? atIdx : 0, actTypes, 3, GUILayout.ExpandWidth(true));
                    if (newAtIdx >= 0) a.Type = (ActionType)newAtIdx;

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("Target:", GUILayout.Width(40));
                    a.Target = GUILayout.TextField(a.Target, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    GUILayout.BeginHorizontal();
                    GUILayout.Label("Value:", GUILayout.Width(35));
                    a.Value = GUILayout.TextField(a.Value, GUILayout.ExpandWidth(true));
                    GUILayout.EndHorizontal();

                    if (a.Type == ActionType.Custom)
                    {
                        GUILayout.Label("Custom code:");
                        a.CustomCode = GUILayout.TextArea(a.CustomCode, GUILayout.Height(40));
                    }
                    GUILayout.EndVertical();
                }
                GUILayout.Space(2);
            }
            GUILayout.EndScrollView();
            GUILayout.EndVertical();

            GUILayout.EndHorizontal();

            GUILayout.Box("", GUILayout.Height(2), GUILayout.ExpandWidth(true));

            GUILayout.BeginHorizontal();
            GUILayout.Label("💡 Target format: GameObject.Component.field (e.g. Player.PlayerCharacter.health)", GUILayout.ExpandWidth(true));
            if (GUILayout.Button("Close", GUILayout.Width(60))) visible = false;
            GUILayout.EndHorizontal();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        public static void Update()
        {
            if (visible) LogicManager.UpdateAll();
        }

        public static bool IsVisible() => visible;
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SuperConsole
{
    /// <summary>
    /// 场景提取器 - 从场景提取所有对象为逻辑体
    /// 注意：此版本已废弃，内部调用 LogicPrefabExtractor
    /// </summary>
    public static class LogicExtractor
    {
        /// <summary>
        /// 从 GameObject 提取（单个对象）
        /// </summary>
        public static LogicEntityV2 ExtractFromGameObject(GameObject source, string name, LogicType type = LogicType.Prefab)
        {
            if (source == null)
            {
                Debug.LogError("[LogicExtractor] ❌ 源对象为空");
                return null;
            }

            // 调用新版提取器
            return LogicPrefabExtractor.Extract(source, name, type);
        }

        /// <summary>
        /// 从场景提取（完整场景）
        /// </summary>
        public static LogicEntityV2 ExtractFromScene(string name, bool includeAllObjects = true)
        {
            if (string.IsNullOrEmpty(name))
            {
                name = SceneManager.GetActiveScene().name;
                if (string.IsNullOrEmpty(name)) name = "UnnamedScene";
            }

            Debug.Log("[LogicExtractor] 🗺️ 正在提取场景: " + name);
            Debug.Log("[LogicExtractor] ⚠️ 注意：场景提取功能正在迁移，当前为简化版本");

            // 创建逻辑体
            LogicEntityV2 logic = LogicManagerV2.Create(name, LogicType.Scene);

            // 创建目录
            string modelsDir = Path.Combine(logic.FolderPath, "models");
            string texturesDir = Path.Combine(logic.FolderPath, "textures");
            string audioDir = Path.Combine(logic.FolderPath, "audio");
            string materialsDir = Path.Combine(logic.FolderPath, "materials");
            string animationsDir = Path.Combine(logic.FolderPath, "animations");
            string prefabDir = Path.Combine(logic.FolderPath, "prefabs");

            Directory.CreateDirectory(modelsDir);
            Directory.CreateDirectory(texturesDir);
            Directory.CreateDirectory(audioDir);
            Directory.CreateDirectory(materialsDir);
            Directory.CreateDirectory(animationsDir);
            Directory.CreateDirectory(prefabDir);

            Scene currentScene = SceneManager.GetActiveScene();
            GameObject[] rootObjects = currentScene.GetRootGameObjects();

            int totalObjects = 0;
            int totalMeshes = 0;
            int totalTextures = 0;
            int totalMaterials = 0;
            int totalAnimations = 0;
            int totalAudio = 0;

            List<GameObject> allObjects = new List<GameObject>();
            foreach (var root in rootObjects)
            {
                if (root == null) continue;
                allObjects.Add(root);
                foreach (Transform child in root.GetComponentsInChildren<Transform>(true))
                {
                    if (child != null && child.gameObject != null)
                        allObjects.Add(child.gameObject);
                }
            }

            totalObjects = allObjects.Count;

            HashSet<string> addedMeshes = new HashSet<string>();
            HashSet<string> addedTextures = new HashSet<string>();
            HashSet<string> addedMaterials = new HashSet<string>();
            HashSet<string> addedAnimations = new HashSet<string>();
            HashSet<string> addedAudio = new HashSet<string>();

            // 提取每个对象
            foreach (var obj in allObjects)
            {
                if (obj == null) continue;

                // 提取 Mesh
                MeshFilter mf = obj.GetComponent<MeshFilter>();
                if (mf != null && mf.mesh != null && !addedMeshes.Contains(mf.mesh.name))
                {
                    addedMeshes.Add(mf.mesh.name);
                    string meshName = GetSafeName(mf.mesh.name, "mesh");
                    string path = Path.Combine(modelsDir, meshName + ".obj");
                    string objContent = MeshToObj(mf.mesh);
                    File.WriteAllText(path, objContent);
                    totalMeshes++;
                    if (string.IsNullOrEmpty(logic.resources.Model))
                        logic.resources.Model = $"models/{meshName}.obj";
                }

                // 提取 SkinnedMesh
                SkinnedMeshRenderer smr = obj.GetComponent<SkinnedMeshRenderer>();
                if (smr != null && smr.sharedMesh != null && !addedMeshes.Contains(smr.sharedMesh.name))
                {
                    addedMeshes.Add(smr.sharedMesh.name);
                    string meshName = GetSafeName(smr.sharedMesh.name, "skinned");
                    string path = Path.Combine(modelsDir, meshName + ".obj");
                    string objContent = MeshToObj(smr.sharedMesh);
                    File.WriteAllText(path, objContent);
                    totalMeshes++;
                    if (string.IsNullOrEmpty(logic.resources.Model))
                        logic.resources.Model = $"models/{meshName}.obj";
                }

                // 提取纹理
                Renderer renderer = obj.GetComponent<Renderer>();
                if (renderer != null)
                {
                    foreach (var mat in renderer.sharedMaterials)
                    {
                        if (mat == null) continue;
                        if (mat.mainTexture != null)
                        {
                            Texture2D tex = mat.mainTexture as Texture2D;
                            if (tex != null && !addedTextures.Contains(tex.name))
                            {
                                addedTextures.Add(tex.name);
                                string texName = GetSafeName(tex.name, "texture");
                                string path = Path.Combine(texturesDir, texName + ".png");
                                try
                                {
                                    byte[] data = tex.EncodeToPNG();
                                    if (data != null && data.Length > 0)
                                    {
                                        File.WriteAllBytes(path, data);
                                        totalTextures++;
                                        logic.resources.Textures.Add($"textures/{texName}.png");
                                    }
                                }
                                catch { }
                            }
                        }

                        if (!addedMaterials.Contains(mat.name))
                        {
                            addedMaterials.Add(mat.name);
                            string matName = GetSafeName(mat.name, "material");
                            string path = Path.Combine(materialsDir, matName + ".mat");
                            string content = SerializeMaterial(mat);
                            File.WriteAllText(path, content);
                            totalMaterials++;
                            logic.resources.Materials.Add($"materials/{matName}.mat");
                        }
                    }
                }

                // 提取动画
                Animation anim = obj.GetComponent<Animation>();
                if (anim != null)
                {
                    foreach (AnimationState state in anim)
                    {
                        if (state == null || state.clip == null) continue;
                        if (!addedAnimations.Contains(state.clip.name))
                        {
                            addedAnimations.Add(state.clip.name);
                            string clipName = GetSafeName(state.clip.name, "anim");
                            string path = Path.Combine(animationsDir, clipName + ".anim");
                            string content = SerializeAnimationClip(state.clip);
                            File.WriteAllText(path, content);
                            totalAnimations++;
                            logic.resources.Animations.Add($"animations/{clipName}.anim");
                        }
                    }
                }

                // 提取 Animator
                Animator animator = obj.GetComponent<Animator>();
                if (animator != null && animator.runtimeAnimatorController != null)
                {
                    var clips = animator.runtimeAnimatorController.animationClips;
                    foreach (var clip in clips)
                    {
                        if (clip == null) continue;
                        if (!addedAnimations.Contains(clip.name))
                        {
                            addedAnimations.Add(clip.name);
                            string clipName = GetSafeName(clip.name, "anim");
                            string path = Path.Combine(animationsDir, clipName + ".anim");
                            string content = SerializeAnimationClip(clip);
                            File.WriteAllText(path, content);
                            totalAnimations++;
                            logic.resources.Animations.Add($"animations/{clipName}.anim");
                        }
                    }
                }

                // 提取音频
                AudioSource audioSource = obj.GetComponent<AudioSource>();
                if (audioSource != null && audioSource.clip != null && !addedAudio.Contains(audioSource.clip.name))
                {
                    addedAudio.Add(audioSource.clip.name);
                    string clipName = GetSafeName(audioSource.clip.name, "audio");
                    totalAudio++;
                    logic.resources.Audio.Add($"audio/{clipName}.wav");
                }
            }

            // 保存场景对象列表
            string sceneListPath = Path.Combine(logic.FolderPath, "scenes", "objects.json");
            Directory.CreateDirectory(Path.GetDirectoryName(sceneListPath));
            string sceneJson = SerializeSceneObjects(allObjects);
            File.WriteAllText(sceneListPath, sceneJson);
            logic.resources.Scene = $"scenes/objects.json";

            logic.description = $"从场景 {currentScene.name} 提取，包含 {totalObjects} 个对象，{totalMeshes} 个模型，{totalTextures} 个纹理，{totalMaterials} 个材质，{totalAnimations} 个动画，{totalAudio} 个音频";

            logic.tags.Add($"scene:{currentScene.name}");
            logic.tags.Add($"objects:{totalObjects}");
            logic.tags.Add($"meshes:{totalMeshes}");
            logic.tags.Add($"textures:{totalTextures}");
            logic.tags.Add($"materials:{totalMaterials}");
            logic.tags.Add($"animations:{totalAnimations}");
            logic.tags.Add($"audio:{totalAudio}");

            // 保存为预制体（场景根对象）
            if (rootObjects.Length > 0)
            {
                GameObject combined = new GameObject("Scene_" + name);
                foreach (var root in rootObjects)
                {
                    if (root != null)
                        root.transform.SetParent(combined.transform);
                }
                LogicPrefabSaver.SavePrefab(combined, logic.FolderPath, "main");
                logic.resources.Prefab = "prefabs/main.prefab";
                UnityEngine.Object.Destroy(combined);
            }

            LogicManagerV2.SaveToFile(logic);

            Debug.Log($"[LogicExtractor] 🗺️ 场景提取完成: {logic.GetDisplayName()}");
            Debug.Log($"   📊 对象: {totalObjects}, 模型: {totalMeshes}, 纹理: {totalTextures}, 材质: {totalMaterials}, 动画: {totalAnimations}, 音频: {totalAudio}");

            return logic;
        }

        // ========== 辅助方法 ==========

        private static string SerializeSceneObjects(List<GameObject> objects)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[");
            for (int i = 0; i < objects.Count; i++)
            {
                var obj = objects[i];
                if (obj == null) continue;

                sb.AppendLine("  {");
                sb.AppendLine($"    \"name\": \"{EscapeJson(obj.name)}\",");
                sb.AppendLine($"    \"tag\": \"{EscapeJson(obj.tag)}\",");
                sb.AppendLine($"    \"layer\": {obj.layer},");
                sb.AppendLine($"    \"active\": {obj.activeSelf.ToString().ToLower()},");
                sb.AppendLine($"    \"position\": \"{obj.transform.position.x:F3},{obj.transform.position.y:F3},{obj.transform.position.z:F3}\",");
                sb.AppendLine($"    \"rotation\": \"{obj.transform.rotation.eulerAngles.x:F3},{obj.transform.rotation.eulerAngles.y:F3},{obj.transform.rotation.eulerAngles.z:F3}\",");
                sb.AppendLine($"    \"scale\": \"{obj.transform.localScale.x:F3},{obj.transform.localScale.y:F3},{obj.transform.localScale.z:F3}\",");
                sb.AppendLine($"    \"components\": [");

                Component[] comps = obj.GetComponents<Component>();
                for (int j = 0; j < comps.Length; j++)
                {
                    var comp = comps[j];
                    if (comp == null) continue;
                    if (comp is Transform) continue;
                    string compName = comp.GetType().Name;
                    sb.Append($"      \"{compName}\"");
                    if (j < comps.Length - 1) sb.Append(",");
                    sb.AppendLine();
                }

                sb.AppendLine("    ]");

                if (i < objects.Count - 1)
                    sb.AppendLine("  },");
                else
                    sb.AppendLine("  }");
            }
            sb.AppendLine("]");
            return sb.ToString();
        }

        private static string GetSafeName(string name, string fallback)
        {
            if (string.IsNullOrEmpty(name) || name == "Mesh" || name == "Texture")
                return $"{fallback}_{Guid.NewGuid().ToString().Substring(0, 6)}";
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        private static string EscapeJson(string text)
        {
            if (string.IsNullOrEmpty(text)) return "";
            return text.Replace("\\", "\\\\").Replace("\"", "\\\"")
                       .Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t");
        }

        private static string MeshToObj(Mesh mesh)
        {
            if (mesh == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"# Extracted by SuperConsole");
            sb.AppendLine($"# Mesh: {mesh.name}");

            foreach (Vector3 v in mesh.vertices)
                sb.AppendLine($"v {v.x:F6} {v.y:F6} {v.z:F6}");

            if (mesh.uv.Length > 0)
                foreach (Vector2 uv in mesh.uv)
                    sb.AppendLine($"vt {uv.x:F6} {uv.y:F6}");

            foreach (Vector3 n in mesh.normals)
                sb.AppendLine($"vn {n.x:F6} {n.y:F6} {n.z:F6}");

            int[] triangles = mesh.triangles;
            for (int i = 0; i < triangles.Length; i += 3)
            {
                int v1 = triangles[i] + 1;
                int v2 = triangles[i + 1] + 1;
                int v3 = triangles[i + 2] + 1;
                if (mesh.uv.Length > 0)
                    sb.AppendLine($"f {v1}/{v1} {v2}/{v2} {v3}/{v3}");
                else
                    sb.AppendLine($"f {v1} {v2} {v3}");
            }
            return sb.ToString();
        }

        private static string SerializeMaterial(Material mat)
        {
            if (mat == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"# SuperConsole Material Export");
            sb.AppendLine($"# Material: {mat.name}");
            sb.AppendLine($"shader: {mat.shader?.name ?? "Standard"}");
            sb.AppendLine($"renderQueue: {mat.renderQueue}");

            if (mat.HasProperty("_Color"))
            {
                Color c = mat.GetColor("_Color");
                sb.AppendLine($"color: {c.r:F4}, {c.g:F4}, {c.b:F4}, {c.a:F4}");
            }
            if (mat.HasProperty("_MainTex") && mat.mainTexture != null)
                sb.AppendLine($"mainTexture: {mat.mainTexture.name}");
            if (mat.HasProperty("_Metallic"))
                sb.AppendLine($"metallic: {mat.GetFloat("_Metallic"):F4}");
            if (mat.HasProperty("_Glossiness"))
                sb.AppendLine($"smoothness: {mat.GetFloat("_Glossiness"):F4}");
            return sb.ToString();
        }

        private static string SerializeAnimationClip(AnimationClip clip)
        {
            if (clip == null) return "";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"# SuperConsole Animation Export");
            sb.AppendLine($"# Clip: {clip.name}");
            sb.AppendLine($"frameRate: {clip.frameRate:F2}");
            sb.AppendLine($"length: {clip.length:F4}");
            sb.AppendLine($"loop: {clip.isLooping}");
            sb.AppendLine($"events: {clip.events.Length}");

            foreach (var evt in clip.events)
            {
                sb.AppendLine($"  event: {evt.time:F4} | {evt.functionName} | {evt.stringParameter} | {evt.floatParameter:F4}");
            }
            return sb.ToString();
        }
    }
}
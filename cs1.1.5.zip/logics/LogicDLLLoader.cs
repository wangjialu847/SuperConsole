﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace SuperConsole
{
    public interface ILogicObject
    {
        void OnSpawn(GameObject gameObject, LogicEntityV2 logic);
        void OnDestroy(GameObject gameObject);
        void OnUpdate();
        void OnMessage(string message, object data);
    }

    public interface ILogicComponent
    {
        void OnLogicSpawn(LogicEntityV2 logic);
        void OnLogicDestroy();
        void OnLogicMessage(string message, object data);
    }

    [AttributeUsage(AttributeTargets.Class)]
    public class DontAttachAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Class)]
    public class LogicMainAttribute : Attribute { }

    public static class LogicDLLLoader
    {
        private static Dictionary<string, Assembly> loadedAssemblies = new Dictionary<string, Assembly>();
        private static Dictionary<string, List<ILogicObject>> logicObjects = new Dictionary<string, List<ILogicObject>>();
        private static Dictionary<string, List<MonoBehaviour>> attachedBehaviours = new Dictionary<string, List<MonoBehaviour>>();
        private static Dictionary<string, GameObject> logicGameObjects = new Dictionary<string, GameObject>();

        private static bool _unloadWarningShown = false;

        public static Assembly LoadDLL(LogicEntityV2 logic)
        {
            if (logic == null || string.IsNullOrEmpty(logic.resources.DLL))
                return null;

            string dllPath = Path.Combine(logic.FolderPath, logic.resources.DLL);
            if (!File.Exists(dllPath))
            {
                Debug.LogWarning($"[LogicDLLLoader] DLL 不存在: {dllPath}");
                return null;
            }

            string key = logic.id;
            if (loadedAssemblies.ContainsKey(key))
            {
                Debug.Log($"[LogicDLLLoader] DLL 已加载: {logic.name}");
                return loadedAssemblies[key];
            }

            try
            {
                byte[] dllBytes = File.ReadAllBytes(dllPath);
                Assembly assembly = Assembly.Load(dllBytes);
                loadedAssemblies[key] = assembly;
                logicObjects[key] = new List<ILogicObject>();

                Debug.Log($"[LogicDLLLoader] ✅ DLL 加载成功: {logic.name} ({assembly.GetName().Name})");

                foreach (Type type in assembly.GetTypes())
                {
                    if (type.IsAbstract || type.IsInterface) continue;
                    Debug.Log($"[LogicDLLLoader]   - 类型: {type.Name}");
                }

                return assembly;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicDLLLoader] ❌ DLL 加载失败: {dllPath} - {ex.Message}");
                return null;
            }
        }

        public static void AttachComponents(GameObject target, LogicEntityV2 logic)
        {
            if (target == null || logic == null) return;

            Assembly assembly = LoadDLL(logic);
            if (assembly == null) return;

            string key = logic.id;
            if (!attachedBehaviours.ContainsKey(key))
                attachedBehaviours[key] = new List<MonoBehaviour>();

            try
            {
                foreach (Type type in assembly.GetTypes())
                {
                    if (type.IsAbstract || type.IsInterface) continue;
                    if (!typeof(MonoBehaviour).IsAssignableFrom(type)) continue;

                    var dontAttach = type.GetCustomAttribute<DontAttachAttribute>();
                    if (dontAttach != null) continue;

                    bool isLogicComponent = typeof(ILogicComponent).IsAssignableFrom(type);

                    MonoBehaviour behaviour = target.AddComponent(type) as MonoBehaviour;
                    if (behaviour != null)
                    {
                        attachedBehaviours[key].Add(behaviour);
                        Debug.Log($"[LogicDLLLoader] 附加组件: {type.Name} -> {target.name}");

                        if (isLogicComponent && behaviour is ILogicComponent logicComp)
                        {
                            logicComp.OnLogicSpawn(logic);
                            Debug.Log($"[LogicDLLLoader] 初始化逻辑组件: {type.Name}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicDLLLoader] 附加组件失败: {ex.Message}");
            }
        }

        public static void Initialize(GameObject target, LogicEntityV2 logic)
        {
            if (target == null || logic == null) return;

            Assembly assembly = LoadDLL(logic);
            if (assembly == null) return;

            string key = logic.id;
            if (!logicObjects.ContainsKey(key))
                logicObjects[key] = new List<ILogicObject>();

            try
            {
                foreach (Type type in assembly.GetTypes())
                {
                    if (type.IsAbstract || type.IsInterface) continue;

                    if (typeof(ILogicObject).IsAssignableFrom(type) && !typeof(MonoBehaviour).IsAssignableFrom(type))
                    {
                        try
                        {
                            object instance = Activator.CreateInstance(type);
                            if (instance is ILogicObject logicObj)
                            {
                                logicObj.OnSpawn(target, logic);
                                logicObjects[key].Add(logicObj);
                                Debug.Log($"[LogicDLLLoader] 初始化逻辑对象: {type.Name}");
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.LogWarning($"[LogicDLLLoader] 实例化失败 {type.Name}: {ex.Message}");
                        }
                    }

                    var initMethod = type.GetMethod("OnLogicSpawn",
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
                    if (initMethod != null)
                    {
                        try
                        {
                            initMethod.Invoke(null, new object[] { target, logic });
                            Debug.Log($"[LogicDLLLoader] 调用静态初始化: {type.Name}.OnLogicSpawn");
                        }
                        catch (Exception ex)
                        {
                            Debug.LogWarning($"[LogicDLLLoader] 静态初始化失败: {ex.Message}");
                        }
                    }
                }

                logicGameObjects[key] = target;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[LogicDLLLoader] 初始化失败: {ex.Message}");
            }
        }

        public static void UpdateAll()
        {
            foreach (var kv in logicObjects)
            {
                foreach (var obj in kv.Value)
                {
                    try { obj.OnUpdate(); }
                    catch (Exception ex) { Debug.LogError($"[LogicDLLLoader] Update 失败: {ex.Message}"); }
                }
            }
        }

        public static void SendMessage(string logicId, string message, object data = null)
        {
            if (!logicObjects.ContainsKey(logicId)) return;

            foreach (var obj in logicObjects[logicId])
            {
                try { obj.OnMessage(message, data); }
                catch (Exception ex) { Debug.LogError($"[LogicDLLLoader] 消息发送失败: {ex.Message}"); }
            }

            if (attachedBehaviours.ContainsKey(logicId))
            {
                foreach (var comp in attachedBehaviours[logicId])
                {
                    if (comp is ILogicComponent logicComp)
                    {
                        try { logicComp.OnLogicMessage(message, data); }
                        catch (Exception ex) { Debug.LogError($"[LogicDLLLoader] 组件消息失败: {ex.Message}"); }
                    }
                }
            }
        }

        public static void UnloadDLL(string id)
        {
            if (!loadedAssemblies.ContainsKey(id)) return;

            // 1. 通知 ILogicObject 销毁
            if (logicObjects.ContainsKey(id))
            {
                GameObject go = logicGameObjects.ContainsKey(id) ? logicGameObjects[id] : null;
                foreach (var obj in logicObjects[id])
                {
                    try
                    {
                        if (go != null) obj.OnDestroy(go);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogError($"[LogicDLLLoader] OnDestroy 失败: {ex.Message}");
                    }
                }
                logicObjects.Remove(id);
            }

            // 2. 通知 ILogicComponent 销毁
            if (attachedBehaviours.ContainsKey(id))
            {
                foreach (var comp in attachedBehaviours[id])
                {
                    if (comp != null && comp is ILogicComponent logicComp)
                    {
                        try { logicComp.OnLogicDestroy(); }
                        catch (Exception ex) { Debug.LogError($"[LogicDLLLoader] 组件销毁失败: {ex.Message}"); }
                    }
                    if (comp != null)
                        UnityEngine.Object.Destroy(comp);
                }
                attachedBehaviours.Remove(id);
            }

            // 3. 清除 GameObject 引用
            if (logicGameObjects.ContainsKey(id))
                logicGameObjects.Remove(id);

            // 4. 卸载程序集引用
            loadedAssemblies.Remove(id);

            // ⚠️ 显示卸载警告（仅一次）
            if (!_unloadWarningShown)
            {
                Debug.LogWarning("[LogicDLLLoader] ⚠️ 注意：.NET 无法真正卸载已加载的 Assembly。");
                Debug.LogWarning("[LogicDLLLoader] ⚠️ 卸载只是清除了引用，DLL 仍占用内存。");
                Debug.LogWarning("[LogicDLLLoader] 💡 建议：只在逻辑体销毁时调用，不要频繁重载。");
                _unloadWarningShown = true;
            }

            Debug.Log($"[LogicDLLLoader] ✅ DLL 已卸载（引用已清除）: {id}");
        }

        public static void UnloadAll()
        {
            List<string> keys = new List<string>(loadedAssemblies.Keys);
            foreach (string key in keys)
            {
                UnloadDLL(key);
            }
            Debug.Log("[LogicDLLLoader] 所有逻辑体 DLL 已卸载（引用已清除）");
        }

        public static Assembly GetDLL(string id)
        {
            return loadedAssemblies.ContainsKey(id) ? loadedAssemblies[id] : null;
        }

        public static List<ILogicObject> GetLogicObjects(string id)
        {
            return logicObjects.ContainsKey(id) ? logicObjects[id] : null;
        }

        public static bool IsLoaded(string id) => loadedAssemblies.ContainsKey(id);
    }
}